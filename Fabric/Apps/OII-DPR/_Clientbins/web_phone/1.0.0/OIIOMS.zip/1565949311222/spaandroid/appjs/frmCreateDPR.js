define("frmCreateDPR", function() {
    return function(controller) {
        function addWidgetsfrmCreateDPR() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxBgf0f0f0",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "7%",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlx003C5COp100",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var flxBack = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "52%",
                "clipBounds": true,
                "height": "35dp",
                "id": "flxBack",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "4%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_adb4ce04e85d4a8f95ea8a99b6bc2238,
                "skin": "slFbox",
                "width": "35dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxBack.setDefaultUnit(kony.flex.DP);
            var imgBack = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "60%",
                "id": "imgBack",
                "isVisible": true,
                "skin": "slImage",
                "src": "back_icon.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBack.add(imgBack);
            var lblTitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblTitle",
                "isVisible": true,
                "skin": "sknLblFFFFFFOp100S130",
                "text": "Create DPR",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxHeader.add(flxBack, lblTitle);
            var flxBody = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "93%",
                "horizontalScrollIndicator": true,
                "id": "flxBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "7.00%",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxBody.setDefaultUnit(kony.flex.DP);
            var flxProjectHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "7%",
                "id": "flxProjectHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgf0f0f0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxProjectHeader.setDefaultUnit(kony.flex.DP);
            var lblProjectDetails = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblProjectDetails",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL00263e110",
                "text": "Project Details - 0000100153",
                "textStyle": {},
                "width": "75%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var flxProjectDetailsArrow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "25dp",
                "id": "flxProjectDetailsArrow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5%",
                "skin": "slFbox",
                "width": "25dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxProjectDetailsArrow.setDefaultUnit(kony.flex.DP);
            var imgProjectDetailsArrow = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgProjectDetailsArrow",
                "isVisible": true,
                "skin": "slImage",
                "src": "down_arrow.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProjectDetailsArrow.add(imgProjectDetailsArrow);
            flxProjectHeader.add(lblProjectDetails, flxProjectDetailsArrow);
            var flxProjectDetailsBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxProjectDetailsBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxOp0",
                "top": "0%",
                "width": "90%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxProjectDetailsBody.setDefaultUnit(kony.flex.DP);
            var flxSuperVisor = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSuperVisor",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSuperVisor.setDefaultUnit(kony.flex.DP);
            var lblSupervisor = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSupervisor",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Supervisor",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblSupervisorValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSupervisorValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "text": "Chaves, Nelson",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxSuperVisor.add(lblSupervisor, lblSupervisorValue);
            var flxLocation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxLocation",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxLocation.setDefaultUnit(kony.flex.DP);
            var lblLocation = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblLocation",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Location",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblLocationValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblLocationValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "text": "Times Square",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxLocation.add(lblLocation, lblLocationValue);
            var flxCountry = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxCountry",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCountry.setDefaultUnit(kony.flex.DP);
            var lblCountry = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCountry",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Country",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblCountryValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCountryValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "text": "Albania",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxCountry.add(lblCountry, lblCountryValue);
            var flxProjectManager = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxProjectManager",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxProjectManager.setDefaultUnit(kony.flex.DP);
            var lblProjectManager = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblProjectManager",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Project Manager",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblProjectManagerValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblProjectManagerValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "text": "Philip Doyle",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxProjectManager.add(lblProjectManager, lblProjectManagerValue);
            flxProjectDetailsBody.add(flxSuperVisor, flxLocation, flxCountry, flxProjectManager);
            var flxProjectDetailsHorizontalLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxProjectDetailsHorizontalLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxDBDBDBOp100",
                "top": "2%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxProjectDetailsHorizontalLine.setDefaultUnit(kony.flex.DP);
            flxProjectDetailsHorizontalLine.add();
            var flxCrewHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "7%",
                "id": "flxCrewHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgf0f0f0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCrewHeader.setDefaultUnit(kony.flex.DP);
            var lblCrewDetails = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblCrewDetails",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL00263e110",
                "text": "Crew Details",
                "textStyle": {},
                "width": "75%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var flxCrewDetailsArrow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "25dp",
                "id": "flxCrewDetailsArrow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5%",
                "skin": "slFbox",
                "width": "25dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCrewDetailsArrow.setDefaultUnit(kony.flex.DP);
            var imgCrewDetailsArrow = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgCrewDetailsArrow",
                "isVisible": true,
                "skin": "slImage",
                "src": "down_arrow.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCrewDetailsArrow.add(imgCrewDetailsArrow);
            flxCrewHeader.add(lblCrewDetails, flxCrewDetailsArrow);
            var segCrewDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "data": [{
                    "imgAddCrew": "",
                    "lblAddCrew": "",
                    "lblCrewMemberName": "Nakul Gupta",
                    "lblRole": "Supervisor"
                }, {
                    "imgAddCrew": "",
                    "lblAddCrew": "",
                    "lblCrewMemberName": "Ravi Khandelwal",
                    "lblRole": "Crew"
                }, {
                    "imgAddCrew": "",
                    "lblAddCrew": "",
                    "lblCrewMemberName": "Prabhjot Singh",
                    "lblRole": "Crew"
                }],
                "groupCells": false,
                "id": "segCrewDetails",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "sknSegOp0",
                "rowTemplate": "flxTempCrewDetails",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxTempCrewDetails": "flxTempCrewDetails",
                    "flxTempCrewDetailsInner": "flxTempCrewDetailsInner",
                    "imgAddCrew": "imgAddCrew",
                    "lblAddCrew": "lblAddCrew",
                    "lblCrewMemberName": "lblCrewMemberName",
                    "lblRole": "lblRole"
                },
                "width": "90%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCrewDetailsHorizontalLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxCrewDetailsHorizontalLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxDBDBDBOp100",
                "top": "2%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCrewDetailsHorizontalLine.setDefaultUnit(kony.flex.DP);
            flxCrewDetailsHorizontalLine.add();
            var flxPersonnelHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "7%",
                "id": "flxPersonnelHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgf0f0f0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxPersonnelHeader.setDefaultUnit(kony.flex.DP);
            var lblPersonnel = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblPersonnel",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL00263e110",
                "text": "Personnel",
                "textStyle": {},
                "width": "75%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var flxPersonnelDetailsArrow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "25dp",
                "id": "flxPersonnelDetailsArrow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5%",
                "skin": "slFbox",
                "width": "25dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxPersonnelDetailsArrow.setDefaultUnit(kony.flex.DP);
            var imgPersonnelDetailsArrow = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgPersonnelDetailsArrow",
                "isVisible": true,
                "skin": "slImage",
                "src": "down_arrow.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPersonnelDetailsArrow.add(imgPersonnelDetailsArrow);
            flxPersonnelHeader.add(lblPersonnel, flxPersonnelDetailsArrow);
            var flxPersonnelDetailsBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxPersonnelDetailsBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxOp0",
                "top": "0%",
                "width": "90%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxPersonnelDetailsBody.setDefaultUnit(kony.flex.DP);
            var flxName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxName.setDefaultUnit(kony.flex.DP);
            var lblName = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblName",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Name",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblNameValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNameValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxName.add(lblName, lblNameValue);
            var flxEmployeeID = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxEmployeeID",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxEmployeeID.setDefaultUnit(kony.flex.DP);
            var lblEmpID = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblEmpID",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Employee ID",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblEmpIDValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblEmpIDValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxEmployeeID.add(lblEmpID, lblEmpIDValue);
            var flxJobPosition = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxJobPosition",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxJobPosition.setDefaultUnit(kony.flex.DP);
            var lblJobPosition = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblJobPosition",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "JobPosition",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblJobPositionValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblJobPositionValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxJobPosition.add(lblJobPosition, lblJobPositionValue);
            var flxCrewPosition = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxCrewPosition",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCrewPosition.setDefaultUnit(kony.flex.DP);
            var lblCrewPosition = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCrewPosition",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Crew Position",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblCrewPositionValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCrewPositionValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxCrewPosition.add(lblCrewPosition, lblCrewPositionValue);
            var flxTRC = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxTRC",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxTRC.setDefaultUnit(kony.flex.DP);
            var lblTRC = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblTRC",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "TRC",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var flxTRCValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "80%",
                "id": "flxTRCValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_i70a97574b9a4bfd9a2a11c4ce025c20,
                "right": "5%",
                "skin": "slFbox",
                "width": "50%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxTRCValue.setDefaultUnit(kony.flex.DP);
            var imgArrow = new kony.ui.Image2({
                "height": "100%",
                "id": "imgArrow",
                "isVisible": true,
                "right": "0dp",
                "skin": "slImage",
                "src": "down_arrow.png",
                "top": "0dp",
                "width": "10%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTRCValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblTRCValue",
                "isVisible": true,
                "maxNumberOfLines": 1,
                "right": "2%",
                "skin": "sknLbl120333333",
                "text": "None",
                "textStyle": {},
                "textTruncatePosition": constants.TEXT_TRUNCATE_END,
                "width": "88%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxTRCValue.add(imgArrow, lblTRCValue);
            flxTRC.add(lblTRC, flxTRCValue);
            var flxDepth = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxDepth",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxDepth.setDefaultUnit(kony.flex.DP);
            var lblDepth = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDepth",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Depth",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblDepthValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDepthValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "text": "420 m",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxDepth.add(lblDepth, lblDepthValue);
            var flxUOM = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxUOM",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxUOM.setDefaultUnit(kony.flex.DP);
            var lblUOM = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblUOM",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "UOM",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblUOMValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblUOMValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "text": "0",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxUOM.add(lblUOM, lblUOMValue);
            var flxNormalHours = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxNormalHours",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxNormalHours.setDefaultUnit(kony.flex.DP);
            var lblNormalHours = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNormalHours",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Normal Hours",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtNormalHoursValue = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTbxBorder25PrcntWhiteBgFont100",
                "height": "70%",
                "id": "txtNormalHoursValue",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "maxTextLength": null,
                "right": "5%",
                "secureTextEntry": false,
                "skin": "sknTbxBorder25PrcntWhiteBgFont100",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_NUMERIC,
                "width": "20%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxNormalHours.add(lblNormalHours, txtNormalHoursValue);
            var flxBillingHours = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxBillingHours",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxBillingHours.setDefaultUnit(kony.flex.DP);
            var lblBillingHours = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblBillingHours",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Billing Hours",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtBillingHoursValue = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTbxBorder25PrcntWhiteBgFont100",
                "height": "70%",
                "id": "txtBillingHoursValue",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "maxTextLength": null,
                "right": "5%",
                "secureTextEntry": false,
                "skin": "sknTbxBorder25PrcntWhiteBgFont100",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_NUMERIC,
                "width": "20%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxBillingHours.add(lblBillingHours, txtBillingHoursValue);
            var flxStandbyHours = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxStandbyHours",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxStandbyHours.setDefaultUnit(kony.flex.DP);
            var lblStandbyHours = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblStandbyHours",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Standby Hours",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtStandbyHoursValue = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTbxBorder25PrcntWhiteBgFont100",
                "height": "70%",
                "id": "txtStandbyHoursValue",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "maxTextLength": null,
                "right": "5%",
                "secureTextEntry": false,
                "skin": "sknTbxBorder25PrcntWhiteBgFont100",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_NUMERIC,
                "width": "20%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxStandbyHours.add(lblStandbyHours, txtStandbyHoursValue);
            var flxOTHours = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxOTHours",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxOTHours.setDefaultUnit(kony.flex.DP);
            var lblOIIOTHours = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblOIIOTHours",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "OII OT Hrs",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtOIIOTHoursValue = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTbxBorder25PrcntWhiteBgFont100",
                "height": "70%",
                "id": "txtOIIOTHoursValue",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "maxTextLength": null,
                "right": "5%",
                "secureTextEntry": false,
                "skin": "sknTbxBorder25PrcntWhiteBgFont100",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_NUMERIC,
                "width": "20%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxOTHours.add(lblOIIOTHours, txtOIIOTHoursValue);
            var flxClientOTHours = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxClientOTHours",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxClientOTHours.setDefaultUnit(kony.flex.DP);
            var lblClientOTHours = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblClientOTHours",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Client OT Hrs",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtClientOTHoursValue = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTbxBorder25PrcntWhiteBgFont100",
                "height": "70%",
                "id": "txtClientOTHoursValue",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "maxTextLength": null,
                "right": "5%",
                "secureTextEntry": false,
                "skin": "sknTbxBorder25PrcntWhiteBgFont100",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_NUMERIC,
                "width": "20%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxClientOTHours.add(lblClientOTHours, txtClientOTHoursValue);
            var flxHourlyRate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxHourlyRate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHourlyRate.setDefaultUnit(kony.flex.DP);
            var lblHourlyRate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblHourlyRate",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Hourly Rate",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblHourlyRateValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblHourlyRateValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxHourlyRate.add(lblHourlyRate, lblHourlyRateValue);
            var flxStandbyRate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxStandbyRate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxStandbyRate.setDefaultUnit(kony.flex.DP);
            var lblStandbyRate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblStandbyRate",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Standby Rate",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblStandbyRateValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblStandbyRateValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxStandbyRate.add(lblStandbyRate, lblStandbyRateValue);
            var flxNonDiveRate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxNonDiveRate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxNonDiveRate.setDefaultUnit(kony.flex.DP);
            var lblNonDiveRate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNonDiveRate",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Non-Dive Rate",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblNonDiveRateValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNonDiveRateValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxNonDiveRate.add(lblNonDiveRate, lblNonDiveRateValue);
            var flxInTransit = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxInTransit",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxInTransit.setDefaultUnit(kony.flex.DP);
            var lblInTransit = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblInTransit",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "In-Transit",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var flxInTransitValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "80%",
                "id": "flxInTransitValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5%",
                "skin": "slFbox",
                "width": "10%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxInTransitValue.setDefaultUnit(kony.flex.DP);
            var imgInTransitValue = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgInTransitValue",
                "isVisible": true,
                "skin": "slImage",
                "src": "checkbox_inactive.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInTransitValue.add(imgInTransitValue);
            flxInTransit.add(lblInTransit, flxInTransitValue);
            var flxArrivalDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxArrivalDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxArrivalDate.setDefaultUnit(kony.flex.DP);
            var lblArrivalDate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblArrivalDate",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Arrival Date",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblArrivalDateValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblArrivalDateValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxArrivalDate.add(lblArrivalDate, lblArrivalDateValue);
            var flxDepartDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxDepartDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxDepartDate.setDefaultUnit(kony.flex.DP);
            var lblDepartDate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDepartDate",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Depart Date",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblDepartDateValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDepartDateValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxDepartDate.add(lblDepartDate, lblDepartDateValue);
            flxPersonnelDetailsBody.add(flxName, flxEmployeeID, flxJobPosition, flxCrewPosition, flxTRC, flxDepth, flxUOM, flxNormalHours, flxBillingHours, flxStandbyHours, flxOTHours, flxClientOTHours, flxHourlyRate, flxStandbyRate, flxNonDiveRate, flxInTransit, flxArrivalDate, flxDepartDate);
            var flxPersonnelDetailsHorizontalLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxPersonnelDetailsHorizontalLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxDBDBDBOp100",
                "top": "2%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxPersonnelDetailsHorizontalLine.setDefaultUnit(kony.flex.DP);
            flxPersonnelDetailsHorizontalLine.add();
            var btnSave = new kony.ui.Button({
                "centerX": "50%",
                "focusSkin": "defBtnFocus",
                "height": "6.50%",
                "id": "btnSave",
                "isVisible": true,
                "skin": "sknBtn7099b1FontFFFFFF",
                "text": "Save",
                "top": "2%",
                "width": "40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxEmptySpace = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1.50%",
                "id": "flxEmptySpace",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxOp0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxEmptySpace.setDefaultUnit(kony.flex.DP);
            flxEmptySpace.add();
            flxBody.add(flxProjectHeader, flxProjectDetailsBody, flxProjectDetailsHorizontalLine, flxCrewHeader, segCrewDetails, flxCrewDetailsHorizontalLine, flxPersonnelHeader, flxPersonnelDetailsBody, flxPersonnelDetailsHorizontalLine, btnSave, flxEmptySpace);
            var flxHeaderShadow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "3dp",
                "id": "flxHeaderShadow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxMultiGradientBlackShadow",
                "top": "6.80%",
                "width": "100%",
                "zIndex": 2
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHeaderShadow.setDefaultUnit(kony.flex.DP);
            flxHeaderShadow.add();
            var flxPopups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxPopups",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_ca8aca278a854821954ad6cb1f7e5c95,
                "skin": "sknFlx000000Op60",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxPopups.setDefaultUnit(kony.flex.DP);
            var flxTRCPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "55%",
                "id": "flxTRCPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_h35d6572c0734735a32a3eeaa7b4b0a9,
                "skin": "sknFlxBgOp0BorderOp0S1pRounded",
                "width": "65%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxTRCPopup.setDefaultUnit(kony.flex.DP);
            var flxTRCPopupHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "11%",
                "id": "flxTRCPopupHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlx003C5COp100",
                "top": "0%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxTRCPopupHeader.setDefaultUnit(kony.flex.DP);
            var lblTRCPopupTitle = new kony.ui.Label({
                "bottom": "25%",
                "id": "lblTRCPopupTitle",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLblFontFFFFFFOp100S120Prc",
                "text": "Select TRC",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var flxDoneTRCPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxDoneTRCPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_j43dd2a8067e44ba97b54785aa4d9abe,
                "right": "5%",
                "skin": "slFbox",
                "width": "20%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxDoneTRCPopup.setDefaultUnit(kony.flex.DP);
            var lblDoneTRCPopup = new kony.ui.Label({
                "bottom": "23%",
                "id": "lblDoneTRCPopup",
                "isVisible": true,
                "right": "0%",
                "skin": "sknLblDBD9DBOp00S90",
                "text": "Done",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxDoneTRCPopup.add(lblDoneTRCPopup);
            flxTRCPopupHeader.add(lblTRCPopupTitle, flxDoneTRCPopup);
            var flxTRCPopupBody = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": false,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "89%",
                "horizontalScrollIndicator": true,
                "id": "flxTRCPopupBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFlxScrllBgFFFFFFOp100",
                "top": "11%",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxTRCPopupBody.setDefaultUnit(kony.flex.DP);
            var chxkbxTRCList = new kony.ui.CheckBoxGroup({
                "centerX": "50%",
                "id": "chxkbxTRCList",
                "isVisible": true,
                "skin": "sknCheckBoxFont333333Op100S90Perc",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "itemOrientation": constants.CHECKBOX_ITEM_ORIENTATION_VERTICAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTRCPopupBody.add(chxkbxTRCList);
            flxTRCPopup.add(flxTRCPopupHeader, flxTRCPopupBody);
            flxPopups.add(flxTRCPopup);
            flxMain.add(flxHeader, flxBody, flxHeaderShadow, flxPopups);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlx000000Op40",
                "width": "100%",
                "zIndex": 15
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "10%",
                "id": "imgLoading",
                "isVisible": true,
                "skin": "slImage",
                "src": "loading.gif",
                "width": "30%",
                "zIndex": 15
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoading.add(imgLoading);
            this.add(flxMain, flxLoading);
        };
        return [{
            "addWidgets": addWidgetsfrmCreateDPR,
            "enabledForIdleTimeout": false,
            "id": "frmCreateDPR",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmFFD80FOp100"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});