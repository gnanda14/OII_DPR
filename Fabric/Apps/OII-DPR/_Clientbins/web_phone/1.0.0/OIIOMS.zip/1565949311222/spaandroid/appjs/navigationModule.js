define({
    /**
     * @desc Used to navigate to the Login screen
     * @param <any> params - Context data to be passed to the login screen
     * @retun void
     */
    navigateToFrmLogin: function(params) {
        var frmLoginNavigationObj = new kony.mvc.Navigation("frmLogin");
        frmLoginNavigationObj.navigate(params);
    },
    /**
     * @desc Used to navigate to the dashboard screen
     * @param <any> params - Context data to be passed to the dashboard screen
     * @retun void
     */
    navigateToFrmDashboard: function(params) {
        var frmDashboardNavigationObj = new kony.mvc.Navigation("frmDashboard");
        frmDashboardNavigationObj.navigate(params);
    },
    /**
     * @desc Used to navigate to the history screen
     * @param <any> params - Context data to be passed to the history screen
     * @retun void
     */
    navigateToFrmHistory: function(params) {
        var frmHistoryNavigationObj = new kony.mvc.Navigation("frmHistory");
        frmHistoryNavigationObj.navigate(params);
    },
    /**
     * @desc Used to navigate to the DPRInfo screen
     * @param <any> params - Context data to be passed to the DPRInfo screen
     * @retun void
     */
    navigateToFrmDPRInfo: function(params) {
        var frmDPRInfoNavigationObj = new kony.mvc.Navigation("frmDPRInfo");
        frmDPRInfoNavigationObj.navigate(params);
    },
    /**
     * @desc Used to navigate to the createDPR screen
     * @param <any> params - Context data to be passed to the createDPR screen
     * @retun void
     */
    navigateToFrmCreateDPR: function(params) {
        var frmCreateDPRNavigationObj = new kony.mvc.Navigation("frmCreateDPR");
        frmCreateDPRNavigationObj.navigate(params);
    },
    /**
     * @desc Used to navigate to the createDPR screen
     * @param <any> params - Context data to be passed to the createDPR screen
     * @retun void
     */
    navigateToFrmAddCrew: function(params) {
        var frmCreateDPRNavigationObj = new kony.mvc.Navigation("frmAddCrew");
        frmCreateDPRNavigationObj.navigate(params);
    }
});