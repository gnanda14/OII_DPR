define({
    /**
     * @desc Validates if a variable is empty or not
     * @param <Any> param - Variable to be validated
     * @retun Boolean
     */
    checkIfEmpty: function(value) {
        if (value === undefined || value === null) {
            return true;
        } else {
            if (value.constructor === Object && Object.keys(value).length <= 0) {
                return true;
            } else if (value.constructor === Array && value.length <= 0) {
                return true;
            } else if (value.constructor === String && (value === "null" || value === "NULL" || value === "Null" || value.trim() === "" || (value.trim()).length <= 0)) {
                return true;
            }
        }
        return false;
    },
    /**
     * @desc Validates if a String is empty or not
     * @param String param - String to be validated
     * @retun Boolean
     */
    validateEmptyString: function(param) {
        if (param === undefined || param === null) {
            return true;
        }
        param = param.trim();
        if (param === "") {
            return true;
        }
        return false;
    },
    /**
     * @desc Validates emails id
     * @param String param - Contains the email id to be validated
     * @retun Boolean
     */
    validateEmail: function(param) {
        var emailReg = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
        if (param === undefined || param === null) {
            return false;
        }
        param = param.trim();
        if (param === "") return false;
        if (emailReg.test(param) === false) {
            return false;
        }
        return true;
    },
    /**
     * @desc Validates mobile number
     * @param String param - Contains the mobile number to be validated
     * @retun Boolean
     */
    validateMobileNumber: function(param) {
        var mobReg = /^(\+)(\d{1,3})(\d{10})$/;
        if (param === undefined || param === null) {
            return false;
        }
        param = param.trim();
        if (param === "") return false;
        if (emailReg.test(param) === false) {
            return false;
        }
        return true;
    },
    /**
     * @desc Empty function
     * @param -
     * @retun void
     */
    doNothing: function() {
        //DoNothing
    }
});