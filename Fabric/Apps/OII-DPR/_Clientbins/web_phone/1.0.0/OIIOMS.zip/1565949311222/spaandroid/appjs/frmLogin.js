define("frmLogin", function() {
    return function(controller) {
        function addWidgetsfrmLogin() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxSimple",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var imgLoginBackground = new kony.ui.Image2({
                "height": "100%",
                "id": "imgLoginBackground",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "logingif.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLoginHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "25%",
                "id": "flxLoginHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "23.50%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxLoginHeader.setDefaultUnit(kony.flex.DP);
            var imgOceanneringLogo = new kony.ui.Image2({
                "centerX": "51%",
                "height": "35dp",
                "id": "imgOceanneringLogo",
                "isVisible": true,
                "skin": "slImage",
                "src": "oceaneering_logo_white.png",
                "top": "11%",
                "width": "150dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOMS = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblOMS",
                "isVisible": true,
                "left": "161dp",
                "skin": "sknLblffffffFont300Bold",
                "text": "OMS",
                "textStyle": {},
                "top": "4%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblOMSFullForm = new kony.ui.Label({
                "centerX": "51%",
                "id": "lblOMSFullForm",
                "isVisible": true,
                "left": "161dp",
                "skin": "sknLblffffffFont120",
                "text": "OFFSHORE MANAGEMENT SYSTEM",
                "textStyle": {},
                "top": "5%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxLoginHeader.add(imgOceanneringLogo, lblOMS, lblOMSFullForm);
            var flxLoginMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "52%",
                "id": "flxLoginMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxSimple",
                "top": "48%",
                "width": "100%",
                "zIndex": 5
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxLoginMain.setDefaultUnit(kony.flex.DP);
            var flxLoginErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "10%",
                "id": "flxLoginErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxfafafaop15",
                "top": "0%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxLoginErrorMessage.setDefaultUnit(kony.flex.DP);
            var lblLoginErrorMessage = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblLoginErrorMessage",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblFontF71E1EOp100S100p",
                "text": "Error",
                "textStyle": {},
                "top": "0%",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxLoginErrorMessage.add(lblLoginErrorMessage);
            var flxEmail = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "17%",
                "id": "flxEmail",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1%",
                "width": "100%",
                "zIndex": 2
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxEmail.setDefaultUnit(kony.flex.DP);
            var flxEmailUnderline = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "3%",
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxEmailUnderline",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxBorderffffff",
                "width": "80%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxEmailUnderline.setDefaultUnit(kony.flex.DP);
            flxEmailUnderline.add();
            var txtLoginEmail = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "bottom": "4%",
                "centerX": "50%",
                "focusSkin": "sknTxtBoxFocusLogin",
                "height": "45dp",
                "id": "txtLoginEmail",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "onTouchStart": controller.AS_TextField_e1a703e44fea4108a57a9b57176ca56e,
                "placeholder": "Username",
                "secureTextEntry": false,
                "skin": "sknTxtLoginFont110White",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "80%",
                "zIndex": 3
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "sknTxtBoxPlaceHolder"
            });
            flxEmail.add(flxEmailUnderline, txtLoginEmail);
            var flxPassword = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "17%",
                "id": "flxPassword",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1%",
                "width": "100%",
                "zIndex": 2
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxPassword.setDefaultUnit(kony.flex.DP);
            var flxPasswordUnderline = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "3%",
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxPasswordUnderline",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxBorderffffff",
                "width": "80%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxPasswordUnderline.setDefaultUnit(kony.flex.DP);
            flxPasswordUnderline.add();
            var txtLoginPassword = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "bottom": "4%",
                "centerX": "50%",
                "focusSkin": "sknTxtBoxFocusLogin",
                "height": "45dp",
                "id": "txtLoginPassword",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "onTouchStart": controller.AS_TextField_db33701f1ee34a2f9dac5b9f90eac469,
                "placeholder": "Password",
                "secureTextEntry": true,
                "skin": "sknTxtLoginFont110White",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "80%",
                "zIndex": 3
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "sknTxtBoxPlaceHolder"
            });
            flxPassword.add(flxPasswordUnderline, txtLoginPassword);
            var flxLoginEssentials = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15%",
                "id": "flxLoginEssentials",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxLoginEssentials.setDefaultUnit(kony.flex.DP);
            var lblRememberMe = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblRememberMe",
                "isVisible": true,
                "left": "10%",
                "skin": "sknLblFFFFFFOp100S100",
                "text": "Remember Me",
                "textStyle": {},
                "top": "17dp",
                "width": "27%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblForgotPassword = new kony.ui.Label({
                "centerY": "50.00%",
                "height": "100%",
                "id": "lblForgotPassword",
                "isVisible": true,
                "onTouchEnd": controller.AS_Label_d47af1d103f04022b3b18a7e24037f31,
                "right": "10.00%",
                "skin": "sknLblFFFFFFOp100S100",
                "text": "Forgot Password ?",
                "textStyle": {},
                "top": "3dp",
                "width": "40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var imgRememberMe = new kony.ui.Image2({
                "centerY": "50%",
                "height": "100%",
                "id": "imgRememberMe",
                "isVisible": true,
                "left": "37%",
                "onTouchEnd": controller.AS_Image_c97810d652f44479800281346a49fa74,
                "skin": "slImage",
                "src": "switch_on.png",
                "top": "15dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoginEssentials.add(lblRememberMe, lblForgotPassword, imgRememberMe);
            var btnLogin = new kony.ui.Button({
                "centerX": "50%",
                "focusSkin": "sknBtnLoginFocus",
                "height": "40dp",
                "id": "btnLogin",
                "isVisible": true,
                "left": "66dp",
                "onClick": controller.AS_Button_j0034e4a3e67492682c236b52e5a2929,
                "skin": "sknBtnLogin",
                "text": "Sign In",
                "top": "11%",
                "width": "58%",
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoginMain.add(flxLoginErrorMessage, flxEmail, flxPassword, flxLoginEssentials, btnLogin);
            var flxTouchId = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "7%",
                "id": "flxTouchId",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "17.33%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_f1fb49e8e2b849d4ae1a34200be09d1c,
                "skin": "sknFlxBg000000Op0",
                "top": "93%",
                "width": "65.34%",
                "zIndex": 1
            }, {}, {});
            flxTouchId.setDefaultUnit(kony.flex.DP);
            var imgTouchId = new kony.ui.Image2({
                "centerY": "50%",
                "height": "31.10%",
                "id": "imgTouchId",
                "isVisible": true,
                "left": "8.29%",
                "skin": "slImage",
                "src": "touchid.png",
                "width": "8.16%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTouchId = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblTouchId",
                "isVisible": true,
                "left": "18%",
                "skin": "sknLblFontFFFFFFFOp100S100p",
                "text": "Sign in with Touch Id/Face Id",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxTouchId.add(imgTouchId, lblTouchId);
            flxMain.add(imgLoginBackground, flxLoginHeader, flxLoginMain, flxTouchId);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlx000000Op40",
                "width": "100%",
                "zIndex": 15
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "10%",
                "id": "imgLoading",
                "isVisible": true,
                "skin": "slImage",
                "src": "loading.gif",
                "width": "30%",
                "zIndex": 15
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoading.add(imgLoading);
            var flxPopupMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxPopupMain",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_fd62abec2da746e6ae1e839c831dc0d0,
                "skin": "sknFlxBg000000Op60",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {}, {});
            flxPopupMain.setDefaultUnit(kony.flex.DP);
            var flxGenericErrorPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "12%",
                "id": "flxGenericErrorPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxBgE24848Op100",
                "width": "92%",
                "zIndex": 3
            }, {}, {});
            flxGenericErrorPopup.setDefaultUnit(kony.flex.DP);
            var lblGenericErrorMessage = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblGenericErrorMessage",
                "isVisible": true,
                "skin": "sknLblFontFFFFFFOp100S100p",
                "text": "No internet connection. Please try again when internet is available.",
                "textStyle": {},
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxGenericErrorPopup.add(lblGenericErrorMessage);
            var flxEnableTouchIdPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "40%",
                "id": "flxEnableTouchIdPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFOp100",
                "width": "90%",
                "zIndex": 3
            }, {}, {});
            flxEnableTouchIdPopup.setDefaultUnit(kony.flex.DP);
            var flxEnableTouchIdTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "24%",
                "id": "flxEnableTouchIdTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBg000000Op0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxEnableTouchIdTitle.setDefaultUnit(kony.flex.DP);
            var lblEnableTouchIdTitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblEnableTouchIdTitle",
                "isVisible": true,
                "skin": "sknLblFont424242Op100S140p",
                "text": "Touch ID/Face ID Authentication",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxEnableTouchIdTitle.add(lblEnableTouchIdTitle);
            var flxEnableTouchIdLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxEnableTouchIdLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBg000000Op100",
                "top": "24%",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxEnableTouchIdLine.setDefaultUnit(kony.flex.DP);
            flxEnableTouchIdLine.add();
            var imgEnableTouchIdPopup = new kony.ui.Image2({
                "centerX": "50%",
                "height": "20%",
                "id": "imgEnableTouchIdPopup",
                "isVisible": true,
                "skin": "slImage",
                "src": "touchid.png",
                "top": "32%",
                "width": "20%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEnableTouchIdMessage = new kony.ui.Label({
                "bottom": "30%",
                "centerX": "50%",
                "id": "lblEnableTouchIdMessage",
                "isVisible": true,
                "skin": "sknLblFont000000Op100S100p",
                "text": "Would you like to enable Touch ID/Face ID to login into the application?",
                "textStyle": {},
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var flxEnableTouchIdButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0%",
                "clipBounds": true,
                "height": "20%",
                "id": "flxEnableTouchIdButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBg000000Op0",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxEnableTouchIdButtons.setDefaultUnit(kony.flex.DP);
            var btnNotNow = new kony.ui.Button({
                "focusSkin": "sknBtnDB304DOp100FontFFFFFFOp100S100",
                "height": "100%",
                "id": "btnNotNow",
                "isVisible": true,
                "left": "0dp",
                "onClick": controller.AS_Button_b1ce2603377e447f829efc24c4681c5a,
                "skin": "sknBtnDB304DOp100FontFFFFFFOp100S100",
                "text": "Not Now",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnEnable = new kony.ui.Button({
                "focusSkin": "sknBtn2EA332Op100FontFFFFFFOp100S100",
                "height": "100%",
                "id": "btnEnable",
                "isVisible": true,
                "left": "50%",
                "onClick": controller.AS_Button_cd8aa97cf1d14ff7aa0bae2231e0b0d3,
                "skin": "sknBtn2EA332Op100FontFFFFFFOp100S100",
                "text": "Enable",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEnableTouchIdButtons.add(btnNotNow, btnEnable);
            flxEnableTouchIdPopup.add(flxEnableTouchIdTitle, flxEnableTouchIdLine, imgEnableTouchIdPopup, lblEnableTouchIdMessage, flxEnableTouchIdButtons);
            var flxAuthentiacteUsingTouchIdPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "30%",
                "id": "flxAuthentiacteUsingTouchIdPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "58dp",
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFOp100BorderFFFFFFS1pRounded",
                "width": "85%",
                "zIndex": 3
            }, {}, {});
            flxAuthentiacteUsingTouchIdPopup.setDefaultUnit(kony.flex.DP);
            var imgAuthUsingTouchID = new kony.ui.Image2({
                "centerX": "50%",
                "height": "17%",
                "id": "imgAuthUsingTouchID",
                "isVisible": true,
                "skin": "slImage",
                "src": "touchid.png",
                "top": "15%",
                "width": "20%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAuthUsingTouchIDHeader = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblAuthUsingTouchIDHeader",
                "isVisible": true,
                "skin": "sknLblFont110HelBold000",
                "text": "Touch ID/Face ID for \"OMS Application\"",
                "textStyle": {},
                "top": "40%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblAuthUsingTouchIdMessage = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblAuthUsingTouchIdMessage",
                "isVisible": true,
                "skin": "sknLblFont000000Op100S80p",
                "text": "Place your finger on the home button to Login in case of Touch ID",
                "textStyle": {},
                "top": "55%",
                "width": "92%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var flxAuthUsingTouchIdHorizontalLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAuthUsingTouchIdHorizontalLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBg000000Op0",
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxAuthUsingTouchIdHorizontalLine.setDefaultUnit(kony.flex.DP);
            flxAuthUsingTouchIdHorizontalLine.add();
            var btnCancelAuthUsingTouchId = new kony.ui.Button({
                "centerX": "50%",
                "centerY": "90%",
                "focusSkin": "sknBtnFFFFFFOp0Font1F4CADOp100S120",
                "height": "15%",
                "id": "btnCancelAuthUsingTouchId",
                "isVisible": true,
                "onClick": controller.AS_Button_abf6c8253e6c41a38a4f0b32a5e2c913,
                "skin": "sknBtnFFFFFFOp0Font1F4CADOp100S120",
                "text": "Cancel",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAuthentiacteUsingTouchIdPopup.add(imgAuthUsingTouchID, lblAuthUsingTouchIDHeader, lblAuthUsingTouchIdMessage, flxAuthUsingTouchIdHorizontalLine, btnCancelAuthUsingTouchId);
            flxPopupMain.add(flxGenericErrorPopup, flxEnableTouchIdPopup, flxAuthentiacteUsingTouchIdPopup);
            this.add(flxMain, flxLoading, flxPopupMain);
        };
        return [{
            "addWidgets": addWidgetsfrmLogin,
            "enabledForIdleTimeout": false,
            "id": "frmLogin",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_ge4b8c4d3d174e628e407608f790e3e9(eventobject);
            },
            "skin": "sknFrmBG051424"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});