define("userfrmAddCrewController", {
    projectId: "",
    onNavigate: function(selectedProjectId) {
        this.projectId = selectedProjectId;
        this.resetAddCrewForm();
    },
    getCrewPositions: function() {
        var integrationObj = oceaneering.oms.appGlobals.client.getIntegrationService("EncompassDB");
        var operationName = "dbo_crew_positions_get";
        var data = {
            "$filter": "departmentid eq '81050'"
        };
        var headers = {};
        integrationObj.invokeOperation(operationName, headers, data, this.successCallback_getCrewPositions.bind(this), this.errorCallback_getCrewPositions.bind(this));
    },
    successCallback_getCrewPositions: function(response) {
        var crewPositionData = [];
        var crewData;
        for (var i = 0; i < response.crew_positions.length; i++) {
            crewData = [];
            crewData[0] = response.crew_positions[i].id;
            crewData[1] = response.crew_positions[i].crewpositionname;
            crewPositionData.push(crewData);
        }
        this.view.lstBoxCrewPoistion.masterData = crewPositionData;
    },
    errorCallback_getCrewPositions: function(response) {
        alert("Error in getting crew position" + JSON.stringify(response));
    },
    // Show and Hide Search Results for Crew in Add Crew Form
    show_Hide_SearchCrewResults: function() {
        if (this.view.flxCrewResultShadow.isVisible == true) {
            this.view.flxCrewResultShadow.isVisible = false;
            this.view.flxSearchCrewResults.isVisible = false;
        } else {
            this.view.flxCrewResultShadow.isVisible = true;
            this.view.flxSearchCrewResults.isVisible = true;
        }
    },
    //On Selectioon of Crew from SegCrewSearchReults
    onSelectionOfCrew: function() {
        var selectedCrew = this.view.segCrewSearchResults.selectedRowItems[0].name;
        var jobCode = this.view.segCrewSearchResults.selectedRowItems[0].jobcode;
        this.view.txtCrewSearch.text = selectedCrew;
        this.view.lblNameValue.text = selectedCrew;
        this.view.lblEmpIDValue.text = this.view.segCrewSearchResults.selectedRowItems[0].employeeid;
        //callService to get employee Details of   Job Position and Crew Position
        this.showLoadingIndicator();
        var integrationObj = oceaneering.oms.appGlobals.client.getIntegrationService("EncompassDB");
        var operationName = "dbo_master_jobcode_get";
        var data = {
            "$filter": "jobcode eq '" + jobCode + "'"
        };
        var headers = {};
        integrationObj.invokeOperation(operationName, headers, data, this.successCallback_onSelectionOfCrew.bind(this), this.errorCallback_onSelectionOfCrew.bind(this));
    },
    successCallback_onSelectionOfCrew: function(response) {
        this.view.lblJobPositionValue.text = response.master_jobcode[0].title + "-" + response.master_jobcode[0].jobcode;
        this.dismissLoadingIndicator();
        this.show_Hide_SearchCrewResults();
    },
    errorCallback_onSelectionOfCrew: function(response) {
        this.dismissLoadingIndicator();
        this.show_Hide_SearchCrewResults();
        alert("Got error in onSelectionOfCrew" + JSON.stringify(response));
    },
    //Get Crew Results after user hits search button
    getSearchCrewResults: function(searchText) {
        this.showLoadingIndicator();
        var integrationObj = oceaneering.oms.appGlobals.client.getIntegrationService("EncompassDB");
        var operationName = "dbo_master_employee_get";
        var data = {
            "$filter": "substringof('name','" + searchText + "') eq true or  substringof('employeeid','" + searchText + "') eq true",
            "$orderby": "name"
        };
        var headers = {};
        integrationObj.invokeOperation(operationName, headers, data, this.successCallback_getSearchCrewResults.bind(this), this.errorCallback_getSearchCrewResults.bind(this));
    },
    successCallback_getSearchCrewResults: function(response) {
        this.view.segCrewSearchResults.widgetDataMap = {
            "lblCrewName": "name",
            "lblCrewEmployeeId": "employeeid"
        };
        if (response.master_employee.length > 0) {
            this.view.segCrewSearchResults.setData(response.master_employee);
            this.view.segCrewSearchResults.isVisible = true;
            this.view.flxNoReults.isVisible = false;
        } else {
            this.view.segCrewSearchResults.isVisible = false;
            this.view.flxNoReults.isVisible = true;
        }
        this.dismissLoadingIndicator();
        this.show_Hide_SearchCrewResults();
    },
    errorCallback_getSearchCrewResults: function(response) {
        this.dismissLoadingIndicator();
        alert("Got error in getSearchCrewResults " + JSON.stringify(response));
    },
    /**
     * @desc Reset all add crew data to empty
     * @param -
     * @retun void
     */
    resetAddCrewForm: function() {
        var currentDate = new Date();
        var date = currentDate.getDate();
        var month = currentDate.getMonth() + 1; //Be careful! January is 0 not 1
        var year = currentDate.getFullYear();
        this.view.lblNameValue.text = " ";
        this.view.lblEmpIDValue.text = " ";
        this.view.lstBoxCrewPoistion.selectedKey = null;
        this.view.lblJobPositionValue.text = " ";
        this.view.cldArrivalDate.dateComponents = [date, month, year, 0, 0, 0];
        this.view.cldDepartDate.dateComponents = [date, month, year, 0, 0, 0];
        this.view.txtOTRate.text = " ";
        this.view.txtDayHourRate.text = " ";
        this.view.txtStandByRate.text = " ";
        this.view.txtNonDiveRate.text = " ";
        this.view.txtCrewSearch.text = "";
    },
    /**
     * @desc Checks all the validation before adding crew
     * @param -
     * @retun void
     */
    onClickOfDone: function() {
        var commonUtils = require("commonUtils");
        if (this.view.lblEmpIDValue.text == " ") {
            alert("Please select crew");
            return;
        } else if (this.view.lstBoxCrewPoistion.selectedKeyValues == null) {
            alert("Please select crew position");
            return;
        }
        //check empty text box validations
        else if (commonUtils.validateEmptyString(this.view.txtOTRate.text) || commonUtils.validateEmptyString(this.view.txtDayHourRate.text) || commonUtils.validateEmptyString(this.view.txtStandByRate.text) || commonUtils.validateEmptyString(this.view.txtNonDiveRate.text)) {
            alert("Please enter value in all the text fields");
            return;
        } else {
            this.addCrew();
        }
    },
    /**
     * @desc Adds crew in Staging table
     * @param -
     * @retun void
     */
    addCrew: function() {
        this.showLoadingIndicator();
        var integrationObj = oceaneering.oms.appGlobals.client.getIntegrationService("StagingDB");
        var empName = this.view.lblNameValue.text;
        var empId = this.view.lblEmpIDValue.text;
        var currentDate = new Date();
        var createdDate = this.formatDate(currentDate);
        var selectedRole = "Crew";
        var crewPosition = this.view.lstBoxCrewPoistion.selectedKeyValue[1];
        var jobPosition = this.view.lblJobPositionValue.text;
        var arrivalDateCldComponents = this.view.cldArrivalDate.dateComponents;
        arrivalDateCldComponents[0] = arrivalDateCldComponents[0].toString();
        arrivalDateCldComponents[1] = arrivalDateCldComponents[1].toString();
        arrivalDateCldComponents[2] = arrivalDateCldComponents[2].toString();
        if (arrivalDateCldComponents[0].length < 2) arrivalDateCldComponents[0] = '0' + arrivalDateCldComponents[0];
        if (arrivalDateCldComponents[1].length < 2) arrivalDateCldComponents[1] = '0' + arrivalDateCldComponents[1];
        var arrivalDate = "" + arrivalDateCldComponents[2] + "-" + arrivalDateCldComponents[1] + "-" + arrivalDateCldComponents[0];
        var departDateComponents = this.view.cldDepartDate.dateComponents;
        departDateComponents[0] = departDateComponents[0].toString();
        departDateComponents[1] = departDateComponents[1].toString();
        departDateComponents[2] = departDateComponents[2].toString();
        if (departDateComponents[0].length < 2) departDateComponents[0] = '0' + departDateComponents[0];
        if (departDateComponents[1].length < 2) departDateComponents[1] = '0' + departDateComponents[1];
        var departDate = "" + departDateComponents[2] + "-" + departDateComponents[1] + "-" + departDateComponents[0];
        var otRate = this.view.txtOTRate.text;
        var dayHourRate = this.view.txtDayHourRate.text;
        var standByRate = this.view.txtStandByRate.text;
        var nonDiveRate = this.view.txtNonDiveRate.text;
        var createdBy = oceaneering.oms.appGlobals.username;
        var operationName = "dbo_crew_Info_create";
        var data = {
            "empId": empId,
            "selectedRole": selectedRole,
            "createdBy": createdBy,
            "createdDate": createdDate,
            "projectId": this.projectId,
            "empName": empName,
            "crewPosition": crewPosition,
            "jobPosition": jobPosition,
            "arrivalDate": arrivalDate,
            "departureDate": departDate,
            "dayRate": dayHourRate,
            "otRate": otRate,
            "standbyRate": standByRate,
            "nonDiveRate": nonDiveRate
        };
        var headers = {};
        integrationObj.invokeOperation(operationName, headers, data, this.operationSuccess_addCrew.bind(this), this.operationFailure_addCrew.bind(this));
    },
    operationSuccess_addCrew: function(res) {
        //code for success call back
        this.dismissLoadingIndicator();
        kony.print("@@@@@@@@@@@@@ Added Crew Successfully @@@@@@@@@@@@@@");
        alert("Added Crew Successfully");
        this.resetAddCrewForm();
    },
    operationFailure_addCrew: function(res) {
        this.dismissLoadingIndicator();
        alert("Error in adding crew.. " + JSON.stringify(res));
    },
    /**
     * @desc Blocks the screen and shows the loading screen
     * @param -
     * @retun void
     */
    showLoadingIndicator: function() {
        this.view.flxLoading.isVisible = true;
        this.view.flxMain.setEnabled(false);
        this.view.flxFooter.setEnabled(false);
    },
    /**
     * @desc enables the screen and hides the loading screen
     * @param -
     * @retun void
     */
    dismissLoadingIndicator: function() {
        this.view.flxLoading.isVisible = false;
        this.view.flxMain.setEnabled(true);
        this.view.flxFooter.setEnabled(true);
    },
    /**
     * @desc Formats a date object into a string in the format YYYY-MM-DD
     * @param Date date - Contains a date object of a date to be converted into string
     * @retun String - YYYY-MM-DD date
     */
    formatDate: function(date) {
        var month = '' + (date.getMonth() + 1),
            day = '' + date.getDate(),
            year = date.getFullYear();
        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;
        return year + "-" + month + "-" + day;
    },
});
define("frmAddCrewControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onTextChange defined for txtCrewSearch **/
    AS_TextField_b5934e09e8c2495982214c32d66236ed: function AS_TextField_b5934e09e8c2495982214c32d66236ed(eventobject, changedtext) {
        var self = this;
        if (this.view.txtCrewSearch.text.length == 0) {
            if (this.view.flxCrewResultShadow.isVisible == true) {
                this.view.flxCrewResultShadow.isVisible = false;
                this.view.flxSearchCrewResults.isVisible = false;
            }
        }
    },
    /** onDone defined for txtCrewSearch **/
    AS_TextField_g8dcdc6cfc1047c9854115e2d10018c8: function AS_TextField_g8dcdc6cfc1047c9854115e2d10018c8(eventobject, changedtext) {
        var self = this;
        if (this.view.txtCrewSearch.text.length > 2) this.getSearchCrewResults(this.view.txtCrewSearch.text);
        else alert("Please enter 3 or more characters to search");
    },
    /** onTouchEnd defined for imgSearch **/
    AS_Image_f907626f1834430d800029f10542038e: function AS_Image_f907626f1834430d800029f10542038e(eventobject, x, y) {
        var self = this;
        if (this.view.txtCrewSearch.text.length > 2) this.getSearchCrewResults(this.view.txtCrewSearch.text);
        else alert("Please enter 3 or more characters to search");
    },
    /** onRowClick defined for segCrewSearchResults **/
    AS_Segment_cca2434a6225480c9c5a9b37304f9ae3: function AS_Segment_cca2434a6225480c9c5a9b37304f9ae3(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.onSelectionOfCrew();
    },
    /** onClick defined for btnSave **/
    AS_Button_bbfe0e9f7f624efbb83e0fbac3940b3c: function AS_Button_bbfe0e9f7f624efbb83e0fbac3940b3c(eventobject) {
        var self = this;
        this.onClickOfDone();
    },
    /** onClick defined for btnCancel **/
    AS_Button_ada86f5c7d7b47ccb78f7f845221a3c6: function AS_Button_ada86f5c7d7b47ccb78f7f845221a3c6(eventobject) {
        var self = this;
        var navigationModule = require("navigationModule");
        navigationModule.navigateToFrmDashboard({});
    },
    /** postShow defined for frmAddCrew **/
    AS_Form_bc553483a1fb4f0f87cc6bc962dca138: function AS_Form_bc553483a1fb4f0f87cc6bc962dca138(eventobject) {
        var self = this;
        this.getCrewPositions();
    }
});
define("frmAddCrewController", ["userfrmAddCrewController", "frmAddCrewControllerActions"], function() {
    var controller = require("userfrmAddCrewController");
    var controllerActions = ["frmAddCrewControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
