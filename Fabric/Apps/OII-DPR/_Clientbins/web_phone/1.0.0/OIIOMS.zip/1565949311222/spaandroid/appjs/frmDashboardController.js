/**
 * @Description - Contains the functionality of the Dashboard Form
 * @author - Nakul Gupta
 */
define("userfrmDashboardController", {
    //Array of JSON - Contains a list of all the projects for the current employee
    projectList: [],
    //JS Module - Contains common functions used throughout the application
    CommonUtilsModule: null,
    //JS Module - Contains navigation functions used to move to other screens
    navigationModule: null,
    /**
     * @desc MVC navigation function
     * @param JSON data - contains the data received from other forms while navigating
     * @retun void
     */
    onNavigate: function(data) {
        this.dismissPopups();
        if (data.navigatingFrom == "Login" || data.loadProjects) {
            this.initializeJSModules();
        }
    },
    /**
     * @desc Initializes all the JS modules required in this form
     * @param -
     * @retun void
     */
    initializeJSModules: function() {
        this.showLoadingIndicator();
        this.CommonUtilsModule = require("commonUtils");
        this.navigationModule = require("navigationModule");
        this.resetDashboardScreen();
    },
    /**
     * @desc Resets Dashboard screen to initial settings
     * @param -
     * @retun void
     */
    resetDashboardScreen: function() {
        this.view.txtSearch.text = "";
        this.view.segProjects.isVisible = false;
        this.view.lblNoProjects.isVisible = false;
        this.view.flxHamburgerMenu.isVisible = false;
        this.view.flxHamburgerMenuInner.left = "-77.5%";
        this.view.segProjects.setEnabled(false);
        this.checkLocalAuth();
    },
    /**
     * @desc Checks whether the device has touch id/ face id or not
     * @param -
     * @retun void
     */
    checkLocalAuth: function() {
        var status = kony.localAuthentication.getStatusForAuthenticationMode(constants.LOCAL_AUTHENTICATION_MODE_TOUCH_ID);
        if (status == 5000) {
            this.showLocalAuth();
        } else {
            this.hideLocalAuth();
        }
    },
    /**
     * @desc Displays touch id/ face id option in the hamburger menu
     * @param -
     * @retun void
     */
    showLocalAuth: function() {
        this.view.flxTouchId.setEnabled(true);
        this.view.flxTouchId.isVisible = true;
        this.view.flxOptionsLine4.isVisible = true;
        this.setLocalAuth();
    },
    /**
     * @desc Sets user preference for touch id/ face id option in the hamburger menu
     * @param -
     * @retun void
     */
    setLocalAuth: function() {
        if (kony.store.getItem("TouchId") === 1) {
            this.view.imgTouchId.src = "switch_on.png";
        } else {
            this.view.imgTouchId.src = "switch_off.png";
        }
        this.getProjectList();
    },
    /**
     * @desc Hides touch id/ face id option in the hamburger menu
     * @param -
     * @retun void
     */
    hideLocalAuth: function() {
        this.view.flxTouchId.setEnabled(false);
        this.view.flxTouchId.isVisible = false;
        this.view.flxOptionsLine4.isVisible = false;
        this.getProjectList();
    },
    /**
     * @desc Calls a service to get the project list for the current employee
     * @param -
     * @retun void
     */
    getProjectList: function() {
        var integrationObj = oceaneering.oms.appGlobals.client.getIntegrationService("Projects");
        var operationName = "getProjects";
        var data = {
            "empId": oceaneering.oms.appGlobals.employeeId
        };
        var headers = {};
        integrationObj.invokeOperation(operationName, headers, data, this.successCallback_GetProjectList.bind(this), this.errorCallback_GetProjectList.bind(this));
    },
    /**
     * @desc Error callback of getProjects service call
     * @param JSON error - Contains the error message and error code of getProjects service call
     * @retun void
     */
    errorCallback_GetProjectList: function(error) {
        this.projectList = null;
        this.view.lblNoProjects.isVisible = true;
        this.showErrorMessage();
    },
    /**
     * @desc Success callback of getProjects service call
     * @param JSON response - Contains the project list for the current user
     * @retun void
     */
    successCallback_GetProjectList: function(response) {
        if (this.CommonUtilsModule.checkIfEmpty(response.projects)) {
            this.view.lblNoProjects.isVisible = true;
        } else {
            this.prepareProjectsData(response.projects);
        }
        this.dismissLoadingIndicator();
    },
    /**
     * @desc Prepares Project data to be displayed in the segment
     * @param Array of JSON projects - Contains the project list
     * @retun void
     */
    prepareProjectsData: function(projects) {
        var projectsData = [];
        for (var i = 0; i < projects.length; i++) {
            projectsData.push({
                "Project_Id": projects[i].projectId,
                "startdate": (projects[i].startdate).substring(0, 10),
                "enddate": (projects[i].enddate).substring(0, 10)
            });
        }
        this.projectList = projectsData;
        this.setProjectsToSegment(this.projectList);
    },
    /**
     * @desc Sets project list to the main segment
     * @param Array of JSON projects - Contains the project list to be set in the segment
     * @retun void
     */
    setProjectsToSegment: function(projects) {
        this.view.segProjects.widgetDataMap = {
            "lblProjectId": "Project_Id",
            "lblStartDate": "startdate",
            "lblEndDate": "enddate"
        };
        this.view.segProjects.setData(projects);
        this.view.segProjects.isVisible = true;
        this.view.segProjects.setEnabled(true);
    },
    /**
     * @desc Searches projects based on project id
     * @param -
     * @retun void
     */
    onSearchProjects: function() {
        var searchKeyword = this.view.txtSearch.text;
        var filteredProjects = (this.CommonUtilsModule.checkIfEmpty(searchKeyword)) ? this.projectList : this.projectList.filter(project => (project.projectId).toLowerCase().includes(searchKeyword.toLowerCase()));
        this.setProjectsToSegment(filteredProjects);
    },
    /**
     * @desc Switches touch id on or off in the hamburger menu
     * @param -
     * @retun void
     */
    toggleTouchId: function() {
        if (this.view.imgTouchId.src == "switch_off.png") {
            this.view.imgTouchId.src = "switch_on.png";
            kony.store.setItem("TouchId", 1);
        } else {
            this.view.imgTouchId.src = "switch_off.png";
            kony.store.setItem("TouchId", 0);
        }
    },
    /**
     * @desc Checks which way to animate hamburger menu
     * @param -
     * @retun void
     */
    toggleHamburgerMenu: function() {
        if (this.view.flxHamburgerMenuInner.left == "0%") {
            this.animateHamburgerMenu("-77.5%");
        } else {
            this.view.flxMain.setEnabled(false);
            this.view.flxHamburgerMenu.isVisible = true;
            this.view.flxHamburgerMenu.setEnabled(true);
            this.animateHamburgerMenu("0%");
        }
    },
    /**
     * @desc Animates the hamburger menu
     * @param String left - Contains the new left position of the hamburger menu
     * @retun void
     */
    animateHamburgerMenu: function(left) {
        var self = this;
        this.view.flxHamburgerMenuInner.animate(kony.ui.createAnimation({
            "100": {
                "left": left,
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 0.75
        }, {
            "animationEnd": self.onHamburgerMenuAnimationEnd.bind(self)
        });
    },
    /**
     * @desc Called when the hamburger menu animation is complete
     * @param -
     * @retun void
     */
    onHamburgerMenuAnimationEnd: function() {
        if (this.view.flxHamburgerMenuInner.left == "-77.5%") {
            this.view.flxMain.setEnabled(true);
            this.view.flxHamburgerMenu.isVisible = false;
            this.view.flxHamburgerMenu.setEnabled(false);
        }
    },
    /**
     * @desc Called when a segment row is selected
     * @param -
     * @retun void
     */
    onSelectingProject: function() {
        this.showLoadingIndicator();
        var projectData = this.view.segProjects.selectedRowItems[0];
        this.view.flxCrew.onClick = this.onClickOfRole.bind(this, "Crew", projectData);
        this.view.flxSupervisor.onClick = this.onClickOfRole.bind(this, "Supervisor", projectData);
        this.checkIfRoleAlreadyExists(projectData);
    },
    /**
     * @desc Calls a service to Staging DB to check whether a role for the selected project already exists or not
     * @param JSON projectData - Contains the project info of the selected project
     * @retun void
     */
    checkIfRoleAlreadyExists: function(projectData) {
        var integrationObj = oceaneering.oms.appGlobals.client.getIntegrationService("StagingDB");
        var operationName = "dbo_crew_Info_get";
        var data = {
            "$filter": "empId eq " + oceaneering.oms.appGlobals.employeeId + " and projectId eq " + projectData.Project_Id
        };
        var headers = {};
        integrationObj.invokeOperation(operationName, headers, data, this.successCallback_CheckRole.bind(this, projectData), this.errorCallback.bind(this));
    },
    /**
     * @desc Success callback of check role service
     * @param JSON projectData - Contains the project info of the selected project
     * @param JSON response - Contains the role of the employee for the selected project
     * @retun void
     */
    successCallback_CheckRole: function(projectData, response) {
        this.dismissLoadingIndicator();
        if (this.CommonUtilsModule.checkIfEmpty(response.crew_Info)) {
            this.showPopup(this.view.flxCrewOrSupervisor);
        } else {
            this.checkRoleAndNavigate({
                "role": (response.crew_Info)[0].selectedRole,
                "projectData": projectData
            });
        }
    },
    /**
     * @desc Called when the user selects a role
     * @param String role - role selected by the user for the selected project
     * @param JSON projectData - Contains the project info of the selected project
     * @retun void
     */
    onClickOfRole: function(role, projectData) {
        this.showLoadingIndicator();
        var roleData = {
            "empId": oceaneering.oms.appGlobals.employeeId,
            "empName": oceaneering.oms.appGlobals.employeeFullName,
            "selectedRole": role,
            "createdBy": oceaneering.oms.appGlobals.username,
            "projectId": projectData.Project_Id,
            "createdDate": this.formatDate(new Date())
        };
        this.addRoleDataToStagingDB(roleData, projectData);
    },
    /**
     * @desc Calls a service to add user role to Staging DB
     * @param JSON roleData - Contains data required to add role in DB
     * @param JSON projectData - Contains the project info of the selected project
     * @retun void
     */
    addRoleDataToStagingDB: function(roleData, projectData) {
        var integrationObj = oceaneering.oms.appGlobals.client.getIntegrationService("StagingDB");
        var operationName = "dbo_crew_Info_create";
        var headers = {};
        integrationObj.invokeOperation(operationName, headers, roleData, this.successCallback_AddRole.bind(this, roleData.selectedRole, projectData), this.errorCallback.bind(this));
    },
    /**
     * @desc Success callback for add user role service
     * @param String role - role selected by the user for the selected project
     * @param JSON projectData - Contains the project info of the selected project
     * @param JSON response - Contains the success response of add role service
     * @retun void
     */
    successCallback_AddRole: function(role, projectData, response) {
        this.dismissLoadingIndicator();
        this.checkRoleAndNavigate({
            "role": role,
            "projectData": projectData
        });
    },
    /**
     * @desc Commom error callback for service calls
     * @param JSON error - Contains the error message and error code of service call
     * @retun void
     */
    errorCallback: function(error) {
        this.showErrorMessage();
    },
    checkRoleAndNavigate: function(data) {
        if (data.role == "Crew") {
            this.navigationModule.navigateToFrmCreateDPR({
                "projectData": data.projectData,
                "navigatingFrom": "Dashboard"
            });
        } else if (data.role == "Supervisor") {
            this.navigationModule.navigateToFrmDPRInfo({
                "projectData": data.projectData,
                "navigatingFrom": "Dashboard"
            });
        }
    },
    /**
     * @desc Called on click of FAB to add a new project
     * @param -
     * @retun void
     */
    onClickOfFAB: function() {
        this.showPopup(this.view.flxAddProject);
    },
    /**
     * @desc Navigates to DPR History screen
     * @param -
     * @retun void
     */
    onClickOfDPRHistory: function() {
        this.view.flxHamburgerMenu.isVisible = false;
        this.view.flxHamburgerMenu.setEnabled(false);
        this.view.flxHamburgerMenuInner.left = "-77.5%";
        this.view.flxMain.setEnabled(true);
        this.navigationModule.navigateToFrmHistory(null);
    },
    /**
     * @desc Called on click of add project button
     * @param -
     * @retun void
     */
    onClickOfAddProject: function() {
        this.showLoadingIndicator();
        var projectID = this.view.txtAddProject.text;
        if (!this.CommonUtilsModule.checkIfEmpty(projectID)) {
            this.checkIfProjectAlreadyInList(projectID);
        } else {
            this.dismissLoadingIndicator();
            alert("Project ID cannot be empty. Please try again.");
        }
    },
    /**
     * @desc Checks if the project id is already present in the project list
     * @param String projectID - Contains the new project id
     * @retun void
     */
    checkIfProjectAlreadyInList: function(projectID) {
        var filteredProjects = this.projectList.filter(project => (project.projectId) == projectID);
        if (this.CommonUtilsModule.checkIfEmpty(filteredProjects)) {
            this.validateProjectID(projectID);
        } else {
            this.dismissLoadingIndicator();
            alert("This Project ID already exists.");
        }
    },
    /**
     * @desc Calls a service to check if the new project id is valide or not
     * @param String projectID - Contains the new project id
     * @retun void
     */
    validateProjectID: function(projectID) {
        var integrationObj = oceaneering.oms.appGlobals.client.getIntegrationService("Projects");
        var operationName = "validateProject";
        var data = {
            "projectId": projectID
        };
        var headers = {};
        integrationObj.invokeOperation(operationName, headers, data, this.successCallback_ValidateProjectID.bind(this), this.errorCallback_ValidateProjectID.bind(this));
    },
    /**
     * @desc Success Callback for validate project id service
     * @param JSON response - Contains the new project info
     * @retun void
     */
    successCallback_ValidateProjectID: function(response) {
        if (response.hasOwnProperty("project")) {
            this.prepareProjectData(response.project);
        } else {
            this.dismissLoadingIndicator();
            alert("Invalid Project ID. Please try again later.");
        }
    },
    /**
     * @desc Prepares the data required to add a new project into DB
     * @param JSON projectInfo - Contains all the data of the new project
     * @retun void
     */
    prepareProjectData: function(projectInfo) {
        var projectData = {
            "Project_Id": projectInfo.projectId,
            "CreatedBy": oceaneering.oms.appGlobals.username,
            "DESCR": projectInfo.description,
            "Start_Date": (projectInfo.startdate).substring(0, 10),
            "End_date": (projectInfo.enddate).substring(0, 10),
            "Report_Date": null,
            "Location": projectInfo.location,
            "Country": projectInfo.country,
            "Manager": projectInfo.manager
        };
        this.addProjectInfoToStagingDB(projectData);
    },
    /**
     * @desc calls a service to add project info service into Staging DB
     * @param JSON projectData - Contains the data required to add a new project into DB
     * @retun void
     */
    addProjectInfoToStagingDB: function(projectData) {
        var integrationObj = oceaneering.oms.appGlobals.client.getIntegrationService("StagingDB");
        var operationName = "dbo_Project_Info_create";
        var headers = {};
        integrationObj.invokeOperation(operationName, headers, projectData, this.successCallback_AddProjectInfo.bind(this), this.errorCallback_AddProjectInfo.bind(this));
    },
    /**
     * @desc Success callback of add project info service
     * @param JSON response - Contains the new projects info
     * @retun void
     */
    successCallback_AddProjectInfo: function(response) {
        this.dismissLoadingIndicator();
        var projectData = response.Project_Info[0];
        this.view.flxCrew.onClick = this.onClickOfRole.bind(this, "Crew", projectData);
        this.view.flxSupervisor.onClick = this.onClickOfRole.bind(this, "Supervisor", projectData);
        this.moveToRolePopup();
    },
    /**
     * @desc Hides add project popup and shows crew/supervisor popup
     * @param -
     * @retun void
     */
    moveToRolePopup: function() {
        this.view.flxAddProject.isVisible = false;
        this.view.flxAddProject.setEnabled(false);
        this.view.flxCrewOrSupervisor.isVisible = true;
        this.view.flxCrewOrSupervisor.setEnabled(true);
    },
    /**
     * @desc Error callback of add project info service
     * @param JSON error - Contains the error message and error code of getProjects service call
     * @retun void
     */
    errorCallback_AddProjectInfo: function(error) {
        this.dismissLoadingIndicator();
        alert("Unable to add project at the moment. Please try again later.");
    },
    /**
     * @desc Error callback of validate project id service
     * @param JSON error - Contains the error message and error code of getProjects service call
     * @retun void
     */
    errorCallback_ValidateProjectID: function(error) {
        if (error.opstatus == 8005 && error.errmsg == "empty response received") {
            this.dismissLoadingIndicator();
            alert("Invalid Project ID. Please try again.");
        } else {
            this.showErrorMessage();
        }
    },
    /**
     * @desc Formats a date object into a string in the format YYYY-MM-DD
     * @param Date date - Contains a date object of a date to be converted into string
     * @retun String - YYYY-MM-DD date
     */
    formatDate: function(date) {
        var month = '' + (date.getMonth() + 1),
            day = '' + date.getDate(),
            year = date.getFullYear();
        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;
        return year + "-" + month + "-" + day;
    },
    /**
     * @desc Called on click of logout in the hamburger menu
     * @param -
     * @retun void
     */
    onClickOfLogout: function() {
        this.navigationModule.navigateToFrmLogin(null);
    },
    /**
     * @desc Shows the common error message
     * @param -
     * @retun void
     */
    showErrorMessage: function() {
        this.dismissLoadingIndicator();
        alert("Sorry, something went wrong. Please try again later.");
    },
    /**
     * @desc Blocks the screen and shows the loading screen
     * @param -
     * @retun void
     */
    showLoadingIndicator: function() {
        this.view.flxLoading.isVisible = true;
        this.view.flxMain.setEnabled(false);
        this.view.flxHamburgerMenu.setEnabled(false);
    },
    /**
     * @desc enables the screen and hides the loading screen
     * @param -
     * @retun void
     */
    dismissLoadingIndicator: function() {
        this.view.flxLoading.isVisible = false;
        this.view.flxMain.setEnabled(true);
        if (this.view.flxHamburgerMenu.isVisible === true) {
            this.view.flxHamburgerMenu.setEnabled(true);
        }
    },
    /**
     * @desc Hides all the popups from the screen
     * @param -
     * @retun void
     */
    dismissPopups: function() {
        this.view.flxHeader.setEnabled(true);
        this.view.flxBody.setEnabled(true);
        this.view.flxFAB.setEnabled(true);
        this.view.flxPopups.isVisible = false;
        this.view.flxPopups.setEnabled(false);
        this.view.flxCrewOrSupervisor.isVisible = false;
        this.view.flxAddProject.isVisible = false;
        this.view.flxCrewOrSupervisor.setEnabled(false);
        this.view.flxAddProject.setEnabled(false);
        this.view.txtAddProject.text = "";
    },
    /**
     * @desc shows the selected popup on the screen
     * @param Widet popupWidget - Contains the popup widget to be displayed
     * @retun void
     */
    showPopup: function(popupWidget) {
        this.view.flxHeader.setEnabled(false);
        this.view.flxBody.setEnabled(false);
        this.view.flxFAB.setEnabled(false);
        this.view.flxPopups.isVisible = true;
        this.view.flxPopups.setEnabled(true);
        popupWidget.isVisible = true;
        popupWidget.setEnabled(true);
    },
    /**
     * @desc Empty function. Does nothing
     * @param -
     * @retun void
     */
    doNothing: function() {
        //Empty Function
    }
});
define("frmDashboardControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxMenuIcon **/
    AS_FlexContainer_a8ce571fb0e94c1fb414de873388ca82: function AS_FlexContainer_a8ce571fb0e94c1fb414de873388ca82(eventobject) {
        var self = this;
        this.toggleHamburgerMenu();
    },
    /** onTextChange defined for txtSearch **/
    AS_TextField_bf023ff7acc842cc9b1e104d3fdedb53: function AS_TextField_bf023ff7acc842cc9b1e104d3fdedb53(eventobject, changedtext) {
        var self = this;
        this.onSearchProjects();
    },
    /** onClick defined for flxSearchIcon **/
    AS_FlexContainer_f5c064e09ef24eedb9b3a6d835d5022a: function AS_FlexContainer_f5c064e09ef24eedb9b3a6d835d5022a(eventobject) {
        var self = this;
        this.onSearchProjects();
    },
    /** onRowClick defined for segProjects **/
    AS_Segment_ga511155ad604eeebe1540fd74506714: function AS_Segment_ga511155ad604eeebe1540fd74506714(eventobject, sectionNumber, rowNumber) {
        var self = this;
        this.onSelectingProject();
    },
    /** onClick defined for flxFAB **/
    AS_FlexContainer_ec49ab7436df49d39a273de5152d814a: function AS_FlexContainer_ec49ab7436df49d39a273de5152d814a(eventobject) {
        var self = this;
        this.onClickOfFAB();
    },
    /** onClick defined for flxCloseCrewOrSupervisor **/
    AS_FlexContainer_b9cb194dba6049629da659c9dc65852c: function AS_FlexContainer_b9cb194dba6049629da659c9dc65852c(eventobject) {
        var self = this;
        this.dismissPopups();
    },
    /** onClick defined for flxCrewOrSupervisor **/
    AS_FlexContainer_gfa857301664420b810b7f70cab4c27e: function AS_FlexContainer_gfa857301664420b810b7f70cab4c27e(eventobject) {
        var self = this;
        this.doNothing();
    },
    /** onClick defined for flxCloseAddProject **/
    AS_FlexContainer_fd3876e0a83343c79acb1be3c68de597: function AS_FlexContainer_fd3876e0a83343c79acb1be3c68de597(eventobject) {
        var self = this;
        this.dismissPopups();
    },
    /** onClick defined for btnAddProject **/
    AS_Button_fb504bace2d24894bc4e3b967cc78c7a: function AS_Button_fb504bace2d24894bc4e3b967cc78c7a(eventobject) {
        var self = this;
        this.onClickOfAddProject();
    },
    /** onDone defined for txtAddProject **/
    AS_TextField_i8bd8292acf5409f8bddca42b1355a78: function AS_TextField_i8bd8292acf5409f8bddca42b1355a78(eventobject, changedtext) {
        var self = this;
        this.onClickOfAddProject();
    },
    /** onClick defined for flxAddProject **/
    AS_FlexContainer_fffe915d04f3437a9452ed2a081dfb3c: function AS_FlexContainer_fffe915d04f3437a9452ed2a081dfb3c(eventobject) {
        var self = this;
        this.doNothing();
    },
    /** onClick defined for flxPopups **/
    AS_FlexContainer_a174f978551643b0a3c04fc709ad4021: function AS_FlexContainer_a174f978551643b0a3c04fc709ad4021(eventobject) {
        var self = this;
        this.dismissPopups();
    },
    /** onClick defined for flxMenuBlankArea **/
    AS_FlexContainer_dd375a4776094b678494edf234281ace: function AS_FlexContainer_dd375a4776094b678494edf234281ace(eventobject) {
        var self = this;
        this.toggleHamburgerMenu();
    },
    /** onClick defined for flxHistory **/
    AS_FlexContainer_a6456668709348bc9ccdaef25ba4b0fd: function AS_FlexContainer_a6456668709348bc9ccdaef25ba4b0fd(eventobject) {
        var self = this;
        this.onClickOfDPRHistory();
    },
    /** onClick defined for flxTouchId **/
    AS_FlexContainer_b092eae1834c4cfb85b63dc349f550d3: function AS_FlexContainer_b092eae1834c4cfb85b63dc349f550d3(eventobject) {
        var self = this;
        this.toggleTouchId();
    },
    /** onClick defined for flxLogout **/
    AS_FlexContainer_ec7e8c069f204687a6032c2b2e7eeda4: function AS_FlexContainer_ec7e8c069f204687a6032c2b2e7eeda4(eventobject) {
        var self = this;
        this.onClickOfLogout();
    },
    /** onDeviceBack defined for frmDashboard **/
    AS_Form_ef289ae5e10a447a95e02479dbc89d4f: function AS_Form_ef289ae5e10a447a95e02479dbc89d4f(eventobject) {
        var self = this;
        this.doNothing();
    }
});
define("frmDashboardController", ["userfrmDashboardController", "frmDashboardControllerActions"], function() {
    var controller = require("userfrmDashboardController");
    var controllerActions = ["frmDashboardControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
