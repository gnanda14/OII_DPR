define("frmAddCrew", function() {
    return function(controller) {
        function addWidgetsfrmAddCrew() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxBgf0f0f0",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "7%",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlx003C5COp100",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var flxBack = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "52%",
                "clipBounds": true,
                "height": "35dp",
                "id": "flxBack",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "4%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "35dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxBack.setDefaultUnit(kony.flex.DP);
            var imgBack = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "60%",
                "id": "imgBack",
                "isVisible": true,
                "skin": "slImage",
                "src": "back_icon.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBack.add(imgBack);
            var lblTitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblTitle",
                "isVisible": true,
                "skin": "sknLblFFFFFFOp100S130",
                "text": "Add Crew",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var imgWhiteOceaneeringLogo = new kony.ui.Image2({
                "centerY": "49%",
                "height": "30dp",
                "id": "imgWhiteOceaneeringLogo",
                "isVisible": true,
                "right": "1%",
                "skin": "slImage",
                "src": "oceaneering_logo_white.png",
                "top": "6dp",
                "width": "90dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(flxBack, lblTitle, imgWhiteOceaneeringLogo);
            var flxBody = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "93%",
                "horizontalScrollIndicator": true,
                "id": "flxBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "7.00%",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxBody.setDefaultUnit(kony.flex.DP);
            var flxPersonnelHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "7%",
                "id": "flxPersonnelHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBg7099b1",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxPersonnelHeader.setDefaultUnit(kony.flex.DP);
            var lblPersonnel = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblPersonnel",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLblFFFFFF110Bold",
                "text": "Personnel",
                "textStyle": {},
                "width": "75%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxPersonnelHeader.add(lblPersonnel);
            var flxPersonnelDetailsBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "73%",
                "id": "flxPersonnelDetailsBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxOp0",
                "top": "19%",
                "width": "90%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxPersonnelDetailsBody.setDefaultUnit(kony.flex.DP);
            var flxName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9.80%",
                "id": "flxName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxName.setDefaultUnit(kony.flex.DP);
            var lblName = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblName",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Name",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblNameValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNameValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "text": " ",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxName.add(lblName, lblNameValue);
            var flxEmployeeID = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9.80%",
                "id": "flxEmployeeID",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxEmployeeID.setDefaultUnit(kony.flex.DP);
            var lblEmpID = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblEmpID",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Employee ID",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblEmpIDValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblEmpIDValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "text": " ",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxEmployeeID.add(lblEmpID, lblEmpIDValue);
            var flxJobPosition = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9.80%",
                "id": "flxJobPosition",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxJobPosition.setDefaultUnit(kony.flex.DP);
            var lblJobPosition = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblJobPosition",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "JobPosition",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblJobPositionValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblJobPositionValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxJobPosition.add(lblJobPosition, lblJobPositionValue);
            var flxCrewPosition = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9.80%",
                "id": "flxCrewPosition",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCrewPosition.setDefaultUnit(kony.flex.DP);
            var lblCrewPosition = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCrewPosition",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Crew Position",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblCrewPositionValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCrewPositionValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "text": "ROV Pilot/Technician",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lstBoxCrewPoistion = new kony.ui.ListBox({
                "centerY": "50%",
                "focusSkin": "defListBoxFocus",
                "height": "75%",
                "id": "lstBoxCrewPoistion",
                "isVisible": true,
                "masterData": [
                    ["lb1", "Please Select"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "right": "5%",
                "skin": "sknLstBoxBorder333Op15",
                "top": "1dp",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCrewPosition.add(lblCrewPosition, lblCrewPositionValue, lstBoxCrewPoistion);
            var fllxDayHourRate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9.80%",
                "id": "fllxDayHourRate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            fllxDayHourRate.setDefaultUnit(kony.flex.DP);
            var lblDayHourRate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDayHourRate",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Day Rate",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblDayHourRateValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDayHourRateValue",
                "isVisible": false,
                "right": "5%",
                "skin": "sknLbl120333333",
                "text": "150$",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtDayHourRate = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTbxBorder25PrcntWhiteBgFont100",
                "height": "75%",
                "id": "txtDayHourRate",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "right": "5%",
                "secureTextEntry": false,
                "skin": "sknTbxBorder25PrcntWhiteBgFont100",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_NUMERIC,
                "top": "0dp",
                "width": "40%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblDollarSign = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDollarSign",
                "isVisible": false,
                "left": "50%",
                "skin": "sknLBL1201c1c1c",
                "text": "$",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            fllxDayHourRate.add(lblDayHourRate, lblDayHourRateValue, txtDayHourRate, lblDollarSign);
            var flxOTRate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9.80%",
                "id": "flxOTRate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxOTRate.setDefaultUnit(kony.flex.DP);
            var lblOTRate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblOTRate",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "OT Rate",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblOTRateValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblOTRateValue",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLbl120333333",
                "text": "250$",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtOTRate = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTbxBorder25PrcntWhiteBgFont100",
                "height": "75%",
                "id": "txtOTRate",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "right": "5%",
                "secureTextEntry": false,
                "skin": "sknTbxBorder25PrcntWhiteBgFont100",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_NUMERIC,
                "top": "0dp",
                "width": "40%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var CopylblDollarSign0e2abe322fb824f = new kony.ui.Label({
                "centerY": "50%",
                "id": "CopylblDollarSign0e2abe322fb824f",
                "isVisible": false,
                "left": "50%",
                "skin": "sknLBL1201c1c1c",
                "text": "$",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxOTRate.add(lblOTRate, lblOTRateValue, txtOTRate, CopylblDollarSign0e2abe322fb824f);
            var flxStandByRate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9.80%",
                "id": "flxStandByRate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxStandByRate.setDefaultUnit(kony.flex.DP);
            var lblStandByRate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblStandByRate",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Standby Rate",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblStandByRateValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblStandByRateValue",
                "isVisible": false,
                "right": "5%",
                "skin": "sknLbl120333333",
                "text": "0",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtStandByRate = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTbxBorder25PrcntWhiteBgFont100",
                "height": "75%",
                "id": "txtStandByRate",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "right": "5%",
                "secureTextEntry": false,
                "skin": "sknTbxBorder25PrcntWhiteBgFont100",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_NUMERIC,
                "top": "0dp",
                "width": "40%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var CopylblDollarSign0d1504b9c7d6e44 = new kony.ui.Label({
                "centerY": "50%",
                "id": "CopylblDollarSign0d1504b9c7d6e44",
                "isVisible": false,
                "left": "50%",
                "skin": "sknLBL1201c1c1c",
                "text": "$",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxStandByRate.add(lblStandByRate, lblStandByRateValue, txtStandByRate, CopylblDollarSign0d1504b9c7d6e44);
            var flxNonDiveRate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9.80%",
                "id": "flxNonDiveRate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxNonDiveRate.setDefaultUnit(kony.flex.DP);
            var lblNonDriveRate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNonDriveRate",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Non-Dive Rate",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblNonDriveRateValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNonDriveRateValue",
                "isVisible": false,
                "right": "5%",
                "skin": "sknLbl120333333",
                "text": "2",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var txtNonDiveRate = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTbxBorder25PrcntWhiteBgFont100",
                "height": "75%",
                "id": "txtNonDiveRate",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "right": "5%",
                "secureTextEntry": false,
                "skin": "sknTbxBorder25PrcntWhiteBgFont100",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_NUMERIC,
                "top": "0dp",
                "width": "40%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var CopylblDollarSign0fa9be294082e43 = new kony.ui.Label({
                "centerY": "50%",
                "id": "CopylblDollarSign0fa9be294082e43",
                "isVisible": false,
                "left": "50%",
                "skin": "sknLBL1201c1c1c",
                "text": "$",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxNonDiveRate.add(lblNonDriveRate, lblNonDriveRateValue, txtNonDiveRate, CopylblDollarSign0fa9be294082e43);
            var flxArrivalDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9.80%",
                "id": "flxArrivalDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxArrivalDate.setDefaultUnit(kony.flex.DP);
            var lblArrivalDate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblArrivalDate",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Arrival Date",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblArrivalDateValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblArrivalDateValue",
                "isVisible": false,
                "right": "5%",
                "skin": "sknLbl120333333",
                "text": "5/23/2019",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cldArrivalDate = new kony.ui.Calendar({
                "calendarIcon": "calendar_icon.png",
                "centerY": "50%",
                "dateComponents": [9, 8, 2019, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "day": 9,
                "formattedDate": "09/08/2019",
                "height": "75%",
                "hour": 0,
                "id": "cldArrivalDate",
                "isVisible": true,
                "minutes": 0,
                "month": 8,
                "right": "5%",
                "seconds": 0,
                "skin": "sknCldArrivalDepartDate",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "40%",
                "year": 2019,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxArrivalDate.add(lblArrivalDate, lblArrivalDateValue, cldArrivalDate);
            var flxDepartDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "9.80%",
                "id": "flxDepartDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxDepartDate.setDefaultUnit(kony.flex.DP);
            var lblDepartDate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDepartDate",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL1201c1c1c",
                "text": "Depart Date",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblDepartDateValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDepartDateValue",
                "isVisible": false,
                "right": "5%",
                "skin": "sknLbl120333333",
                "text": "5/23/2019 ",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var cldDepartDate = new kony.ui.Calendar({
                "calendarIcon": "calendar_icon.png",
                "centerY": "50%",
                "dateComponents": [9, 8, 2019, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "day": 9,
                "formattedDate": "09/08/2019",
                "height": "75%",
                "hour": 0,
                "id": "cldDepartDate",
                "isVisible": true,
                "minutes": 0,
                "month": 8,
                "right": "5%",
                "seconds": 0,
                "skin": "sknCldArrivalDepartDate",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "40%",
                "year": 2019,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDepartDate.add(lblDepartDate, lblDepartDateValue, cldDepartDate);
            flxPersonnelDetailsBody.add(flxName, flxEmployeeID, flxJobPosition, flxCrewPosition, fllxDayHourRate, flxOTRate, flxStandByRate, flxNonDiveRate, flxArrivalDate, flxDepartDate);
            var flxPersonnelDetailsHorizontalLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxPersonnelDetailsHorizontalLine",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxDBDBDBOp100",
                "top": "2%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxPersonnelDetailsHorizontalLine.setDefaultUnit(kony.flex.DP);
            flxPersonnelDetailsHorizontalLine.add();
            var flxCrewSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "7%",
                "id": "flxCrewSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBorderd1d1d110pxRd",
                "top": "7.5%",
                "width": "90.50%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCrewSearch.setDefaultUnit(kony.flex.DP);
            var txtCrewSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTxtFont107Col333",
                "height": "100%",
                "id": "txtCrewSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "onDone": controller.AS_TextField_g8dcdc6cfc1047c9854115e2d10018c8,
                "onTextChange": controller.AS_TextField_b5934e09e8c2495982214c32d66236ed,
                "placeholder": " Crew's Name/Employee ID",
                "secureTextEntry": false,
                "skin": "sknTxtFont107Col333",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "88%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "CopydefTextBoxPlaceholder0aee86ccbc75041"
            });
            var imgSearch = new kony.ui.Image2({
                "centerY": "47%",
                "height": "30dp",
                "id": "imgSearch",
                "isVisible": true,
                "onTouchEnd": controller.AS_Image_f907626f1834430d800029f10542038e,
                "right": "3%",
                "skin": "slImage",
                "src": "search2.png",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [66, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCrewSearch.add(txtCrewSearch, imgSearch);
            var flxSearchCrewResults = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "28%",
                "id": "flxSearchCrewResults",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "19dp",
                "isModalContainer": false,
                "skin": "sknFlx7099b1Op82BorderRd10",
                "top": "15%",
                "width": "91%",
                "zIndex": 3
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSearchCrewResults.setDefaultUnit(kony.flex.DP);
            var segCrewSearchResults = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblCrewEmployeeId": "02032934",
                    "lblCrewName": "Ravi"
                }, {
                    "lblCrewEmployeeId": "02032934",
                    "lblCrewName": "Ravi Gupta"
                }, {
                    "lblCrewEmployeeId": "02032934",
                    "lblCrewName": "Ravi Singh"
                }, {
                    "lblCrewEmployeeId": "02032934",
                    "lblCrewName": "Ravi Khandelwal"
                }, {
                    "lblCrewEmployeeId": "02032934",
                    "lblCrewName": "Ravi Nair"
                }, {
                    "lblCrewEmployeeId": "02032934",
                    "lblCrewName": "Ravi Prakash"
                }],
                "groupCells": false,
                "height": "100%",
                "id": "segCrewSearchResults",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_cca2434a6225480c9c5a9b37304f9ae3,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "sknSegmentBgfafafa",
                "rowTemplate": "flxCrewSearchResults",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "e3e3e300",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxCrewSearchResults": "flxCrewSearchResults",
                    "lblCrewEmployeeId": "lblCrewEmployeeId",
                    "lblCrewName": "lblCrewName"
                },
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoReults = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxNoReults",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFF",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxNoReults.setDefaultUnit(kony.flex.DP);
            var lblNoResults = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblNoResults",
                "isVisible": true,
                "left": "87dp",
                "skin": "sknLblSize1007099b1",
                "text": "Sorry! No results found, please refine your search criteria. ",
                "textStyle": {},
                "top": "60dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxNoReults.add(lblNoResults);
            flxSearchCrewResults.add(segCrewSearchResults, flxNoReults);
            var flxCrewResultShadow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.20%",
                "clipBounds": true,
                "height": "8dp",
                "id": "flxCrewResultShadow",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxMultiGradientBlackShadow",
                "top": "42.20%",
                "width": "87%",
                "zIndex": 2
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCrewResultShadow.setDefaultUnit(kony.flex.DP);
            flxCrewResultShadow.add();
            flxBody.add(flxPersonnelHeader, flxPersonnelDetailsBody, flxPersonnelDetailsHorizontalLine, flxCrewSearch, flxSearchCrewResults, flxCrewResultShadow);
            var flxHeaderShadow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "3dp",
                "id": "flxHeaderShadow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxMultiGradientBlackShadow",
                "top": "6.80%",
                "width": "100%",
                "zIndex": 2
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHeaderShadow.setDefaultUnit(kony.flex.DP);
            flxHeaderShadow.add();
            flxMain.add(flxHeader, flxBody, flxHeaderShadow);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlx000000Op40",
                "width": "100%",
                "zIndex": 15
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "10%",
                "id": "imgLoading",
                "isVisible": true,
                "skin": "slImage",
                "src": "loading.gif",
                "width": "30%",
                "zIndex": 15
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoading.add(imgLoading);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "-0.30%",
                "centerX": "50%",
                "clipBounds": true,
                "height": "7.50%",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxOp0",
                "width": "101%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var btnSave = new kony.ui.Button({
                "centerX": "70%",
                "centerY": "50%",
                "focusSkin": "sknBtn7099b1FontFFFFFF",
                "height": "70%",
                "id": "btnSave",
                "isVisible": true,
                "onClick": controller.AS_Button_bbfe0e9f7f624efbb83e0fbac3940b3c,
                "skin": "sknbtn7099b1RoundedBorder",
                "text": "Save",
                "width": "32%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancel = new kony.ui.Button({
                "centerX": "35%",
                "centerY": "50%",
                "focusSkin": "sknBtn7099b1FontFFFFFF",
                "height": "70%",
                "id": "btnCancel",
                "isVisible": true,
                "onClick": controller.AS_Button_ada86f5c7d7b47ccb78f7f845221a3c6,
                "skin": "sknBtn949494FontFFFFFF",
                "text": "Cancel",
                "width": "32%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFooter.add(btnSave, btnCancel);
            this.add(flxMain, flxLoading, flxFooter);
        };
        return [{
            "addWidgets": addWidgetsfrmAddCrew,
            "allowVerticalBounce": false,
            "bounces": false,
            "enabledForIdleTimeout": false,
            "id": "frmAddCrew",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_bc553483a1fb4f0f87cc6bc962dca138,
            "skin": "sknFrmFFD80FOp100"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});