define("userfrmLoginController", {
    mediaplayer: "",
    mediaplayer1: "",
    //-------------------Block screen while loading---------------
    /**
     * @desc Blocks the screen and shows the loading screen
     * @param -
     * @retun void
     */
    showLoadingIndicator: function() {
        this.view.flxLoading.isVisible = true;
        this.view.flxMain.setEnabled(false);
    },
    /**
     * @desc enables the screen and hides the loading screen
     * @param -
     * @retun void
     */
    dismissLoadingIndicator: function() {
        this.view.flxLoading.isVisible = false;
        this.view.flxMain.setEnabled(true);
    },
    //-------------------------Ocean Waves Playback Sound---------------------------------
    createMediaFromFile: function() {
        //kony.print(":::Inside createMediaFromFile::::");
        try {
            // kony.print(":::Inside createMediaFromFile try::::");
            var destFilePath = kony.io.FileSystem.getDataDirectoryPath() + "/ocean_waves4.mp3";
            //kony.print("Destination Path:::" +destFilePath);
            kony.io.FileSystem.copyBundledRawFileTo("ocean_waves4.mp3", destFilePath);
            //kony.print("copied bundled raw file to destination");
            var file = new kony.io.File(destFilePath);
            //kony.print(":::file:::" + file);
            this.mediaplayer = kony.media.createFromFile(file);
            kony.timer.schedule("playSound", this.playMediaFile, 1, false);
            //kony.print(":::Media Player:::" + this.mediaplayer);
            //      this.mediaplayer.setCallbacks({ 
            //             onProgressCallBack: OnMediaProgress,
            //              onMediaCompleted: OnMediaCompleted, 
            //              onMediaFailed: OnMediaFailed });
            this.mediaplayer.setCallbacks({
                onMediaCompleted: this.OnMediaCompleted()
            });
        } catch (e) {
            alert("Exception::" + e);
        }
    },
    playMediaFile: function() {
        //kony.print(":::Inside playMediaFile::::");
        try {
            // alert(":::Inside playMediaFile try::::");
            this.mediaplayer.play(1);
            kony.timer.cancel("playSound");
            this.checkVol();
            kony.timer.schedule("stopSound", this.stopMediaFile, 12, false);
        } catch (e) {
            alert("::Exception::" + e);
        }
    },
    checkVol: function() {
        //kony.print(":::Inside playMediaFile::::");
        try {
            //kony.print(":::Inside playMediaFile try::::");
            // alert("Volume is::"+this.mediaplayer.volume);
            this.mediaplayer.volume = 0.1;
            kony.print(":::Volume is::::" + this.mediaplayer.volume);
        } catch (e) {
            alert("::Exception::" + e);
        }
    },
    pauseMediaFile: function() {
        //kony.print(":::Inside pauseMediaFile::::");
        try {
            //kony.print(":::Inside pauseMediaFile try::::");
            this.mediaplayer.pause();
        } catch (e) {
            alert("Exception::" + e);
        }
    },
    stopMediaFile: function() {
        //kony.print("Inside stopMediaFile");
        try {
            //kony.print("Inside stopMediaFile try");
            this.mediaplayer.stop();
            kony.timer.cancel("stopSound");
        } catch (e) {
            alert("Exception::" + e);
        }
    },
    OnMediaCompleted: function() {
        // alert("completed playing given song...");
    },
    /**
     * @function
     *
     */
    OnMediaProgress: function(Position) {
        kony.print("Call back invoked when the media is playing");
    },
    /**
     * @function
     *
     */
    OnMediaFailed: function(errorMessage) {
        alert("Unable to play the given media");
    },
    //----------------------------------OMS Login------------------------------------------
    onNavigate: function(data) {
        this.createMediaFromFile();
        if (data == "logout") {
            this.dismissPopup();
        } else {
            this.getRememberMeDetails();
        }
    },
    /**
     * @desc Called on click of the login button
     * @param -
     * @retun void
     */
    onClickOfLogin: function() {
        this.showLoadingIndicator();
        this.stopMediaFile();
        // kony.application.showLoadingScreen("sknLbl7D7D7DOp100S100", "Authenticating...", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, {});
        var username = this.getText(this.view.txtLoginEmail);
        var password = this.view.txtLoginPassword.text;
        this.view.flxLoginErrorMessage.setVisibility(false);
        this.checkIfUsernamePasswordIsValid(username, password);
    },
    getText: function(widget) {
        var inputString = widget.text;
        if (inputString === undefined || inputString === null || inputString === "null") {
            inputString = "";
        } else {
            inputString = (inputString.trim()).toLowerCase();
        }
        return inputString;
    },
    checkIfUsernamePasswordIsValid: function(userId, password) {
        var commonUtils = require("commonUtils");
        if (commonUtils.validateEmptyString(userId) && commonUtils.validateEmptyString(password)) {
            this.showAlertLogin("Enter valid username and password.");
            this.setUsernameAndPasswordToEmpty();
        } else if (commonUtils.validateEmptyString(userId)) {
            this.showAlertLogin("Enter valid username.");
            this.setUsernameAndPasswordToEmpty();
        } else if (commonUtils.validateEmptyString(password)) {
            this.showAlertLogin("Enter valid password.");
            this.setUsernameAndPasswordToEmpty();
        } else {
            // If internet is available (OMS) else check from Local Db if this is not the first time
            if (kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY)) {
                this.initilizeClientSDK_getlogin();
            } else {
                this.showGenericErrorPopup("No internet connection. Please try again when network is available.");
            }
        }
    },
    /**
     * @desc Sets username and password textboxes to empty
     * @param -
     * @retun void
     */
    setUsernameAndPasswordToEmpty: function() {
        //this.view.txtLoginEmail.text = "";
        // this.view.txtLoginPassword.text = "";
    },
    /**
     * @desc Initializes the Client SDK
     * @param -
     * @retun void
     */
    initilizeClientSDK_getlogin: function() {
        var appKey = oceaneering.oms.appConfig.appKey;
        var appSecret = oceaneering.oms.appConfig.appSecret;
        var serviceUrl = oceaneering.oms.appConfig.serviceUrl;
        oceaneering.oms.appGlobals.client = null;
        oceaneering.oms.appGlobals.client = new kony.sdk();
        oceaneering.oms.appGlobals.client.init(appKey, appSecret, serviceUrl, this.successCallback_getlogin.bind(this), this.errorCallback_getlogin.bind(this));
    },
    /**
     * @desc Success Callback for initializing Client SDK
     * @param JSON response - Success details from the Client SDK init
     * @retun void
     */
    successCallback_getlogin: function(response) {
        var userId = this.view.txtLoginEmail.text.trim();
        var password = this.view.txtLoginPassword.text.trim();
        this.invokeLoginService(userId, password);
    },
    /**
     * @desc Error Callback for initializing Client SDK
     * @param JSON error - Error details from the Client SDK init
     * @retun void
     */
    errorCallback_getlogin: function(error) {
        this.showGenericErrorPopup("No internet connection. Please try again when network is available.");
        kony.timer.schedule("timerNetworkConnection", this.dismissPopup, 4, false);
        kony.print("@@@@@@@@@@@@@@@ In initilizeClientSDKFailure: " + JSON.stringify(error));
    },
    /**
     * @desc Initializes the Client SDK
     * @param -
     * @retun void
     */
    initilizeClientSDK_navigateToHome: function(username, password) {
        // kony.application.showLoadingScreen("sknLbl7D7D7DOp100S100", "Authenticating...", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, {});
        this.showLoadingIndicator();
        var appKey = oceaneering.oms.appConfig.appKey;
        var appSecret = oceaneering.oms.appConfig.appSecret;
        var serviceUrl = oceaneering.oms.appConfig.serviceUrl;
        oceaneering.oms.appGlobals.client = null;
        oceaneering.oms.appGlobals.client = new kony.sdk();
        oceaneering.oms.appGlobals.client.init(appKey, appSecret, serviceUrl, this.successCallback_navigateToHome.bind(this, username, password), this.errorCallback_navigateToHome.bind(this));
    },
    /**
     * @desc Success Callback for initializing Client SDK
     * @param JSON response - Success details from the Client SDK init
     * @retun void
     */
    successCallback_navigateToHome: function(username, password, response) {
        this.dismissLoadingIndicator();
        this.showLoadingIndicator();
        kony.print("@@@@@@@@@@@@@@@ In initilizeClientSDKSuccess: " + JSON.stringify(response));
        this.invokeLoginService(username, password);
        // var navigationModule = require("navigationModule");
        // navigationModule.navigateToFrmDashboard({"navigatingFrom" : "Login"});
    },
    /**
     * @desc Error Callback for initializing Client SDK
     * @param JSON error - Error details from the Client SDK init
     * @retun void
     */
    errorCallback_navigateToHome: function(error) {
        this.dismissLoadingIndicator();
        this.showGenericErrorPopup("No internet connection. Please try again when network is available.");
        kony.timer.schedule("timerNetworkConnection", this.dismissPopup, 4, false);
        kony.print("@@@@@@@@@@@@@@@ In initilizeClientSDKFailure: " + JSON.stringify(error));
    },
    /**
     * @desc Invokes the login service
     * @param -
     * @retun void
     */
    invokeLoginService: function(userId, password) {
        try {
            var data = {
                "user": userId,
                "password": password
            };
            var headers = {};
            var integrationObj = oceaneering.oms.appGlobals.client.getIntegrationService("OMSAuthentication");
            var operationName = "UserLogin";
            integrationObj.invokeOperation(operationName, headers, data, this.operationSuccess.bind(this, userId, password), this.operationFailure.bind(this));
        } catch (err) {
            this.showGenericErrorPopup("Sorry, something went wrong. Please try again later.");
            kony.print("@@@@@@@@@@@@@@@ Error in invokeLoginService function: " + JSON.stringify(err));
        }
    },
    /**
     * @desc Error Callback for login service
     * @param JSON err - Error details from login service
     * @retun void
     */
    operationFailure: function(err) {
        this.showAlertLogin("Sorry, something went wrong. Please try again later.");
        kony.print("@@@@@@@@@@@@@@@ In invokeLoginService_ErrorCallback: " + JSON.stringify(err));
    },
    /**
     * @desc Success Callback for login service
     * @param JSON res - Contains the logged in user's details
     * @retun void
     */
    operationSuccess: function(userId, password, res) {
        try {
            if (res.EmpID == "") {
                this.showAlertLogin("The username or password you entered is incorrect.");
            } else {
                //oceaneering.oms.appGlobals.employeeId =res.EmpID;
                kony.store.setItem("username", userId);
                kony.store.setItem("userPassword", password);
                oceaneering.oms.appGlobals.employeeFullName = res.FirstName + " " + res.LastName;
                oceaneering.oms.appGlobals.username = res.Login;
                this.afterLoginSuccess();
            }
        } catch (err) {
            this.showGenericErrorPopup("Sorry, something went wrong. Please try again later.");
            kony.print("@@@@@@@@@@@@@@@ Error in invokeLoginService_SuccessCallback: " + JSON.stringify(err));
        }
    },
    /**
     * @desc Called after successful login.
     * @param JSON data - Contains the logged in user's details
     * @retun void
     */
    afterLoginSuccess: function() {
        this.dismissLoadingIndicator();
        this.view.flxLoginErrorMessage.setVisibility(false);
        this.storeEmployeeDataInDevice();
    },
    /**
     * @desc Stored login details into the local DB
     * @param JSON data - Contains the logged in user's details
     * @retun void
     */
    storeEmployeeDataInDevice: function() {
        // Have to update local Db with user id and password
        if (kony.store.getItem("userId") == null || kony.store.getItem("userId") == undefined) {
            kony.store.setItem("userId", "");
        }
        if (this.view.imgRememberMe.src == "switch_off.png") {
            kony.store.setItem("RememberUser", 0);
        } else {
            kony.store.setItem("RememberUser", 1);
        }
        this.checkTouchId();
    },
    /**
     * @desc Check if enable touchID popup should be displayed or not
     * @param -
     * @retun void
     */
    checkTouchId: function() {
        var userId = (this.view.txtLoginEmail.text.trim()).toLowerCase();
        if (userId != (kony.store.getItem("userId")).toLowerCase()) {
            kony.store.setItem("firstTimeLogin", true);
            kony.store.setItem("userId", userId);
        }
        if (kony.store.getItem("firstTimeLogin") == null || kony.store.getItem("firstTimeLogin") == undefined || kony.store.getItem("firstTimeLogin") == true) {
            this.isAuthUsingTouchSupported();
        } else {
            var navigationModule = require("navigationModule");
            navigationModule.navigateToFrmDashboard({
                "navigatingFrom": "Login"
            });
        }
    },
    /**
     * @desc Check if touchID is supported by the device or not
     * @param -
     * @retun void
     */
    isAuthUsingTouchSupported: function() {
        var status = kony.localAuthentication.getStatusForAuthenticationMode(constants.LOCAL_AUTHENTICATION_MODE_TOUCH_ID);
        if (status == 5000) {
            if (kony.store.getItem("firstTimeLogin") == false) {
                this.authUsingTouchID();
            } else {
                kony.store.setItem("firstTimeLogin", false);
                this.showEnableTouchIdPopup();
            }
        } else {
            kony.store.setItem("TouchId", 0);
            if (kony.store.getItem("firstTimeLogin") == false) {
                var msg = "Touch ID is not configured/Enabled on this device. Please enter your username and password to use this application. ";
                this.view.flxLoginErrorMessage.setVisibility(false);
                this.showGenericErrorPopup(msg);
            } else {
                kony.store.setItem("firstTimeLogin", false);
                var navigationModule = require("navigationModule");
                navigationModule.navigateToFrmDashboard({
                    "navigatingFrom": "Login"
                });
            }
        }
    },
    /**
     * @desc Authenticate using touch Id
     * @param -
     * @retun void
     */
    authUsingTouchID: function() {
        this.view.flxTouchId.setVisibility(true);
        this.dismissPopup();
        var config = {
            "promptMessage": "Place your finger on the home button to Login"
        };
        kony.localAuthentication.authenticate(constants.LOCAL_AUTHENTICATION_MODE_TOUCH_ID, this.statusCallBack.bind(this), config);
    },
    /**
     * @desc Touch Id Authentication callback
     * @param Int status - contains the touchId status code
     * @param messgae - contains the touchId Authentication message
     * @retun void
     */
    statusCallBack: function(status, message) {
        if (status == 5000) {
            if (kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY)) {
                var userId = kony.store.getItem("username");
                var password = kony.store.getItem("userPassword");
                this.showLoadingIndicator();
                kony.store.setItem("RememberUser", 1);
                this.dismissPopup();
                this.dismissLoadingIndicator();
                if (oceaneering.oms.appGlobals.client == null) {
                    this.stopMediaFile();
                    this.initilizeClientSDK_navigateToHome(userId, password);
                } else {
                    this.showLoadingIndicator();
                    this.stopMediaFile();
                    this.invokeLoginService(userId, password);
                    //  var navigationModule = require("navigationModule");
                    //  navigationModule.navigateToFrmDashboard({"navigatingFrom" : "Login"});
                }
            } else {
                this.showGenericErrorPopup("Please check your Network Connectivity.");
            }
        } else if (status == 5002) {
            kony.store.setItem("RememberUser", 1);
        } else {
            kony.store.setItem("RememberUser", 1);
            var msg = "Touch ID does not recognize your fingerprint. Please try again or login using your username and password.";
            this.showGenericErrorPopup(msg);
        }
    },
    /**
     * @desc Shows the error message on the Login Screen
     * @param String text - Contains the error message
     * @retun void
     */
    showAlertLogin: function(text) {
        this.view.flxLoginErrorMessage.setVisibility(true);
        this.view.lblLoginErrorMessage.text = text;
        this.dismissLoadingIndicator();
    },
    /**
     * @desc Opens new mail on Click of Forgot Password
     * @param -
     * @retun void
     */
    sendMail: function() {
        try {
            var deviceInfo = kony.os.deviceInfo();
            // Set the recipients.
            var to = ["grp-mobile-oii@oceaneering.com"];
            var cc = [];
            var bcc = [];
            // Set the subject.
            var sub = "Forgot Password";
            // Message body.
            var msgbody = "Unable to Login. \n My UserId is:  \n My EmployeeId is:  \n\nThank You.\n" + "\n==================\nDO NOT EDIT\n==================\nApplication: OMS\nDevice Model: " + deviceInfo.model + "\nOS: " + deviceInfo.name + "\nOS Version: " + deviceInfo.version;
            // Send the email.
            kony.phone.openEmail(to, cc, bcc, sub, msgbody, false);
        } catch (err) {
            kony.print("@@@@@@@@@@@@@@@ Error in sendMail function: " + JSON.stringify(err));
        }
    },
    /**
     * @desc Used to toggle remember me between on and off
     * @param -
     * @retun void
     */
    toggleRememberMe: function() {
        try {
            if (this.view.imgRememberMe.src == "switch_off.png") {
                this.view.imgRememberMe.src = "switch_on.png";
            } else {
                this.view.imgRememberMe.src = "switch_off.png";
            }
        } catch (err) {
            kony.print("@@@@@@@@@@@@@@@ Error in toggleRememberMe function: " + JSON.stringify(err));
        }
    },
    /**
     * @desc Called on PostShow of login form. Populated the required fields
     * @param -
     * @retun void
     */
    getRememberMeDetails: function() {
        try {
            var userId = kony.store.getItem("userId");
            var password = kony.store.getItem("password");
            this.dismissPopup();
            if (kony.store.getItem("TouchId") === 1) {
                this.setDetailsForTouchID(userId, password);
            } else if (kony.store.getItem("RememberUser") == 1) {
                this.setDetailsForRememberMe(userId);
            } else {
                this.view.flxTouchId.setVisibility(false);
                this.view.imgRememberMe.src = "switch_off.png";
                this.setUsernameAndPasswordToEmpty();
            }
        } catch (err) {
            kony.print("@@@@@@@@@@@@@@@ Error in getRememberUserName function: " + JSON.stringify(err));
        }
    },
    setDetailsForTouchID: function(userId, password) {
        this.view.flxTouchId.setVisibility(true);
        this.view.imgRememberMe.src = "switch_on.png";
        this.view.txtLoginEmail.text = userId;
        this.view.txtLoginPassword.text = password;
        this.isAuthUsingTouchSupported();
    },
    setDetailsForRememberMe: function(userId) {
        this.view.flxTouchId.setVisibility(false);
        this.view.imgRememberMe.src = "switch_on.png";
        this.view.txtLoginEmail.text = userId;
        this.view.txtLoginPassword.text = "";
    },
    /**
     * @desc Shows the enable Touch ID popup for the first time login of a user
     * @param -
     * @retun void
     */
    showEnableTouchIdPopup: function() {
        this.dismissPopup();
        this.view.flxPopupMain.isVisible = true;
        this.view.flxEnableTouchIdPopup.isVisible = true;
    },
    /**
     * @desc Disables Touch ID and navigates to Dashboard screen
     * @param -
     * @retun void
     */
    onClickOfNotNowInTouchIdPopup: function() {
        kony.store.setItem("TouchId", 0);
        var navigationModule = require("navigationModule");
        navigationModule.navigateToFrmDashboard({
            "navigatingFrom": "Login"
        });
    },
    /**
     * @desc Shows the generic error message popup
     * @param String errorMessage - Contains the error message to be displayed in the popup
     * @retun void
     */
    showGenericErrorPopup: function(errorMessage) {
        this.dismissLoadingIndicator();
        this.dismissPopup();
        this.view.flxPopupMain.isVisible = true;
        this.view.flxGenericErrorPopup.isVisible = true;
        this.view.lblGenericErrorMessage.text = errorMessage;
    },
    /**
     * @desc Enables Touch ID
     * @param -
     * @retun void
     */
    enableTouchId: function() {
        kony.store.setItem("TouchId", 1);
        this.authUsingTouchID();
    },
    /**
     * @desc Dismisses all the popups in the login screen
     * @param -
     * @retun void
     */
    dismissPopup: function() {
        this.view.flxPopupMain.isVisible = false;
        this.view.flxEnableTouchIdPopup.isVisible = false;
        this.view.flxGenericErrorPopup.isVisible = false;
        this.view.flxAuthentiacteUsingTouchIdPopup.isVisible = false;
    },
    /**
     * @desc Shows Authenticate using Touch ID ppopup for Android
     * @param -
     * @retun void
     */
    showAuthUsingTouchIdPopup: function() {
        this.view.flxPopupMain.isVisible = true;
        this.view.flxAuthentiacteUsingTouchIdPopup.isVisible = true;
    }
});
define("frmLoginControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onTouchStart defined for txtLoginEmail **/
    AS_TextField_e1a703e44fea4108a57a9b57176ca56e: function AS_TextField_e1a703e44fea4108a57a9b57176ca56e(eventobject, x, y) {
        var self = this;
        this.view.flxLoginErrorMessage.setVisibility(false);
    },
    /** onBeginEditing defined for txtLoginEmail **/
    AS_TextField_badea528a3ab42df9226431b26cf6c3b: function AS_TextField_badea528a3ab42df9226431b26cf6c3b(eventobject, changedtext) {
        var self = this;
        this.view.flxLoginErrorMessage.setVisibility(false);
    },
    /** onBeginEditing defined for txtLoginEmail **/
    AS_TextField_g8130a73d5b64d20908a8004d2de5078: function AS_TextField_g8130a73d5b64d20908a8004d2de5078(eventobject, changedtext) {
        var self = this;
        this.view.flxLoginErrorMessage.setVisibility(false);
    },
    /** onTouchStart defined for txtLoginPassword **/
    AS_TextField_db33701f1ee34a2f9dac5b9f90eac469: function AS_TextField_db33701f1ee34a2f9dac5b9f90eac469(eventobject, x, y) {
        var self = this;
        this.view.flxLoginErrorMessage.setVisibility(false);
    },
    /** onBeginEditing defined for txtLoginPassword **/
    AS_TextField_cfbd813fe88d46048243a032f7f2bff9: function AS_TextField_cfbd813fe88d46048243a032f7f2bff9(eventobject, changedtext) {
        var self = this;
        this.view.flxLoginErrorMessage.setVisibility(false);
    },
    /** onBeginEditing defined for txtLoginPassword **/
    AS_TextField_e364d3a837d241b4b97167d15fb98eee: function AS_TextField_e364d3a837d241b4b97167d15fb98eee(eventobject, changedtext) {
        var self = this;
        this.view.flxLoginErrorMessage.setVisibility(false);
    },
    /** onTouchEnd defined for lblForgotPassword **/
    AS_Label_d47af1d103f04022b3b18a7e24037f31: function AS_Label_d47af1d103f04022b3b18a7e24037f31(eventobject, x, y) {
        var self = this;
        this.sendMail();
    },
    /** onTouchEnd defined for imgRememberMe **/
    AS_Image_c97810d652f44479800281346a49fa74: function AS_Image_c97810d652f44479800281346a49fa74(eventobject, x, y) {
        var self = this;
        this.toggleRememberMe();
    },
    /** onClick defined for btnLogin **/
    AS_Button_j0034e4a3e67492682c236b52e5a2929: function AS_Button_j0034e4a3e67492682c236b52e5a2929(eventobject) {
        var self = this;
        this.onClickOfLogin();
    },
    /** onClick defined for flxTouchId **/
    AS_FlexContainer_f1fb49e8e2b849d4ae1a34200be09d1c: function AS_FlexContainer_f1fb49e8e2b849d4ae1a34200be09d1c(eventobject) {
        var self = this;
        this.isAuthUsingTouchSupported();
    },
    /** onClick defined for btnNotNow **/
    AS_Button_b1ce2603377e447f829efc24c4681c5a: function AS_Button_b1ce2603377e447f829efc24c4681c5a(eventobject) {
        var self = this;
        this.onClickOfNotNowInTouchIdPopup();
    },
    /** onClick defined for btnEnable **/
    AS_Button_cd8aa97cf1d14ff7aa0bae2231e0b0d3: function AS_Button_cd8aa97cf1d14ff7aa0bae2231e0b0d3(eventobject) {
        var self = this;
        this.enableTouchId();
    },
    /** onClick defined for btnCancelAuthUsingTouchId **/
    AS_Button_abf6c8253e6c41a38a4f0b32a5e2c913: function AS_Button_abf6c8253e6c41a38a4f0b32a5e2c913(eventobject) {
        var self = this;
        this.dismissPopup();
    },
    /** onClick defined for flxPopupMain **/
    AS_FlexContainer_fd62abec2da746e6ae1e839c831dc0d0: function AS_FlexContainer_fd62abec2da746e6ae1e839c831dc0d0(eventobject) {
        var self = this;
        this.dismissPopup();
    },
    /** preShow defined for frmLogin **/
    AS_Form_ge4b8c4d3d174e628e407608f790e3e9: function AS_Form_ge4b8c4d3d174e628e407608f790e3e9(eventobject) {
        var self = this;
        this.dismissLoadingIndicator();
    }
});
define("frmLoginController", ["userfrmLoginController", "frmLoginControllerActions"], function() {
    var controller = require("userfrmLoginController");
    var controllerActions = ["frmLoginControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
