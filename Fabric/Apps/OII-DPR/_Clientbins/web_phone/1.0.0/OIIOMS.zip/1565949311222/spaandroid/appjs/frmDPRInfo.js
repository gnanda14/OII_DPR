define("frmDPRInfo", function() {
    return function(controller) {
        function addWidgetsfrmDPRInfo() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "7%",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx003C5COp100",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var flxBack = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "52%",
                "clipBounds": true,
                "height": "80%",
                "id": "flxBack",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "4%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "7%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxBack.setDefaultUnit(kony.flex.DP);
            var imgBack = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "49%",
                "height": "100%",
                "id": "imgBack",
                "isVisible": true,
                "skin": "slImage",
                "src": "white_back.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBack.add(imgBack);
            var lblHeaderTitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblHeaderTitle",
                "isVisible": true,
                "skin": "sknLblFFFFFFOp100S130",
                "text": "DPR Info",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var Button0a7a6a6484c974e = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "100%",
                "id": "Button0a7a6a6484c974e",
                "isVisible": true,
                "onClick": controller.AS_Button_aec2ded646b844fba45f18588a15adbd,
                "right": "2%",
                "skin": "defBtnNormal",
                "text": "Add Crew",
                "top": "0dp",
                "width": "30%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(flxBack, lblHeaderTitle, Button0a7a6a6484c974e);
            var flxMain = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "93%",
                "horizontalScrollIndicator": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFLXf0f0f0Op100",
                "top": "7.00%",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxProjectHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "7%",
                "id": "flxProjectHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgf0f0f0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxProjectHeader.setDefaultUnit(kony.flex.DP);
            var lblProjectID = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblProjectID",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL00263e110",
                "text": "Project Details - 0000100153",
                "textStyle": {},
                "top": "2dp",
                "width": "75%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var btnExpandProjectDetails = new kony.ui.Button({
                "focusSkin": "sknNonExpandedDetails",
                "height": "25dp",
                "id": "btnExpandProjectDetails",
                "isVisible": true,
                "onClick": controller.AS_Button_ba1c21305a204fcfbd24836abfa3c1e9,
                "right": "5%",
                "skin": "sknNonExpandedDetails",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAddCrew = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAddCrew",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "5%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "30%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxAddCrew.setDefaultUnit(kony.flex.DP);
            var lblAddCrew = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAddCrew",
                "isVisible": true,
                "right": "0%",
                "skin": "sknLbl333Font105Bold",
                "text": "Add Crew",
                "textStyle": {},
                "top": "2dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var imgAddCrew = new kony.ui.Image2({
                "centerY": "46.50%",
                "height": "15dp",
                "id": "imgAddCrew",
                "isVisible": true,
                "right": "6%",
                "skin": "slImage",
                "src": "addicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddCrew.add(lblAddCrew, imgAddCrew);
            flxProjectHeader.add(lblProjectID, btnExpandProjectDetails, flxAddCrew);
            var flxProjectDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "32%",
                "id": "flxProjectDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgf0f0f0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxProjectDetails.setDefaultUnit(kony.flex.DP);
            var flxProjectDetailsInner = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "95%",
                "id": "flxProjectDetailsInner",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFF",
                "top": "0%",
                "width": "90%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxProjectDetailsInner.setDefaultUnit(kony.flex.DP);
            var flxSuperVisor = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "25%",
                "id": "flxSuperVisor",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxSimple",
                "top": "0dp",
                "width": "102%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSuperVisor.setDefaultUnit(kony.flex.DP);
            var CopylblBorderLine0d46330e3d5624b = new kony.ui.Label({
                "centerX": "50%",
                "height": "2px",
                "id": "CopylblBorderLine0d46330e3d5624b",
                "isVisible": true,
                "left": "0dp",
                "skin": "lblBorderb0b0b0",
                "textStyle": {},
                "top": "95%",
                "width": "97%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblSupervisor = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSupervisor",
                "isVisible": true,
                "left": "6%",
                "skin": "sknLBL1201c1c1c",
                "text": "Supervisor",
                "textStyle": {},
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblSupervisorValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSupervisorValue",
                "isVisible": true,
                "right": "4%",
                "skin": "sknLbl120333333",
                "text": "Chaves, Nelson",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxSuperVisor.add(CopylblBorderLine0d46330e3d5624b, lblSupervisor, lblSupervisorValue);
            var flxLocation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "25%",
                "id": "flxLocation",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxSimple",
                "top": "0dp",
                "width": "102%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxLocation.setDefaultUnit(kony.flex.DP);
            var CopylblBorderLine0cfbdb492fe574c = new kony.ui.Label({
                "centerX": "50%",
                "height": "2px",
                "id": "CopylblBorderLine0cfbdb492fe574c",
                "isVisible": true,
                "left": "0dp",
                "skin": "lblBorderb0b0b0",
                "textStyle": {},
                "top": "95%",
                "width": "97%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblLocation = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblLocation",
                "isVisible": true,
                "left": "6%",
                "skin": "sknLBL1201c1c1c",
                "text": "Location",
                "textStyle": {},
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblLocationValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblLocationValue",
                "isVisible": true,
                "right": "4%",
                "skin": "sknLbl120333333",
                "text": "Times Square",
                "textStyle": {},
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxLocation.add(CopylblBorderLine0cfbdb492fe574c, lblLocation, lblLocationValue);
            var flxCountry = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "25%",
                "id": "flxCountry",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxSimple",
                "top": "0dp",
                "width": "102%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCountry.setDefaultUnit(kony.flex.DP);
            var CopylblBorderLine0f6950accf81747 = new kony.ui.Label({
                "centerX": "50%",
                "height": "2px",
                "id": "CopylblBorderLine0f6950accf81747",
                "isVisible": true,
                "left": "0dp",
                "skin": "lblBorderb0b0b0",
                "textStyle": {},
                "top": "95%",
                "width": "97%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblCountry = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCountry",
                "isVisible": true,
                "left": "6%",
                "skin": "sknLBL1201c1c1c",
                "text": "Country",
                "textStyle": {},
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lstBoxCountries = new kony.ui.ListBox({
                "centerY": "48%",
                "focusSkin": "defListBoxFocus",
                "height": "40dp",
                "id": "lstBoxCountries",
                "isVisible": true,
                "masterData": [
                    ["Country1", "New York"],
                    ["Country2", "India"],
                    ["Country3", "Australia"]
                ],
                "right": "4%",
                "selectedKey": "Country1",
                "selectedKeyValue": ["Country1", "New York"],
                "skin": "sknLsBoxCountries",
                "top": "3dp",
                "width": "45%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [4, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Image0hb040acffb2340 = new kony.ui.Image2({
                "centerY": "49%",
                "height": "22dp",
                "id": "Image0hb040acffb2340",
                "isVisible": true,
                "right": "3%",
                "skin": "slImage",
                "src": "down_arrow.png",
                "top": "2dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCountry.add(CopylblBorderLine0f6950accf81747, lblCountry, lstBoxCountries, Image0hb040acffb2340);
            var flxProjectManager = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "25%",
                "id": "flxProjectManager",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxSimple",
                "top": "0dp",
                "width": "102%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxProjectManager.setDefaultUnit(kony.flex.DP);
            var CopylblBorderLine0ae5cb5a5d28e4c = new kony.ui.Label({
                "centerX": "50%",
                "height": "2px",
                "id": "CopylblBorderLine0ae5cb5a5d28e4c",
                "isVisible": true,
                "left": "0dp",
                "skin": "lblBorderb0b0b0",
                "textStyle": {},
                "top": "95%",
                "width": "97%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblProjectManager = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblProjectManager",
                "isVisible": true,
                "left": "6%",
                "skin": "sknLBL1201c1c1c",
                "text": "Project Manager",
                "textStyle": {},
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblProjectManagerValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblProjectManagerValue",
                "isVisible": true,
                "right": "4%",
                "skin": "sknLbl120333333",
                "text": "Philip Doyle",
                "textStyle": {},
                "width": "48%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxProjectManager.add(CopylblBorderLine0ae5cb5a5d28e4c, lblProjectManager, lblProjectManagerValue);
            flxProjectDetailsInner.add(flxSuperVisor, flxLocation, flxCountry, flxProjectManager);
            flxProjectDetails.add(flxProjectDetailsInner);
            var borderProjectDetails = new kony.ui.Label({
                "centerX": "50%",
                "height": "1dp",
                "id": "borderProjectDetails",
                "isVisible": true,
                "left": "0dp",
                "skin": "lblBorderb0b0b0",
                "textStyle": {},
                "top": "0%",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var flxCrewDetailsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "7%",
                "id": "flxCrewDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgf0f0f0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCrewDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblCrewDetailsHeader = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblCrewDetailsHeader",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL00263e110",
                "text": "Crew Details",
                "textStyle": {},
                "top": "2dp",
                "width": "75%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var btnExpandCrewDetails = new kony.ui.Button({
                "focusSkin": "sknNonExpandedDetails",
                "height": "25dp",
                "id": "btnExpandCrewDetails",
                "isVisible": true,
                "onClick": controller.AS_Button_d7d85dd542af424283d3d9b6f4ba6276,
                "right": "5%",
                "skin": "sknNonExpandedDetails",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCrewDetailsHeader.add(lblCrewDetailsHeader, btnExpandCrewDetails);
            var borderCrewDetails = new kony.ui.Label({
                "centerX": "50%",
                "height": "1dp",
                "id": "borderCrewDetails",
                "isVisible": true,
                "left": "0dp",
                "skin": "lblBorderb0b0b0",
                "textStyle": {},
                "top": "0%",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var segCrewDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "data": [{
                    "imgAddCrew": "imagedrag.png",
                    "lblAddCrew": "Label",
                    "lblCrewMemberName": "",
                    "lblRole": ""
                }],
                "groupCells": false,
                "id": "segCrewDetails",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxTempCrewDetails",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "b0b0b028",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxTempCrewDetails": "flxTempCrewDetails",
                    "flxTempCrewDetailsInner": "flxTempCrewDetailsInner",
                    "imgAddCrew": "imgAddCrew",
                    "lblAddCrew": "lblAddCrew",
                    "lblCrewMemberName": "lblCrewMemberName",
                    "lblRole": "lblRole"
                },
                "width": "90%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCrewDPRInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "7%",
                "id": "flxCrewDPRInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgf0f0f0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCrewDPRInfo.setDefaultUnit(kony.flex.DP);
            var lblCrewInfoHeader = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblCrewInfoHeader",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLBL00263e110",
                "text": "Crew DPR Info",
                "textStyle": {},
                "top": "2dp",
                "width": "75%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxCrewDPRInfo.add(lblCrewInfoHeader);
            var segCrewInfo = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "data": [{
                    "btnExpandCrewMemberDetails": "",
                    "lblCrewMemNameSup": "Chaves, Nelson",
                    "lblDprIDSup": "DPR ID",
                    "lblDprIDSupValue": "05538729",
                    "lblEmpIDSup": "Employee ID",
                    "lblEmpIDSupValue": "0203732232",
                    "lblEndDateSup": "End Date",
                    "lblEndDateSupValue": "2019-08-17",
                    "lblNormalHoursSup": "Normal Hours",
                    "lblNormalHoursSupValue": "320",
                    "lblStartDateSup": "Start Date",
                    "lblStartDateSupValue": "2018-07-15"
                }],
                "groupCells": false,
                "id": "segCrewInfo",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxTempCrewInfo",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnExpandCrewMemberDetails": "btnExpandCrewMemberDetails",
                    "flxCrewMemberDetailsSup": "flxCrewMemberDetailsSup",
                    "flxCrewMemberHeaderSup": "flxCrewMemberHeaderSup",
                    "flxDPRIDSup": "flxDPRIDSup",
                    "flxEmployeeIDSup": "flxEmployeeIDSup",
                    "flxEndDateSup": "flxEndDateSup",
                    "flxNormalHoursSup": "flxNormalHoursSup",
                    "flxStartDateSup": "flxStartDateSup",
                    "flxTempCrewInfo": "flxTempCrewInfo",
                    "lblCrewMemNameSup": "lblCrewMemNameSup",
                    "lblDprIDSup": "lblDprIDSup",
                    "lblDprIDSupValue": "lblDprIDSupValue",
                    "lblEmpIDSup": "lblEmpIDSup",
                    "lblEmpIDSupValue": "lblEmpIDSupValue",
                    "lblEndDateSup": "lblEndDateSup",
                    "lblEndDateSupValue": "lblEndDateSupValue",
                    "lblNormalHoursSup": "lblNormalHoursSup",
                    "lblNormalHoursSupValue": "lblNormalHoursSupValue",
                    "lblStartDateSup": "lblStartDateSup",
                    "lblStartDateSupValue": "lblStartDateSupValue"
                },
                "width": "90%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMain.add(flxProjectHeader, flxProjectDetails, borderProjectDetails, flxCrewDetailsHeader, borderCrewDetails, segCrewDetails, flxCrewDPRInfo, segCrewInfo);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "-0.30%",
                "centerX": "50%",
                "clipBounds": true,
                "height": "7.50%",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxOp0",
                "width": "101%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var btnSave = new kony.ui.Button({
                "centerX": "50%",
                "centerY": "50%",
                "focusSkin": "sknBtn7099b1FontFFFFFF",
                "height": "80%",
                "id": "btnSave",
                "isVisible": true,
                "onClick": controller.AS_Button_f62f524b24fb48da8b59ca9c8cb4aa63,
                "skin": "sknBtn7099b1FontFFFFFF",
                "text": "Save",
                "width": "40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFooter.add(btnSave);
            this.add(flxHeader, flxMain, flxFooter);
        };
        return [{
            "addWidgets": addWidgetsfrmDPRInfo,
            "bounces": false,
            "enabledForIdleTimeout": false,
            "id": "frmDPRInfo",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});