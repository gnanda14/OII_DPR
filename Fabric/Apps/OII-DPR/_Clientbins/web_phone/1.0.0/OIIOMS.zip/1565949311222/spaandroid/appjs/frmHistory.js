define("frmHistory", function() {
    return function(controller) {
        function addWidgetsfrmHistory() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFOp100",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "7%",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx003C5COp100",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var flxMenuIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "55%",
                "clipBounds": true,
                "height": "80%",
                "id": "flxMenuIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "4%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_c57b9454de174938bba4b85ad3033ac9,
                "skin": "slFbox",
                "width": "8%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxMenuIcon.setDefaultUnit(kony.flex.DP);
            var imgMenu = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "60%",
                "id": "imgMenu",
                "isVisible": true,
                "skin": "slImage",
                "src": "back_icon.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMenuIcon.add(imgMenu);
            var lblTitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblTitle",
                "isVisible": true,
                "skin": "sknLblFFFFFFOp100S130",
                "text": "DPR History",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var flxFilterIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "55%",
                "clipBounds": true,
                "height": "80%",
                "id": "flxFilterIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_b818639388984e78b93d78f6b579e91f,
                "right": "4%",
                "skin": "slFbox",
                "width": "8%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxFilterIcon.setDefaultUnit(kony.flex.DP);
            var imgFilterIcon = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "60%",
                "id": "imgFilterIcon",
                "isVisible": true,
                "skin": "slImage",
                "src": "filter_icon.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFilterIcon.add(imgFilterIcon);
            flxHeader.add(flxMenuIcon, lblTitle, flxFilterIcon);
            var flxBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "93%",
                "id": "flxBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "7%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxBody.setDefaultUnit(kony.flex.DP);
            var flxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "8%",
                "id": "flxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx999999Op100",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var flxSeachArea = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "80%",
                "id": "flxSeachArea",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.50%",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100BorderFFFFFFOp100Radius25px",
                "width": "87%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSeachArea.setDefaultUnit(kony.flex.DP);
            var txtSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "bottom": "5%",
                "focusSkin": "sknFFFFFFOp100Font333333Op100S100Perc",
                "height": "80%",
                "id": "txtSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "5%",
                "placeholder": "Enter Project ID",
                "secureTextEntry": false,
                "skin": "sknFFFFFFOp100Font333333Op100S100Perc",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_NUMERIC,
                "width": "75%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var flxSearchIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "80%",
                "id": "flxSearchIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "85%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "10%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSearchIcon.setDefaultUnit(kony.flex.DP);
            var imgSearch = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgSearch",
                "isVisible": true,
                "skin": "slImage",
                "src": "search_icon.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchIcon.add(imgSearch);
            flxSeachArea.add(txtSearch, flxSearchIcon);
            flxSearch.add(flxSeachArea);
            var flxStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "5%",
                "id": "flxStatus",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxE8E8E8Op100",
                "top": "8%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxStatus.setDefaultUnit(kony.flex.DP);
            var flxPendingStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "8dp",
                "id": "flxPendingStatus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "sknFlxC41431Op100BorderC41431Op100S1Circle",
                "width": "8dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxPendingStatus.setDefaultUnit(kony.flex.DP);
            flxPendingStatus.add();
            var lblPendingStatus = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPendingStatus",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLblC41431Op100S80Perc",
                "text": "Pending",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var flxSubmittedStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "8dp",
                "id": "flxSubmittedStatus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "sknFlx009C77Op100Border009C77Op100S1pxBorder",
                "width": "8dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSubmittedStatus.setDefaultUnit(kony.flex.DP);
            flxSubmittedStatus.add();
            var lblSubmittedStatus = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblSubmittedStatus",
                "isVisible": true,
                "left": "2%",
                "skin": "sknLbl009C77Op100S80Perc",
                "text": "Submitted",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxStatus.add(flxPendingStatus, lblPendingStatus, flxSubmittedStatus, lblSubmittedStatus);
            var flxSegHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "7%",
                "id": "flxSegHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "13%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSegHeader.setDefaultUnit(kony.flex.DP);
            var lblDPRIdTitle = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDPRIdTitle",
                "isVisible": true,
                "left": "6.50%",
                "skin": "sknLbl25536EOp100S110Perc",
                "text": "DPR ID",
                "textStyle": {},
                "width": "25%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblProjectIdTitle = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblProjectIdTitle",
                "isVisible": true,
                "left": "38%",
                "skin": "sknLbl25536EOp100S110Perc",
                "text": "Project ID",
                "textStyle": {},
                "width": "25%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblStartDateTitle = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblStartDateTitle",
                "isVisible": true,
                "left": "69.50%",
                "skin": "sknLbl25536EOp100S110Perc",
                "text": "Start Date",
                "textStyle": {},
                "width": "25%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var flxHeaderLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHeaderLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxAAAAAAOp100",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHeaderLine.setDefaultUnit(kony.flex.DP);
            flxHeaderLine.add();
            flxSegHeader.add(lblDPRIdTitle, lblProjectIdTitle, lblStartDateTitle, flxHeaderLine);
            var segDPRHistory = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblDPRId": "DPR-1234567",
                    "lblProjectId": "0000144516",
                    "lblStartDate": "2005-07-15"
                }, {
                    "lblDPRId": "DPR-1234567",
                    "lblProjectId": "0000144516",
                    "lblStartDate": "2005-07-15"
                }, {
                    "lblDPRId": "DPR-1234567",
                    "lblProjectId": "0000144516",
                    "lblStartDate": "2005-07-15"
                }, {
                    "lblDPRId": "DPR-1234567",
                    "lblProjectId": "0000144516",
                    "lblStartDate": "2005-07-15"
                }, {
                    "lblDPRId": "DPR-1234567",
                    "lblProjectId": "0000144516",
                    "lblStartDate": "2005-07-15"
                }, {
                    "lblDPRId": "DPR-1234567",
                    "lblProjectId": "0000144516",
                    "lblStartDate": "2005-07-15"
                }, {
                    "lblDPRId": "DPR-1234567",
                    "lblProjectId": "0000144516",
                    "lblStartDate": "2005-07-15"
                }, {
                    "lblDPRId": "DPR-1234567",
                    "lblProjectId": "0000144516",
                    "lblStartDate": "2005-07-15"
                }, {
                    "lblDPRId": "DPR-1234567",
                    "lblProjectId": "0000144516",
                    "lblStartDate": "2005-07-15"
                }, {
                    "lblDPRId": "DPR-1234567",
                    "lblProjectId": "0000144516",
                    "lblStartDate": "2005-07-15"
                }],
                "groupCells": false,
                "height": "80%",
                "id": "segDPRHistory",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxTempSegHistory",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "20%",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxStatus": "flxStatus",
                    "flxTempSegHistory": "flxTempSegHistory",
                    "lblDPRId": "lblDPRId",
                    "lblProjectId": "lblProjectId",
                    "lblStartDate": "lblStartDate"
                },
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBody.add(flxSearch, flxStatus, flxSegHeader, segDPRHistory);
            flxMain.add(flxHeader, flxBody);
            var flxFiltersOuter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxFiltersOuter",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxOp0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxFiltersOuter.setDefaultUnit(kony.flex.DP);
            var flxFiltersInner = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "93%",
                "id": "flxFiltersInner",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_a73937d1b23c462fb3b88362fd1e9b4d,
                "skin": "sknFlx000000Op40",
                "top": "7.00%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxFiltersInner.setDefaultUnit(kony.flex.DP);
            var flxFilterMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "22%",
                "id": "flxFilterMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "1%",
                "skin": "slFbox",
                "top": "1%",
                "width": "75%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxFilterMain.setDefaultUnit(kony.flex.DP);
            var imgWhiteTriangle = new kony.ui.Image2({
                "height": "16%",
                "id": "imgWhiteTriangle",
                "isVisible": true,
                "right": "3%",
                "skin": "slImage",
                "src": "white_triangle.png",
                "top": "0dp",
                "width": "12.50%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFilters = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "87.50%",
                "id": "flxFilters",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknFlxBgFFFFFFOp100BorderFFFFFFS1pRounded",
                "top": "11%",
                "width": "100%",
                "zIndex": 2
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxFilters.setDefaultUnit(kony.flex.DP);
            var lblFromDate = new kony.ui.Label({
                "id": "lblFromDate",
                "isVisible": true,
                "left": "8%",
                "skin": "sknLbl22253BOp100S110",
                "text": "From:",
                "textStyle": {},
                "top": "10%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var calStartDate = new kony.ui.Calendar({
                "calendarIcon": "calendar_start.png",
                "centerY": "45%",
                "dateComponents": [29, 7, 2019, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "day": 29,
                "focusSkin": "sknCalendarFont000000Op100S90",
                "formattedDate": "29/07/2019",
                "height": "20%",
                "hour": 0,
                "id": "calStartDate",
                "isVisible": true,
                "left": "5%",
                "minutes": 0,
                "month": 7,
                "seconds": 0,
                "skin": "sknCalendarFont000000Op100S90",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "40%",
                "year": 2019,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEndDate = new kony.ui.Label({
                "id": "lblEndDate",
                "isVisible": true,
                "left": "55%",
                "skin": "sknLbl22253BOp100S110",
                "text": "To:",
                "textStyle": {},
                "top": "10%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var calEndDate = new kony.ui.Calendar({
                "calendarIcon": "calendar_end.png",
                "centerY": "45%",
                "dateComponents": [29, 7, 2019, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "day": 29,
                "focusSkin": "sknCalendarFont000000Op100S90",
                "formattedDate": "29/07/2019",
                "height": "20%",
                "hour": 0,
                "id": "calEndDate",
                "isVisible": true,
                "left": "52%",
                "minutes": 0,
                "month": 7,
                "seconds": 0,
                "skin": "sknCalendarFont000000Op100S90",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "40%",
                "year": 2019,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFilterActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "5%",
                "clipBounds": true,
                "height": "25%",
                "id": "flxFilterActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "8.00%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "84%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxFilterActions.setDefaultUnit(kony.flex.DP);
            var btnApply = new kony.ui.Button({
                "focusSkin": "sknBtn0097A8Op100Border0097A8Op100Rounded",
                "height": "100%",
                "id": "btnApply",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtn0097A8Op100Border0097A8Op100Rounded",
                "text": "Apply",
                "top": "1dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnReset = new kony.ui.Button({
                "focusSkin": "sknBtn949494FontFFFFFFRounded",
                "height": "100%",
                "id": "btnReset",
                "isVisible": true,
                "right": "0%",
                "skin": "sknBtn949494FontFFFFFFRounded",
                "text": "Reset",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFilterActions.add(btnApply, btnReset);
            var flxVerticalLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "40%",
                "id": "flxVerticalLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknBFBFBFFlxOp100",
                "top": "11%",
                "width": "1dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxVerticalLine.setDefaultUnit(kony.flex.DP);
            flxVerticalLine.add();
            flxFilters.add(lblFromDate, calStartDate, lblEndDate, calEndDate, flxFilterActions, flxVerticalLine);
            flxFilterMain.add(imgWhiteTriangle, flxFilters);
            flxFiltersInner.add(flxFilterMain);
            flxFiltersOuter.add(flxFiltersInner);
            this.add(flxMain, flxFiltersOuter);
        };
        return [{
            "addWidgets": addWidgetsfrmHistory,
            "enabledForIdleTimeout": false,
            "id": "frmHistory",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmFFD80FOp100"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});