define('applicationController',{
    appInit: function(params) {
        skinsInit();
        kony.mvc.registry.add("com.konymp.floatingaction", "floatingaction", "floatingactionController");
        kony.application.registerMaster({
            "namespace": "com.konymp",
            "classname": "floatingaction",
            "name": "com.konymp.floatingaction"
        });
        kony.mvc.registry.add("com.konymp.timepicker", "timepicker", "timepickerController");
        kony.application.registerMaster({
            "namespace": "com.konymp",
            "classname": "timepicker",
            "name": "com.konymp.timepicker"
        });
        kony.mvc.registry.add("flxSampleRowTemplate", "flxSampleRowTemplate", "flxSampleRowTemplateController");
        kony.mvc.registry.add("flxSectionHeaderTemplate", "flxSectionHeaderTemplate", "flxSectionHeaderTemplateController");
        kony.mvc.registry.add("flxTempCrewInfo", "flxTempCrewInfo", "flxTempCrewInfoController");
        kony.mvc.registry.add("flxCrewSearchResults", "flxCrewSearchResults", "flxCrewSearchResultsController");
        kony.mvc.registry.add("flxTempCrewDetails", "flxTempCrewDetails", "flxTempCrewDetailsController");
        kony.mvc.registry.add("flxTempSegHistory", "flxTempSegHistory", "flxTempSegHistoryController");
        kony.mvc.registry.add("flxTempSegProjects", "flxTempSegProjects", "flxTempSegProjectsController");
        kony.mvc.registry.add("flxTempSegTRC", "flxTempSegTRC", "flxTempSegTRCController");
        kony.mvc.registry.add("frmAddCrew", "frmAddCrew", "frmAddCrewController");
        kony.mvc.registry.add("frmCreateDPR", "frmCreateDPR", "frmCreateDPRController");
        kony.mvc.registry.add("frmDashboard", "frmDashboard", "frmDashboardController");
        kony.mvc.registry.add("frmDPRInfo", "frmDPRInfo", "frmDPRInfoController");
        kony.mvc.registry.add("frmHistory", "frmHistory", "frmHistoryController");
        kony.mvc.registry.add("frmLogin", "frmLogin", "frmLoginController");
        setAppBehaviors();
    },
    postAppInitCallBack: function(eventObj) {},
    appmenuseq: function() {
        new kony.mvc.Navigation("frmLogin").navigate();
    }
});

define('com/konymp/floatingaction/analytics',[],function() {
    return {
        analyticsHost: "https://sampleapps.konycloud.com:443/services/data/v1/analytics/objects/log",
        constructBody: function() {
            try {
                var date = new Date();
                var deviceInfo = this.getDeviceOS();
                var body = {
                    "deviceModel": deviceInfo.model,
                    "Locale": kony.i18n.getCurrentDeviceLocale().language,
                    "Platform": deviceInfo.name,
                    "PlatformVersion": deviceInfo.version,
                    "appId": appConfig.appId,
                    "serviceUrl": appConfig.serviceUrl,
                    "itemGuid": "dbe86a8fb58844638bf4a15fd6085849",
                    "assetName": "com.konymp.floatingaction",
                    "assetVersion": "1.0.0",
                    "releaseMode": !appConfig.isDebug,
                    "konySdkVersion": kony.sdk.version,
                    "date": date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear(),
                    "endpointId": this.generateUniqueId(),
                    "deviceHeight": deviceInfo.deviceHeight,
                    "deviceWidth": deviceInfo.deviceWidth,
                    "kuid": "ubdf40815c524e5891d1af960c494bb8",
                };
                return body;
            } catch (exception) {
                kony.print(JSON.stringify(exception));
            }
        },
        notifyAnalytics: function() {
            try {
                if (this.checkInternetConnectivity() && this.isItFirstTime()) {
                    var httpclient = new kony.net.HttpRequest();
                    httpclient.open(constants.HTTP_METHOD_POST, this.analyticsHost);
                    httpclient.setRequestHeader("Content-Type", "application/json");
                    httpclient.send(JSON.stringify(this.constructBody()));
                }
            } catch (exception) {
                kony.print(JSON.stringify(exception));
            }
        },
        getDeviceOS: function() {
            try {
                return kony.os.deviceInfo();
            } catch (exception) {
                kony.print(JSON.stringify(exception));
            }
        },
        generateUniqueId: function() {
            try {
                return kony.crypto.createHMacHash("SHA512", this.getDeviceOS().deviceid, "KonyAnalytics");
            } catch (exception) {
                kony.print(JSON.stringify(exception));
            }
        },
        isItFirstTime: function() {
            var bodyDetails = this.constructBody();
            var assetVersion = kony.store.getItem(bodyDetails.assetName + "Version");
            if (kony.sdk.isNullOrUndefined(assetVersion) || assetVersion != bodyDetails.assetVersion) {
                kony.store.setItem(bodyDetails.assetName + "Version", bodyDetails.assetVersion);
                return true;
            } else {
                return false;
            }
        },
        checkInternetConnectivity: function() {
            return kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY);
        }
    };
});

/*
#
#  Created by Team Kony.
#  Copyright (c) 2017 Kony Inc. All rights reserved.
#
*/
define('com/konymp/floatingaction/KonyLogger',[],function() {
    /**
     * @module KonyLogger v1.1
     * @author AyyappaSwamy.Thatavarthy / Praharshita.Krishna
     * @category functionality
     * @description This module implements the KonyLogger class
     * KonyLogger provides the functionality of 6 logging levels viz.,
     * 1.TRACE	2.DEBUG	 3.INFO  4.WARN  5.ERROR 6.SILENT
     * It also supports capturing events viz.,
     * DEFAULT, FUNCTION_ENTRY, FUNCTION_EXIT, EXCEPTION, SUCCESS_CALLBACK, ERROR_CALLBACK, SERVICE_CALL, DATA_STORE
     * 2017 Kony Inc. 
     */
    /**
     * @member of  KonyLogger.js
     * @function KonyLogger
     * @param method - The function to be called to log the given message. 
     * When no parameter is passed, kony.print is called by default.
     * @returns an instance of KonyLogger class.
     * @description - This is the constructor for KonyLogger. 
     * This method initializes the instance created.
     **/
    var KonyLogger = function() {
        this.printMethod = kony.print;
        this.reuseableComponentName = arguments[0] || "appContext";
        var loggerGenerator = function() {
            this.trace = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "TRACE", message, event);
            };
            this.debug = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "DEBUG", message, event);
            };
            this.info = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "INFO", message, event);
            };
            this.warn = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "WARN", message, event);
            };
            this.error = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "ERROR", message, event);
            };
        };
        this.setLogLevel = function(logLevel) {
            if (this.isValidLogLevel(logLevel)) {
                if (typeof logLevel === "string") {
                    this.currentLogLevel = this.logLevels[logLevel];
                } else if (typeof logLevel === "number") {
                    this.currentLogLevel = logLevel;
                }
                var logMethods = Object.keys(this.logLevels);
                for (var i = 0; i < logMethods.length; i++) {
                    var methodName = logMethods[i].toLowerCase();
                    this[methodName] = (i < this.currentLogLevel) ? function() {} : (new loggerGenerator())[methodName];
                }
                return true;
            } else {
                return false;
            }
        };
        this.enableServerLogging = false;
        this.logMethod = function(functionName, logLevel, message, eventType) {
            var logObj = {
                "component": this.reuseableComponentName || "",
                "event": this.supportedEventTypes[eventType] || this.supportedEventTypes[this.DEFAULT],
                "function": functionName || "",
                "timestamp": KonyLogger.Utils.getDateTimeStamp() || "",
                "level": logLevel || "",
                "message": message || ""
            };
            if (this.enableServerLogging === true) {
                if ((KNYMetricsService !== undefined) && (KNYMetricsService !== null) && (KNYMetricsService !== "")) {
                    if (typeof KNYMetricsService.sendEvent === "function") {
                        /** sendEvent params - eventType, subEventType, formID, widgetID, flowTag, metaInfo{JSON} **/
                        KNYMetricsService.sendEvent("Custom", "KonyLogger", "MarketPlaceComponent", logObj.component, null, logObj);
                    }
                }
            }
            this.printMethod(JSON.stringify(logObj, null, '\t'));
        };
        this.setLogLevel("TRACE");
    };
    /**
     * @member of  KonyLogger
     * @property logLevels - This enum holds the 6 levels of logging and their order.
     **/
    KonyLogger.prototype.logLevels = {
        "TRACE": 0,
        "DEBUG": 1,
        "INFO": 2,
        "WARN": 3,
        "ERROR": 4,
        "SILENT": 5
    };
    /**
     * @member of  KonyLogger
     * @property eventTypes - This array holds 8 types of events.
     **/
    KonyLogger.prototype.supportedEventTypes = ["DEFAULT", "FUNCTION_ENTRY", "FUNCTION_EXIT", "SUCCESS_CALLBACK", "ERROR_CALLBACK", "EXCEPTION", "SERVICE_CALL", "DATA_STORE"];
    /** KonyLogger EventTypes**/
    KonyLogger.prototype.DEFAULT = 0;
    KonyLogger.prototype.FUNCTION_ENTRY = 1;
    KonyLogger.prototype.FUNCTION_EXIT = 2;
    KonyLogger.prototype.SUCCESS_CALLBACK = 3;
    KonyLogger.prototype.ERROR_CALLBACK = 4;
    KonyLogger.prototype.EXCEPTION = 5;
    KonyLogger.prototype.SERVICE_CALL = 6;
    KonyLogger.prototype.DATA_STORE = 7;
    /**
     * @member of  KonyLogger
     * @property defaultLogLevel - This property holds the default logLevel
     * It is intialised to "TRACE".
     **/
    KonyLogger.prototype.defaultLogLevel = KonyLogger.prototype.logLevels["TRACE"];
    /**
     * @member of  KonyLogger
     * @function isValidLogLevel
     * @param logLevel - (string or number)
     * @description - This method validates the logLevel parameter with the enum logLevels
     * @return boolean
     **/
    KonyLogger.prototype.isValidLogLevel = function(logLevel) {
        if ((logLevel !== undefined) && (logLevel !== null) && (logLevel !== "")) {
            if (typeof logLevel === "string") {
                if (logLevel.toUpperCase() in this.logLevels) {
                    return true;
                } else {
                    return false;
                }
            } else if (typeof logLevel === "number") {
                for (var logLevelKey in this.logLevels) {
                    if (logLevel === this.logLevels.logLevelKey) {
                        return true;
                    }
                }
                return false;
            } else {
                return false;
            }
        }
    };
    /**
     * @member of  KonyLogger
     * @function getLogLevel
     * @param none
     * @description - This method returns the current log level of the instance
     * @return type number
     **/
    KonyLogger.prototype.getLogLevel = function() {
        return this.currentLogLevel;
    };
    /**
     * @member of  KonyLogger
     * @function setPrintMethod
     * @param method: type function - The method to print the log/message.
     * The default value is kony.print
     * @description - This method sets the current log method to 'method'
     * @return none
     **/
    KonyLogger.prototype.setPrintMethod = function(method) {
        if ((method !== undefined) && (method !== null) && (method !== "")) {
            if (typeof method === "function") {
                this.printMethod = method;
            }
        }
    };
    KonyLogger.Utils = {};
    /**
     * @member of  KonyLogger
     * @function getDateTimeStamp
     * @param none
     * @description - It returns the current date and time stamp in "DD/MM/YY HH:MM AM/PM" format
     * @return type string
     **/
    KonyLogger.Utils.getDateTimeStamp = function() {
        var dateTimeStamp = "";
        var currentDateObj = new Date();
        dateTimeStamp += currentDateObj.getDate() + "/" + (currentDateObj.getMonth() + 1) + "/" + currentDateObj.getFullYear();
        dateTimeStamp += " ";
        var hours = currentDateObj.getHours();
        if (hours > 12) {
            dateTimeStamp += (hours - 12) + ":" + currentDateObj.getMinutes() + " PM";
        } else {
            dateTimeStamp += hours + ":" + currentDateObj.getMinutes() + " AM";
        }
        return dateTimeStamp;
    };
    return KonyLogger;
});

/*
#
#  Created by Team Kony.
#  Copyright (c) 2017 Kony Inc. All rights reserved.
#
*/
define("com/konymp/floatingaction/userfloatingactionController", ['com/konymp/floatingaction/KonyLogger'],function() {
    var konymp = konymp || {};
    var KonyLoggerModule = require("com/konymp/floatingaction/KonyLogger");
    konymp.logger = (new KonyLoggerModule("Floating Action Component")) || function() {};
    return {
        /**
         * @constructor constructor
         * @param basicConfig
         * @param layoutConfig
         * @param pspConfig
         */
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            var analytics = require("com/konymp/" + "floatingaction" + "/analytics");
            analytics.notifyAnalytics();
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            this._flag = 0;
            this._menuItemType = "Only Image";
            this._animationType = "Default";
            this._enableOverlay = true;
            this.showMenuItems = this.showMenuItemsWithDefaultAnimation.bind(this);
            this.hideMenuItems = this.hideMenuItemsWithDefaultAnimation.bind(this);
            kony.application.setApplicationBehaviors({
                hideDefaultLoadingIndicator: true
            });
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @initGettersSetters Logic for getters/setters of custom properties
         */
        initGettersSetters: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            defineSetter(this, "isVisibleMenuItem1", function(value) {
                try {
                    konymp.logger.trace("----------------------------- Setting isVisibleMenuItem1 Start", konymp.logger.FUNCTION_ENTRY);
                    if (typeof(value) === 'boolean') {
                        this.view.flxOption1.isVisible = value;
                        this.setUIForFloatingAction();
                    } else {
                        throw {
                            error: "InvalidType",
                            message: "Floating Action isVisibleMenuItem1 should be of type boolean"
                        };
                    }
                } catch (e) {
                    konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
                    if (e.error === "InvalidType") {
                        throw e;
                    }
                }
                konymp.logger.trace("-----------------------------Setting isVisibleMenuItem1 End", konymp.logger.FUNCTION_EXIT);
            });
            defineSetter(this, "isVisibleMenuItem2", function(value) {
                try {
                    konymp.logger.trace("----------------------------- Setting isVisibleMenuItem2 Start", konymp.logger.FUNCTION_ENTRY);
                    if (typeof(value) === 'boolean') {
                        this.view.flxOption2.isVisible = value;
                        this.setUIForFloatingAction();
                    } else {
                        throw {
                            error: "InvalidType",
                            message: "Floating Action isVisibleMenuItem2 should be of type boolean"
                        };
                    }
                } catch (e) {
                    konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
                    if (e.error === "InvalidType") {
                        throw e;
                    }
                }
                konymp.logger.trace("-----------------------------Setting isVisibleMenuItem2 End", konymp.logger.FUNCTION_EXIT);
            });
            defineSetter(this, "isVisibleMenuItem3", function(value) {
                try {
                    konymp.logger.trace("----------------------------- Setting isVisibleMenuItem3 Start", konymp.logger.FUNCTION_ENTRY);
                    if (typeof(value) === 'boolean') {
                        this.view.flxOption3.isVisible = value;
                        this.setUIForFloatingAction();
                    } else {
                        throw {
                            error: "InvalidType",
                            message: "Floating Action isVisibleMenuItem3 should be of type boolean"
                        };
                    }
                } catch (e) {
                    konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
                    if (e.error === "InvalidType") {
                        throw e;
                    }
                }
                konymp.logger.trace("-----------------------------Setting isVisibleMenuItem3 End", konymp.logger.FUNCTION_EXIT);
            });
            defineSetter(this, "isVisibleMenuItem4", function(value) {
                try {
                    konymp.logger.trace("----------------------------- Setting isVisibleMenuItem4 Start", konymp.logger.FUNCTION_ENTRY);
                    if (typeof(value) === 'boolean') {
                        this.view.flxOption4.isVisible = value;
                        this.setUIForFloatingAction();
                    } else {
                        throw {
                            error: "InvalidType",
                            message: "Floating Action isVisibleMenuItem4 should be of type boolean"
                        };
                    }
                } catch (e) {
                    konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
                    if (e.error === "InvalidType") {
                        throw e;
                    }
                }
                konymp.logger.trace("-----------------------------Setting isVisibleMenuItem4 End", konymp.logger.FUNCTION_EXIT);
            });
            defineSetter(this, "isVisibleMenuItem5", function(value) {
                try {
                    konymp.logger.trace("----------------------------- Setting isVisibleMenuItem5 Start", konymp.logger.FUNCTION_ENTRY);
                    if (typeof(value) === 'boolean') {
                        this.view.flxOption5.isVisible = value;
                        this.setUIForFloatingAction();
                    } else {
                        throw {
                            error: "InvalidType",
                            message: "Floating Action isVisibleMenuItem5 should be of type boolean"
                        };
                    }
                } catch (e) {
                    konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
                    if (e.error === "InvalidType") {
                        throw e;
                    }
                }
                konymp.logger.trace("-----------------------------Setting isVisibleMenuItem5 End", konymp.logger.FUNCTION_EXIT);
            });
            defineSetter(this, "menuItemType", function(value) {
                try {
                    konymp.logger.trace("----------------------------- Setting menuItemType Start", konymp.logger.FUNCTION_ENTRY);
                    if (typeof(value) === 'string') {
                        this._menuItemType = value;
                        this.setMenuItemDisplayType();
                    } else {
                        throw {
                            error: "InvalidType",
                            message: "Floating Action menuitem type should be of type string"
                        };
                    }
                } catch (e) {
                    konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
                    if (e.error === "InvalidType") {
                        throw e;
                    }
                }
                konymp.logger.trace("-----------------------------Setting menuItemType End", konymp.logger.FUNCTION_EXIT);
            });
            defineSetter(this, "animationType", function(value) {
                try {
                    konymp.logger.trace("----------------------------- Setting animationType Start", konymp.logger.FUNCTION_ENTRY);
                    if (typeof(value) === 'string') {
                        this._animationType = value;
                        this.setUIForFloatingAction();
                    } else {
                        throw {
                            error: "InvalidType",
                            message: "Floating Action animationType should be of type string"
                        };
                    }
                } catch (e) {
                    konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
                    if (e.error === "InvalidType") {
                        throw e;
                    }
                }
                konymp.logger.trace("-----------------------------Setting animationType End", konymp.logger.FUNCTION_EXIT);
            });
            defineSetter(this, "enableOverlay", function(value) {
                try {
                    konymp.logger.trace("----------------------------- Setting enableOverlay Start", konymp.logger.FUNCTION_ENTRY);
                    if (typeof(value) === 'boolean') {
                        this._enableOverlay = value;
                    } else {
                        throw {
                            error: "InvalidType",
                            message: "Floating Action enableOverlay should be of type boolean"
                        };
                    }
                } catch (e) {
                    konymp.logger.error(JSON.stringify(e), konymp.logger.EXCEPTION);
                    if (e.error === "InvalidType") {
                        throw e;
                    }
                }
                konymp.logger.trace("-----------------------------Setting enableOverlay End", konymp.logger.FUNCTION_EXIT);
            });
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function showMenu
         * @scope private
         * @description to show the menu items
         */
        showMenu: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            this.view.flxMenu.onClick = this.emptyFunction.bind(this);
            this.view.flxMenu1.onClick = this.emptyFunction.bind(this);
            if (this._flag == 0) {
                this.gettingFrame();
                this._flag = 1;
            }
            this.animationStarts();
            this.handlePrimaryButtonOnClick();
            this.handleMenuItem1onClick();
            this.handleMenuItem2onClick();
            this.handleMenuItem3onClick();
            this.handleMenuItem4onClick();
            this.handleMenuItem5onClick();
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function hideMenu
         * @scope private
         * @description to hide the menu items
         */
        hideMenu: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            this.handlePrimaryButtonOnClick();
            this.rotatePrimaryButtonIcon(0);
            this.hideMenuItems();
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function createMenuItems
         * @scope private
         * @description to set UI and onclick events on the basis of animation selected
         */
        createMenuItems: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            if (this._animationType === "Default") {
                this.showMenuItems = this.showMenuItemsWithDefaultAnimation;
                this.hideMenuItems = this.hideMenuItemsWithDefaultAnimation;
                this.setUIForDefaultAnimation();
            } else if (this._animationType === "Rise") {
                this.showMenuItems = this.showMenuItemsWithRiseAnimation.bind(this);
                this.hideMenuItems = this.hideMenuItemsWithRiseAnimation.bind(this);
                this.setUIForRiseAnimation();
            } else if (this._animationType === "Slide In") {
                this.showMenuItems = this.showMenuItemsWithSlideInAnimation;
                this.hideMenuItems = this.hideMenuItemsWithSlideInAnimation;
                this.setUIForSlideInAnimation();
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function showMenuItemsWithDefaultAnimation
         * @scope private
         * @description to show menu items with default animation
         */
        showMenuItemsWithDefaultAnimation: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            this.generateCenterYArray();
            this._rightoflblOption = this._widthInDp - this._frame.x;
            var y = this.generalizeWidthInPxPulsate(parseFloat(this.view.flxMenu1.width) / 2);
            var left = (y * this._widthInPx) * 100;
            var trans100 = kony.ui.makeAffineTransform();
            trans100.rotate(0);
            var divate = (3 * this._widthInDp) / 100;
            var divatefirst = (7 * this._widthInDp) / 100;
            var x = parseFloat(this.view.flxMenu1.centerX);
            for (i = 1; i <= this._noOfSubMenu; i++) {
                var b = i - 1;
                this.view["lblOption" + i].animate(kony.ui.createAnimation({
                    "60": {
                        "right": this._rightoflblOption + divatefirst + "dp",
                        "centerY": this.centerYArray[b] + "dp",
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                        "transform": trans100
                    },
                    "75": {
                        "right": this._rightoflblOption - divate + "dp",
                        "centerY": this.centerYArray[b] + "dp",
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                        "transform": trans100
                    },
                    "100": {
                        "right": this._rightoflblOption + "dp",
                        "centerY": this.centerYArray[b] + "dp",
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        }
                    },
                }), {
                    "delay": 0.05 * i,
                    "iterationCount": 1,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS,
                    "duration": 0.30
                }, {});
                this.view["flxOption" + i].animate(kony.ui.createAnimation({
                    "60": {
                        "centerX": x - divate + "dp",
                        "centerY": this.centerYArray[b] + "dp",
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                    },
                    "75": {
                        "centerX": x + divate + "dp",
                        "centerY": this.centerYArray[b] + "dp",
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                    },
                    "100": {
                        "centerX": x + "dp",
                        "centerY": this.centerYArray[b] + "dp",
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                    }
                }), {
                    "delay": 0.05 * i,
                    "iterationCount": 1,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS,
                    "duration": 0.30
                }, {
                    "animationEnd": this.showItemsAnimationEnd.bind(this, i)
                });
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function hideMenuItemsWithDefaultAnimation
         * @scope private
         * @description to hide menu items with default animation
         */
        hideMenuItemsWithDefaultAnimation: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            var trans100 = kony.ui.makeAffineTransform();
            trans100.rotate(-60);
            var j = 1;
            for (var i = this._noOfSubMenu; i >= 1; i--) {
                this.view["lblOption" + i].animate(kony.ui.createAnimation({
                    "100": {
                        "right": -110 - (i * 10) + "%",
                        "centerY": this.view.flxMenu1.centerY,
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                        "transform": trans100
                    }
                }), {
                    "delay": 0.01 * i,
                    "iterationCount": 1,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS,
                    "duration": 0.2
                }, {});
                this.view["flxOption" + i].animate(kony.ui.createAnimation({
                    "100": {
                        "centerX": 110 + (i * 31) + "%",
                        "centerY": this.view.flxMenu1.centerY,
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                    }
                }), {
                    "delay": 0.01 * j,
                    "iterationCount": 1,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS,
                    "duration": 0.2
                }, {
                    "animationEnd": this.hideItemsAnimationEnd.bind(this, i)
                });
                j++;
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function showMenuItemsWithRiseAnimation
         * @scope private
         * @description to show menu items with rise animation
         */
        showMenuItemsWithRiseAnimation: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            this.generateCenterYArray();
            for (var j = 1; j <= this._noOfSubMenu; j++) {
                var b = j - 1;
                this.view["flxOption" + j].isVisible = true;
                if (this._menuItemType !== "Only Image") {
                    this.view["lblOption" + j].isVisible = true;
                }
                this.view["lblOption" + j].animate(kony.ui.createAnimation({
                    "100": {
                        "centerY": this.centerYArray[b] + "dp",
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                        "opacity": 1.0
                    }
                }), {
                    "delay": 0,
                    "iterationCount": 1,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS,
                    "duration": 0.4
                }, {});
                this.view["flxOption" + j].animate(kony.ui.createAnimation({
                    "100": {
                        "centerY": this.centerYArray[b] + "dp",
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                        "opacity": 1.0
                    }
                }), {
                    "delay": 0,
                    "iterationCount": 1,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS,
                    "duration": 0.4
                }, {
                    "animationEnd": this.showItemsAnimationEnd.bind(this, j)
                });
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function hideMenuItemsWithRiseAnimation
         * @scope private
         * @description to hide menu items with rise animation
         */
        hideMenuItemsWithRiseAnimation: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            for (var j = 1; j <= this._noOfSubMenu; j++) {
                this.view["lblOption" + j].animate(kony.ui.createAnimation({
                    "100": {
                        "centerY": this.view.flxMenu1.centerY,
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                        "opacity": 0.0
                    }
                }), {
                    "delay": 0,
                    "iterationCount": 1,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS,
                    "duration": 0.4
                }, {});
                this.view["flxOption" + j].animate(kony.ui.createAnimation({
                    "100": {
                        "centerY": this.view.flxMenu1.centerY,
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                        "opacity": 0.0
                    }
                }), {
                    "delay": 0,
                    "iterationCount": 1,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS,
                    "duration": 0.4
                }, {
                    "animationEnd": this.hideItemsAnimationEnd.bind(this, j)
                });
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function showMenuItemsWithSlideInAnimation
         * @scope private
         * @description to show menu items with slide animation
         */
        showMenuItemsWithSlideInAnimation: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            for (var j = 1; j <= this._noOfSubMenu; j++) {
                this.view["lblOption" + j].animate(kony.ui.createAnimation({
                    "100": {
                        "right": this._widthInDp - this._frame.x + "dp",
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                        "opacity": 1.0
                    }
                }), {
                    "delay": 0,
                    "iterationCount": 1,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS,
                    "duration": 0.30
                }, {});
                this.view["flxOption" + j].animate(kony.ui.createAnimation({
                    "100": {
                        "centerX": this.view.flxMenu1.centerX,
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                        "opacity": 1.0
                    }
                }), {
                    "delay": 0,
                    "iterationCount": 1,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS,
                    "duration": 0.30
                }, {
                    "animationEnd": this.showItemsAnimationEnd.bind(this, j)
                });
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function hideMenuItemsWithSlideInAnimation
         * @scope private
         * @description to hide menu items with slide animation
         */
        hideMenuItemsWithSlideInAnimation: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            for (var j = 1; j <= this._noOfSubMenu; j++) {
                this.view["lblOption" + j].animate(kony.ui.createAnimation({
                    "100": {
                        "right": "-150%",
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                        "opacity": 0.0
                    }
                }), {
                    "delay": 0,
                    "iterationCount": 1,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS,
                    "duration": 0.30
                }, {});
                this.view["flxOption" + j].animate(kony.ui.createAnimation({
                    "100": {
                        "centerX": "150%",
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                        "opacity": 0.0
                    }
                }), {
                    "delay": 0,
                    "iterationCount": 1,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS,
                    "duration": 0.30
                }, {
                    "animationEnd": this.hideItemsAnimationEnd.bind(this, j)
                });
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function setMenuItemDisplayType
         * @scope private
         * @description to set menu type on basis of type selected
         */
        setMenuItemDisplayType: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            var menuItemIndex = 1;
            this.view.flxMenu1.imgMain2.src = this.view.flxMenu.imgMain.src;
            this.view.flxMenu1.imgIcon2.src = this.view.flxMenu.imgIcon.src;
            if (this._menuItemType === "Only Image") {
                for (menuItemIndex = 1; menuItemIndex <= 5; menuItemIndex++) {
                    this.view["lblOption" + menuItemIndex].isVisible = false;
                }
            } else if (this._menuItemType === "Image and Text") {
                for (menuItemIndex = 1; menuItemIndex <= 5; menuItemIndex++) {
                    this.view["lblOption" + menuItemIndex].isVisible = true;
                }
                for (var j = 1; j <= this._noOfSubMenu; j++) {
                    this.view["lblOption" + j].centerY = this.view["flxOption" + j].centerY;
                }
                this._rightoflblOption = (100 + 2 + ((parseInt(this.view.flxOption1.width) / kony.os.deviceInfo().deviceWidth) * 100) - (parseInt(this.view.flxMenu.centerX))) + "%";
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function setUIForFloatingAction
         * @scope private
         * @description to set UI for floating action
         */
        setUIForFloatingAction: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            this._noOfSubMenu = 0;
            for (var i = 1; i <= 5; i++) {
                if (this.view["flxOption" + i].isVisible === true) {
                    this._noOfSubMenu += 1;
                } else {
                    break;
                }
            }
            this.view.flxMenu.width = this.generalizeWidthInPxPulsate(79.2) + "px";
            this.view.flxMenu.height = this.view.flxMenu.width;
            this.view.flxMenu1.height = this.view.flxMenu.width;
            this.view.flxMenu1.width = this.view.flxMenu.width;
            this.view.height = this.view.flxMenu.width;
            this.view.width = this.view.flxMenu.width;
            this.view.flxMenu.onClick = this.showMenu.bind(this);
            this.view.flxMenu1.onClick = this.emptyFunction.bind(this);
            this._retainPosflx = this.view.flxOption1.centerX;
            this._retainPosLbl = this.view.lblOption1.right;
            this._leftOfFlxOption = this.view.flxMenu.centerX;
            this.initializeMenuItemsUI();
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function setUIForDefaultAnimation
         * @scope private
         * @description to set UI for Default animation
         */
        setUIForDefaultAnimation: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            for (i = 1; i <= this._noOfSubMenu; i++) {
                this.view["flxOption" + i].centerX = 110 + (i * 50) + "%";
                this.view["flxOption" + i].centerY = this.view.flxMenu1.centerY;
                this.view["flxOption" + i].width = this.generalizeWidthInPxPulsate(72) + "px";
                this.view["flxOption" + i].height = this.view["flxOption" + i].width;
                this.view["lblOption" + i].centerY = this.view["flxOption" + i].centerY;
                this.view["lblOption" + i].right = -110 - (i * 50) + "%";
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function setUIForRiseAnimation
         * @scope private
         * @description to set UI for Rise animation
         */
        setUIForRiseAnimation: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            for (var a = 1; a <= this._noOfSubMenu; a++) {
                this.view["flxOption" + a].centerX = this.view.flxMenu1.centerX;
                this.view["flxOption" + a].centerY = this.view.flxMenu1.centerY;
                this.view["flxOption" + a].width = this.generalizeWidthInPxPulsate(72) + "px";
                this.view["flxOption" + a].height = this.view["flxOption" + a].width;
                this.view["lblOption" + a].centerY = this.view["flxOption" + a].centerY;
                this.view["lblOption" + a].right = this._widthInDp - this._frame.x + "dp";
                this.view["flxOption" + a].isVisible = true;
                this.view["lblOption" + a].isVisible = true;
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function setUIForSlideInAnimation
         * @scope private
         * @description to set UI for Slide animation
         */
        setUIForSlideInAnimation: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            for (var a = 1; a <= this._noOfSubMenu; a++) {
                this.view["flxOption" + a].width = this.generalizeWidthInPxPulsate(72) + "px";
                this.view["flxOption" + a].height = this.view["flxOption" + a].width;
            }
            this.generateCenterYArray();
            for (a = 1; a <= this._noOfSubMenu; a++) {
                this.view["flxOption" + a].centerY = this.centerYArray[a - 1] + "dp";
                this.view["lblOption" + a].centerY = this.centerYArray[a - 1] + "dp";
                this.view["lblOption" + a].right = "-150%";
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function showItemsAnimationEnd
         * @scope private
         * @description to set onClick of primary button after Show animation ends
         */
        showItemsAnimationEnd: function(itemNum) {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            if (itemNum === this._noOfSubMenu) {
                this.view.flxMenu.onClick = this.emptyFunction.bind(this);
                this.view.flxMenu1.onClick = this.hideMenu.bind(this);
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function hideItemsAnimationEnd
         * @scope private
         * @description to set onClick of primary button after hide animation ends
         */
        hideItemsAnimationEnd: function(itemNum) {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            if (itemNum === this._noOfSubMenu) {
                this.view.flxMenu.onClick = this.showMenu.bind(this);
                this.view.flxMenu1.onClick = this.emptyFunction.bind(this);
                this.view.imgOverlay.isVisible = false;
                this.rePosParent();
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function rotatePrimaryButtonIcon
         * @scope private
         * @description to animate the primary button icon
         */
        rotatePrimaryButtonIcon: function(angle) {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            if (this._noOfSubMenu !== 0) {
                var trans100 = kony.ui.makeAffineTransform();
                trans100.rotate(angle);
                this.view.imgIcon.animate(kony.ui.createAnimation({
                    "100": {
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                        "transform": trans100
                    }
                }), {
                    "delay": 0,
                    "iterationCount": 1,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS,
                    "duration": 0.40
                }, {});
                this.view.imgIcon2.animate(kony.ui.createAnimation({
                    "100": {
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                        "transform": trans100
                    }
                }), {
                    "delay": 0,
                    "iterationCount": 1,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS,
                    "duration": 0.40
                }, {});
            } else {
                //	this.view.flxMenu.onClick = this.showMenu.bind(this);
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function emptyFunction
         * @scope private
         * @description to assign this function on onclick
         */
        emptyFunction: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function handlePrimaryButtonOnClick
         * @scope private
         * @description to handle onClickPrimaryButton when there is no event assigned by user
         */
        handlePrimaryButtonOnClick: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            if (this._noOfSubMenu !== 0) {
                this.view.flxMenu.onClick = this.emptyFunction.bind(this);
            }
            var self = this;
            if (self.onClickPrimaryButton) {
                self.onClickPrimaryButton();
                this.view.flxMenu.onClick = this.showMenu.bind(this);
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function handleMenuItem1onClick
         * @scope private
         * @description to assign onClick of Menu1
         */
        handleMenuItem1onClick: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            this.view.flxOption1.onClick = this.onClickOfMenuItem1.bind(this);
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function onClickOfMenuItem1
         * @scope private
         * @description to handle onClickOfMenuItem1 when there is no event assigned by user
         */
        onClickOfMenuItem1: function() {
            var self = this;
            if (self.onClickMenuItem1 !== null && self.onClickMenuItem1 !== undefined && typeof(self.onClickMenuItem1) == "function") {
                self.onClickMenuItem1();
            }
            this.hideMenu();
        },
        /**
         * @function handleMenuItem2onClick
         * @scope private
         * @description to assign onClick of Menu2
         */
        handleMenuItem2onClick: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            this.view.flxOption2.onClick = this.onClickOfMenuItem2.bind(this);
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function onClickOfMenuItem2
         * @scope private
         * @description to handle onClickOfMenuItem2 when there is no event assigned by user
         */
        onClickOfMenuItem2: function() {
            var self = this;
            if (self.onClickMenuItem2 !== null && self.onClickMenuItem2 !== undefined && typeof(self.onClickMenuItem2) !== "undefined") {
                self.onClickMenuItem2();
            }
            this.hideMenu();
        },
        /**
         * @function handleMenuItem3onClick
         * @scope private
         * @description to assign onClick of Menu3
         */
        handleMenuItem3onClick: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            this.view.flxOption3.onClick = this.onClickOfMenuItem3.bind(this);
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function onClickOfMenuItem3
         * @scope private
         * @description to handle onClickOfMenuItem3 when there is no event assigned by user
         */
        onClickOfMenuItem3: function() {
            var self = this;
            if (self.onClickMenuItem3 !== null && self.onClickMenuItem3 !== undefined && typeof(self.onClickMenuItem3) == "function") {
                self.onClickMenuItem3();
            }
            this.hideMenu();
        },
        /**
         * @function handleMenuItem4onClick
         * @scope private
         * @description to assign onClick of Menu4
         */
        handleMenuItem4onClick: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            this.view.flxOption4.onClick = this.onClickOfMenuItem4.bind(this);
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function onClickOfMenuItem4
         * @scope private
         * @description to handle onClickOfMenuItem4 when there is no event assigned by user
         */
        onClickOfMenuItem4: function() {
            var self = this;
            if (self.onClickMenuItem4 !== null && self.onClickMenuItem4 !== undefined && typeof(self.onClickMenuItem4) == "function") {
                self.onClickMenuItem4();
            }
            this.hideMenu();
        },
        /**
         * @function handleMenuItem5onClick
         * @scope private
         * @description to assign onClick of Menu5
         */
        handleMenuItem5onClick: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            this.view.flxOption5.onClick = this.onClickOfMenuItem5.bind(this);
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function onClickOfMenuItem5
         * @scope private
         * @description to handle onClickOfMenuItem5 when there is no event assigned by user
         */
        onClickOfMenuItem5: function() {
            var self = this;
            if (self.onClickMenuItem5 !== null && self.onClickMenuItem5 !== undefined && typeof(self.onClickMenuItem5) == "function") {
                self.onClickMenuItem5();
            }
            this.hideMenu();
        },
        /**
         * @function setOverlay
         * @scope private
         * @description to handle overlay
         */
        setOverlay: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            if ((this._enableOverlay === true) && (this._noOfSubMenu > 0)) {
                this.view.imgOverlay.isVisible = true;
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function generateCenterYArray
         * @scope private
         * @description to handle difference between menu options
         */
        generateCenterYArray: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            this.centerYArray = [];
            var centerY = parseFloat(this.view.flxMenu1.centerY);
            this.centerYArray.push(centerY - 70);
            for (var i = 1; i < this._noOfSubMenu; i++) {
                this.centerYArray.push((this.centerYArray[i - 1]) - 65);
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function generateCenterYArray
         * @scope private
         * @description to handle difference between menu options
         */
        initializeMenuItemsUI: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            for (var z = 1; z <= 5; z++) {
                this.view["lblOption" + z].isVisible = false;
            }
            if (this._menuItemType !== "Only Image") {
                for (var y = 1; y <= 5; y++) {
                    if (this.view["flxOption" + y].isVisible === true) {
                        this.view["lblOption" + y].isVisible = true;
                    } else {
                        break;
                    }
                }
            }
            if (this.view.flxOption1.isVisible === true) {
                this._SubMenuAnimation = "true";
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function generalizeWidthInPx
         * @description Its used to calculate width in px for device resolution.
         * @param px
         */
        generalizeWidthInPxPulsate: function(px) {
            try {
                konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
                px = parseFloat(px);
                if (!isNaN(px)) {
                    return parseInt(px * (kony.os.deviceInfo().deviceWidth / parseInt(360)));
                }
                return null;
            } catch (exception) {
                kony.logger.error(JSON.stringify(exception), kony.logger.EXCEPTION);
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function generalizeHeightInPx
         * @description Its used to calculate height in px for device resolution.
         * @param px
         */
        generalizeHeightInPxPulsate: function(px) {
            try {
                konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
                px = parseFloat(px);
                if (!isNaN(px)) {
                    return parseInt(px * (kony.os.deviceInfo().deviceHeight / parseInt(667)));
                }
                return null;
            } catch (exception) {
                kony.logger.error(JSON.stringify(exception), kony.logger.EXCEPTION);
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function fitToParent
         * @scope private
         * @description to change the height and width of component to 100%
         */
        fitToParent: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            this.view.height = "100%";
            this.view.width = "100%";
            this.view.centerX = "50%";
            this.view.centerY = "50%";
            this.view.flxMenu1.animate(kony.ui.createAnimation({
                "100": {
                    "stepConfig": {
                        "timingFunction": kony.anim.EASE
                    },
                    "opacity": 1
                }
            }), {
                "delay": 0,
                "iterationCount": 1,
                "fillMode": kony.anim.FILL_MODE_FORWARDS,
                "duration": 0
            }, {
                "animationEnd": this.callAnimation
            });
            this.view.flxMenu1.isVisible = true;
            this.view.flxMenu.isVisible = false;
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function callAnimation
         * @scope private
         * @description to call all the animations to show menu items
         */
        callAnimation: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            this.setOverlay();
            this.rotatePrimaryButtonIcon(135);
            this.showMenuItems();
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function gettingFrame
         * @scope private
         * @description to get the frame
         */
        gettingFrame: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            this._frame = this.view.frame;
            this._deviceInfo = kony.os.deviceInfo();
            this._widthInDp = this._deviceInfo.screenWidth;
            this._heightInDp = this._deviceInfo.screenHeight;
            this._widthInPx = this._deviceInfo.deviceWidth;
            this._heightInPx = this._deviceInfo.deviceHeight;
            this._centerX = (this._frame.x + (this._frame.width) / 2) + "dp";
            this._centerY = (this._frame.y + (this._frame.height) / 2) + "dp";
            this.view.flxMenu1.centerX = this._centerX;
            this.view.flxMenu1.centerY = this._centerY;
            this.createMenuItems();
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function rePosParent
         * @scope private
         * @description to change the height and width of component to intial
         */
        rePosParent: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            this.view.centerX = this._centerX;
            this.view.centerY = this._centerY;
            this.view.height = this.view.flxMenu.height;
            this.view.width = this.view.flxMenu.width;
            this.view.flxMenu.isVisible = true;
            this.view.flxMenu1.isVisible = false;
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        },
        /**
         * @function animationStarts
         * @scope private
         * @description initial animation to change the opacity of primary button
         */
        animationStarts: function() {
            konymp.logger.debug("", konymp.logger.FUNCTION_ENTRY);
            if (this._noOfSubMenu === 0) {} else {
                this.view.flxMenu1.animate(kony.ui.createAnimation({
                    "100": {
                        "stepConfig": {
                            "timingFunction": kony.anim.EASE
                        },
                        "opacity": 0.9
                    }
                }), {
                    "delay": 0,
                    "iterationCount": 1,
                    "fillMode": kony.anim.FILL_MODE_FORWARDS,
                    "duration": 0
                }, {
                    "animationEnd": this.fitToParent
                });
            }
            konymp.logger.debug("", konymp.logger.FUNCTION_EXIT);
        }
    };
});
define("com/konymp/floatingaction/floatingactionControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("com/konymp/floatingaction/floatingactionController", ["com/konymp/floatingaction/userfloatingactionController", "com/konymp/floatingaction/floatingactionControllerActions"], function() {
    var controller = require("com/konymp/floatingaction/userfloatingactionController");
    var actions = require("com/konymp/floatingaction/floatingactionControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        defineSetter(this, "sknMenuItem1Text", function(val) {
            this.view.lblOption1.skin = val;
        });
        defineGetter(this, "sknMenuItem1Text", function() {
            return this.view.lblOption1.skin;
        });
        defineSetter(this, "primaryButtonBGSrc", function(val) {
            this.view.imgMain.src = val;
        });
        defineGetter(this, "primaryButtonBGSrc", function() {
            return this.view.imgMain.src;
        });
        defineSetter(this, "menuItem1BGSrc", function(val) {
            this.view.imgBG1.src = val;
        });
        defineGetter(this, "menuItem1BGSrc", function() {
            return this.view.imgBG1.src;
        });
        defineSetter(this, "sknMenuItem2Text", function(val) {
            this.view.lblOption2.skin = val;
        });
        defineGetter(this, "sknMenuItem2Text", function() {
            return this.view.lblOption2.skin;
        });
        defineSetter(this, "menuItem5BGSrc", function(val) {
            this.view.imgBG5.src = val;
        });
        defineGetter(this, "menuItem5BGSrc", function() {
            return this.view.imgBG5.src;
        });
        defineSetter(this, "imgPrimaryIcon", function(val) {
            this.view.imgIcon.src = val;
        });
        defineGetter(this, "imgPrimaryIcon", function() {
            return this.view.imgIcon.src;
        });
        defineSetter(this, "menuItem4BGSrc", function(val) {
            this.view.imgBG4.src = val;
        });
        defineGetter(this, "menuItem4BGSrc", function() {
            return this.view.imgBG4.src;
        });
        defineSetter(this, "menuItem3BGSrc", function(val) {
            this.view.imgBG3.src = val;
        });
        defineGetter(this, "menuItem3BGSrc", function() {
            return this.view.imgBG3.src;
        });
        defineSetter(this, "menuItem2BGSrc", function(val) {
            this.view.imgBG2.src = val;
        });
        defineGetter(this, "menuItem2BGSrc", function() {
            return this.view.imgBG2.src;
        });
        defineSetter(this, "menuItem1IconSrc", function(val) {
            this.view.imgOption1.src = val;
        });
        defineGetter(this, "menuItem1IconSrc", function() {
            return this.view.imgOption1.src;
        });
        defineSetter(this, "menuItem3IconSrc", function(val) {
            this.view.imgOption3.src = val;
        });
        defineGetter(this, "menuItem3IconSrc", function() {
            return this.view.imgOption3.src;
        });
        defineSetter(this, "menuItem5IconSrc", function(val) {
            this.view.imgOption5.src = val;
        });
        defineGetter(this, "menuItem5IconSrc", function() {
            return this.view.imgOption5.src;
        });
        defineSetter(this, "menuItem4IconSrc", function(val) {
            this.view.imgOption4.src = val;
        });
        defineGetter(this, "menuItem4IconSrc", function() {
            return this.view.imgOption4.src;
        });
        defineSetter(this, "sknMenuItem3Text", function(val) {
            this.view.lblOption3.skin = val;
        });
        defineGetter(this, "sknMenuItem3Text", function() {
            return this.view.lblOption3.skin;
        });
        defineSetter(this, "menuItem2IconSrc", function(val) {
            this.view.imgOption2.src = val;
        });
        defineGetter(this, "menuItem2IconSrc", function() {
            return this.view.imgOption2.src;
        });
        defineSetter(this, "menuItem2Text", function(val) {
            this.view.lblOption2.text = val;
        });
        defineGetter(this, "menuItem2Text", function() {
            return this.view.lblOption2.text;
        });
        defineSetter(this, "menuItem5Text", function(val) {
            this.view.lblOption5.text = val;
        });
        defineGetter(this, "menuItem5Text", function() {
            return this.view.lblOption5.text;
        });
        defineSetter(this, "menuItem3Text", function(val) {
            this.view.lblOption3.text = val;
        });
        defineGetter(this, "menuItem3Text", function() {
            return this.view.lblOption3.text;
        });
        defineSetter(this, "menuItem4Text", function(val) {
            this.view.lblOption4.text = val;
        });
        defineGetter(this, "menuItem4Text", function() {
            return this.view.lblOption4.text;
        });
        defineSetter(this, "menuItem1Text", function(val) {
            this.view.lblOption1.text = val;
        });
        defineGetter(this, "menuItem1Text", function() {
            return this.view.lblOption1.text;
        });
        defineSetter(this, "sknMenuItem4Text", function(val) {
            this.view.lblOption4.skin = val;
        });
        defineGetter(this, "sknMenuItem4Text", function() {
            return this.view.lblOption4.skin;
        });
        defineSetter(this, "sknMenuItem5Text", function(val) {
            this.view.lblOption5.skin = val;
        });
        defineGetter(this, "sknMenuItem5Text", function() {
            return this.view.lblOption5.skin;
        });
        defineSetter(this, "imgBGOverlaySrc", function(val) {
            this.view.imgOverlay.src = val;
        });
        defineGetter(this, "imgBGOverlaySrc", function() {
            return this.view.imgOverlay.src;
        });
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konymp/floatingaction/floatingaction',[],function() {
    return function(controller) {
        var floatingaction = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "88%",
            "centerY": "91%",
            "clipBounds": true,
            "isMaster": true,
            "height": "70px",
            "id": "floatingaction",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "79px"
        }, controller.args[0], "floatingaction"), extendConfig({}, controller.args[1], "floatingaction"), extendConfig({}, controller.args[2], "floatingaction"));
        floatingaction.setDefaultUnit(kony.flex.DP);
        var flxMenu = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "50%",
            "clipBounds": false,
            "height": "79px",
            "id": "flxMenu",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "79px",
            "zIndex": 5
        }, controller.args[0], "flxMenu"), extendConfig({}, controller.args[1], "flxMenu"), extendConfig({}, controller.args[2], "flxMenu"));
        flxMenu.setDefaultUnit(kony.flex.DP);
        var imgMain = new kony.ui.Image2(extendConfig({
            "height": "100%",
            "id": "imgMain",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "konymp_fa_bg.png",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgMain"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgMain"), extendConfig({}, controller.args[2], "imgMain"));
        var imgIcon = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "imgIcon",
            "isVisible": true,
            "skin": "slImage",
            "src": "konymp_fa_icon_plus.png",
            "width": "100%",
            "zIndex": 2
        }, controller.args[0], "imgIcon"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgIcon"), extendConfig({}, controller.args[2], "imgIcon"));
        flxMenu.add(imgMain, imgIcon);
        var flxMenu1 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "centerY": "50%",
            "clipBounds": false,
            "height": "79px",
            "id": "flxMenu1",
            "isVisible": false,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "79px",
            "zIndex": 5
        }, controller.args[0], "flxMenu1"), extendConfig({}, controller.args[1], "flxMenu1"), extendConfig({}, controller.args[2], "flxMenu1"));
        flxMenu1.setDefaultUnit(kony.flex.DP);
        var imgMain2 = new kony.ui.Image2(extendConfig({
            "height": "100%",
            "id": "imgMain2",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "konymp_fa_bg.png",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgMain2"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgMain2"), extendConfig({}, controller.args[2], "imgMain2"));
        var imgIcon2 = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "imgIcon2",
            "isVisible": true,
            "skin": "slImage",
            "src": "konymp_fa_icon_plus.png",
            "width": "100%",
            "zIndex": 2
        }, controller.args[0], "imgIcon2"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgIcon2"), extendConfig({}, controller.args[2], "imgIcon2"));
        flxMenu1.add(imgMain2, imgIcon2);
        var flxOption1 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "150%",
            "centerY": "85%",
            "clipBounds": false,
            "height": "11%",
            "id": "flxOption1",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "20%",
            "zIndex": 3
        }, controller.args[0], "flxOption1"), extendConfig({}, controller.args[1], "flxOption1"), extendConfig({}, controller.args[2], "flxOption1"));
        flxOption1.setDefaultUnit(kony.flex.DP);
        var imgOption1 = new kony.ui.Image2(extendConfig({
            "height": "100%",
            "id": "imgOption1",
            "isVisible": true,
            "left": "0%",
            "skin": "slImage",
            "src": "konymp_fa_itempen.png",
            "top": "0%",
            "width": "100%",
            "zIndex": 2
        }, controller.args[0], "imgOption1"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgOption1"), extendConfig({}, controller.args[2], "imgOption1"));
        var imgBG1 = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "imgBG1",
            "isVisible": true,
            "left": "10%",
            "skin": "slImage",
            "src": "konymp_fa_itemiconbg.png",
            "top": "10%",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgBG1"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgBG1"), extendConfig({}, controller.args[2], "imgBG1"));
        flxOption1.add(imgOption1, imgBG1);
        var lblOption1 = new kony.ui.Label(extendConfig({
            "centerY": "85%",
            "id": "lblOption1",
            "isVisible": true,
            "right": "-350%",
            "skin": "konympfasknLblBlackSmall",
            "text": "Label",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 3
        }, controller.args[0], "lblOption1"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblOption1"), extendConfig({
            "renderAsAnchor": false,
            "textCopyable": false
        }, controller.args[2], "lblOption1"));
        var flxOption2 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "150%",
            "centerY": "85%",
            "clipBounds": false,
            "height": "56dp",
            "id": "flxOption2",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "56dp",
            "zIndex": 3
        }, controller.args[0], "flxOption2"), extendConfig({}, controller.args[1], "flxOption2"), extendConfig({}, controller.args[2], "flxOption2"));
        flxOption2.setDefaultUnit(kony.flex.DP);
        var imgOption2 = new kony.ui.Image2(extendConfig({
            "height": "100%",
            "id": "imgOption2",
            "isVisible": true,
            "left": "0%",
            "skin": "slImage",
            "src": "konymp_fa_itemstar.png",
            "top": "0%",
            "width": "100%",
            "zIndex": 2
        }, controller.args[0], "imgOption2"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgOption2"), extendConfig({}, controller.args[2], "imgOption2"));
        var imgBG2 = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "imgBG2",
            "isVisible": true,
            "skin": "slImage",
            "src": "konymp_fa_itemiconbg.png",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgBG2"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgBG2"), extendConfig({}, controller.args[2], "imgBG2"));
        flxOption2.add(imgOption2, imgBG2);
        var lblOption2 = new kony.ui.Label(extendConfig({
            "centerY": "85%",
            "id": "lblOption2",
            "isVisible": true,
            "right": "-350%",
            "skin": "konympfasknLblBlackSmall",
            "text": "Label",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 3
        }, controller.args[0], "lblOption2"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblOption2"), extendConfig({
            "renderAsAnchor": false,
            "textCopyable": false
        }, controller.args[2], "lblOption2"));
        var flxOption3 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "150%",
            "centerY": "85%",
            "clipBounds": false,
            "height": "56dp",
            "id": "flxOption3",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "56dp",
            "zIndex": 3
        }, controller.args[0], "flxOption3"), extendConfig({}, controller.args[1], "flxOption3"), extendConfig({}, controller.args[2], "flxOption3"));
        flxOption3.setDefaultUnit(kony.flex.DP);
        var imgOption3 = new kony.ui.Image2(extendConfig({
            "height": "100%",
            "id": "imgOption3",
            "isVisible": true,
            "left": "0%",
            "skin": "slImage",
            "src": "konymp_fa_itemprofile.png",
            "top": "0%",
            "width": "100%",
            "zIndex": 2
        }, controller.args[0], "imgOption3"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgOption3"), extendConfig({}, controller.args[2], "imgOption3"));
        var imgBG3 = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "imgBG3",
            "isVisible": true,
            "left": "10%",
            "skin": "slImage",
            "src": "konymp_fa_itemiconbg.png",
            "top": "10%",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgBG3"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgBG3"), extendConfig({}, controller.args[2], "imgBG3"));
        flxOption3.add(imgOption3, imgBG3);
        var lblOption3 = new kony.ui.Label(extendConfig({
            "centerY": "85%",
            "id": "lblOption3",
            "isVisible": true,
            "right": "-350%",
            "skin": "konympfasknLblBlackSmall",
            "text": "Label",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 3
        }, controller.args[0], "lblOption3"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblOption3"), extendConfig({
            "renderAsAnchor": false,
            "textCopyable": false
        }, controller.args[2], "lblOption3"));
        var flxOption4 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "150%",
            "centerY": "85%",
            "clipBounds": false,
            "height": "56dp",
            "id": "flxOption4",
            "isVisible": false,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "56dp",
            "zIndex": 3
        }, controller.args[0], "flxOption4"), extendConfig({}, controller.args[1], "flxOption4"), extendConfig({}, controller.args[2], "flxOption4"));
        flxOption4.setDefaultUnit(kony.flex.DP);
        var imgOption4 = new kony.ui.Image2(extendConfig({
            "height": "100%",
            "id": "imgOption4",
            "isVisible": true,
            "left": "0%",
            "skin": "slImage",
            "src": "konymp_fa_itemdel.png",
            "top": "0%",
            "width": "100%",
            "zIndex": 2
        }, controller.args[0], "imgOption4"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgOption4"), extendConfig({}, controller.args[2], "imgOption4"));
        var imgBG4 = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "imgBG4",
            "isVisible": true,
            "left": "10%",
            "skin": "slImage",
            "src": "konymp_fa_itemiconbg.png",
            "top": "10%",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgBG4"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgBG4"), extendConfig({}, controller.args[2], "imgBG4"));
        flxOption4.add(imgOption4, imgBG4);
        var lblOption4 = new kony.ui.Label(extendConfig({
            "centerY": "85%",
            "id": "lblOption4",
            "isVisible": false,
            "right": "-350%",
            "skin": "konympfasknLblBlackSmall",
            "text": "Label",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 3
        }, controller.args[0], "lblOption4"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblOption4"), extendConfig({
            "renderAsAnchor": false,
            "textCopyable": false
        }, controller.args[2], "lblOption4"));
        var flxOption5 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "150%",
            "centerY": "85%",
            "clipBounds": false,
            "height": "56dp",
            "id": "flxOption5",
            "isVisible": false,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "slFbox",
            "width": "56dp",
            "zIndex": 3
        }, controller.args[0], "flxOption5"), extendConfig({}, controller.args[1], "flxOption5"), extendConfig({}, controller.args[2], "flxOption5"));
        flxOption5.setDefaultUnit(kony.flex.DP);
        var imgOption5 = new kony.ui.Image2(extendConfig({
            "height": "100%",
            "id": "imgOption5",
            "isVisible": true,
            "left": "0%",
            "skin": "slImage",
            "src": "konymp_fa_itemprofile.png",
            "top": "0%",
            "width": "100%",
            "zIndex": 2
        }, controller.args[0], "imgOption5"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgOption5"), extendConfig({}, controller.args[2], "imgOption5"));
        var imgBG5 = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "centerY": "50%",
            "height": "100%",
            "id": "imgBG5",
            "isVisible": true,
            "left": "10%",
            "skin": "slImage",
            "src": "konymp_fa_itemiconbg.png",
            "top": "10%",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgBG5"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgBG5"), extendConfig({}, controller.args[2], "imgBG5"));
        flxOption5.add(imgOption5, imgBG5);
        var lblOption5 = new kony.ui.Label(extendConfig({
            "centerY": "85%",
            "id": "lblOption5",
            "isVisible": false,
            "right": "-350%",
            "skin": "konympfasknLblBlackSmall",
            "text": "Label",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 3
        }, controller.args[0], "lblOption5"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblOption5"), extendConfig({
            "renderAsAnchor": false,
            "textCopyable": false
        }, controller.args[2], "lblOption5"));
        var imgOverlay = new kony.ui.Image2(extendConfig({
            "height": "100%",
            "id": "imgOverlay",
            "isVisible": false,
            "left": "0%",
            "skin": "slImage",
            "src": "konymp_fa_fade.png",
            "top": "0%",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "imgOverlay"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgOverlay"), extendConfig({}, controller.args[2], "imgOverlay"));
        floatingaction.add(flxMenu, flxMenu1, flxOption1, lblOption1, flxOption2, lblOption2, flxOption3, lblOption3, flxOption4, lblOption4, flxOption5, lblOption5, imgOverlay);
        return floatingaction;
    }
})
;
define('com/konymp/floatingaction/floatingactionConfig',[],function() {
    return {
        "properties": [{
            "name": "sknMenuItem1Text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "primaryButtonBGSrc",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "menuItem1BGSrc",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "sknMenuItem2Text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "menuItem5BGSrc",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "imgPrimaryIcon",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "menuItem4BGSrc",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "menuItem3BGSrc",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "menuItem2BGSrc",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "menuItem1IconSrc",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "menuItem3IconSrc",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "menuItem5IconSrc",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "menuItem4IconSrc",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "sknMenuItem3Text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "menuItem2IconSrc",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "menuItem2Text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "menuItem5Text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "menuItem3Text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "menuItem4Text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "menuItem1Text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "sknMenuItem4Text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "sknMenuItem5Text",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "imgBGOverlaySrc",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "isVisibleMenuItem1",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "isVisibleMenuItem2",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "isVisibleMenuItem3",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "isVisibleMenuItem4",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "isVisibleMenuItem5",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "menuItemType",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "animationType",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "enableOverlay",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": [],
        "events": ["onClickPrimaryButton", "onClickMenuItem1", "onClickMenuItem2", "onClickMenuItem3", "onClickMenuItem4", "onClickMenuItem5"]
    }
});

define('com/konymp/timepicker/analytics',[],function() {
    return {
        analyticsHost: "https://sampleapps.konycloud.com:443/services/data/v1/analytics/objects/log",
        constructBody: function() {
            try {
                var date = new Date();
                var deviceInfo = this.getDeviceOS();
                var body = {
                    "deviceModel": deviceInfo.model,
                    "Locale": kony.i18n.getCurrentDeviceLocale().language,
                    "Platform": deviceInfo.name,
                    "PlatformVersion": deviceInfo.version,
                    "appId": appConfig.appId,
                    "serviceUrl": appConfig.serviceUrl,
                    "itemGuid": "ca2add381be84685b19edefc26da8899",
                    "assetName": "com.konymp.timepicker",
                    "assetVersion": "1.0.0",
                    "releaseMode": !appConfig.isDebug,
                    "konySdkVersion": kony.sdk.version,
                    "date": date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear(),
                    "endpointId": this.generateUniqueId(),
                    "deviceHeight": deviceInfo.deviceHeight,
                    "deviceWidth": deviceInfo.deviceWidth,
                    "kuid": "ud64d5f180f14c83802119145c023138",
                };
                return body;
            } catch (exception) {
                kony.print(JSON.stringify(exception));
            }
        },
        notifyAnalytics: function() {
            try {
                if (this.checkInternetConnectivity() && this.isItFirstTime()) {
                    var httpclient = new kony.net.HttpRequest();
                    httpclient.open(constants.HTTP_METHOD_POST, this.analyticsHost);
                    httpclient.setRequestHeader("Content-Type", "application/json");
                    httpclient.send(JSON.stringify(this.constructBody()));
                }
            } catch (exception) {
                kony.print(JSON.stringify(exception));
            }
        },
        getDeviceOS: function() {
            try {
                return kony.os.deviceInfo();
            } catch (exception) {
                kony.print(JSON.stringify(exception));
            }
        },
        generateUniqueId: function() {
            try {
                return kony.crypto.createHMacHash("SHA512", this.getDeviceOS().deviceid, "KonyAnalytics");
            } catch (exception) {
                kony.print(JSON.stringify(exception));
            }
        },
        isItFirstTime: function() {
            var bodyDetails = this.constructBody();
            var assetVersion = kony.store.getItem(bodyDetails.assetName + "Version");
            if (kony.sdk.isNullOrUndefined(assetVersion) || assetVersion != bodyDetails.assetVersion) {
                kony.store.setItem(bodyDetails.assetName + "Version", bodyDetails.assetVersion);
                return true;
            } else {
                return false;
            }
        },
        checkInternetConnectivity: function() {
            return kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY);
        }
    };
});

define('com/konymp/timepicker/konyLogger',[],function() {
    /**
     * @module KonyLogger v1.2
     * @author AyyappaSwamy.Thatavarthy / Praharshita.Krishna
     * @category functionality
     * @description This module implements the KonyLogger class
     * KonyLogger provides the functionality of 6 logging levels viz.,
     * 1.TRACE	2.DEBUG	 3.INFO  4.WARN  5.ERROR 6.SILENT
     * It also supports capturing events viz.,
     * DEFAULT, FUNCTION_ENTRY, FUNCTION_EXIT, EXCEPTION, SUCCESS_CALLBACK, ERROR_CALLBACK, SERVICE_CALL, DATA_STORE
     * 2017 Kony Inc. 
     */
    /**
     * @member of  KonyLogger.js
     * @function KonyLogger
     * @param method - The function to be called to log the given message. 
     * When no parameter is passed, kony.print is called by default.
     * @returns an instance of KonyLogger class.
     * @description - This is the constructor for KonyLogger. 
     * This method initializes the instance created.
     **/
    var KonyLogger = function() {
        this.printMethod = kony.print;
        this.reuseableComponentName = arguments[0] || "appContext";
        var loggerGenerator = function() {
            this.trace = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "TRACE", message, event);
            };
            this.debug = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "DEBUG", message, event);
            };
            this.info = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "INFO", message, event);
            };
            this.warn = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "WARN", message, event);
            };
            this.error = function(message, event) {
                var caller;
                try {
                    caller = arguments.callee.caller.name;
                } catch (err) {
                    caller = "Global";
                }
                this.logMethod(caller, "ERROR", message, event);
            };
        };
        this.setLogLevel = function(logLevel) {
            if (this.isValidLogLevel(logLevel)) {
                if (typeof logLevel === "string") {
                    this.currentLogLevel = this.logLevels[logLevel];
                } else if (typeof logLevel === "number") {
                    this.currentLogLevel = logLevel;
                }
                var logMethods = Object.keys(this.logLevels);
                for (var i = 0; i < logMethods.length; i++) {
                    var methodName = logMethods[i].toLowerCase();
                    this[methodName] = (i < this.currentLogLevel) ? function() {} : (new loggerGenerator())[methodName];
                }
                return true;
            } else {
                return false;
            }
        };
        this.enableServerLogging = false;
        this.logMethod = function(functionName, logLevel, message, eventType) {
            var logObj = {
                "component": this.reuseableComponentName || "",
                "event": this.supportedEventTypes[eventType] || this.supportedEventTypes[this.DEFAULT],
                "function": functionName || "",
                "timestamp": KonyLogger.Utils.getDateTimeStamp() || "",
                "level": logLevel || "",
                "message": message || ""
            };
            if (this.enableServerLogging === true) {
                if ((KNYMetricsService !== undefined) && (KNYMetricsService !== null) && (KNYMetricsService !== "")) {
                    if (typeof KNYMetricsService.sendEvent === "function") {
                        /** sendEvent params - eventType, subEventType, formID, widgetID, flowTag, metaInfo{JSON} **/
                        KNYMetricsService.sendEvent("Custom", "KonyLogger", "MarketPlaceComponent", logObj.component, null, logObj);
                    }
                }
            }
            this.printMethod(JSON.stringify(logObj, null, '\t'));
        };
        this.setLogLevel("TRACE");
        /**
         * @descrption This creates an error object
         * @property code - This is the error code for the errorObject
         * @property message - This is the message for the errorObject
         **/
        this.getErrorObject = function(code, message) {
            var obj = {
                "code": code.toFixed(),
                "message": message || ""
            };
            return obj;
        };
    };
    /**
     * @member of  KonyLogger
     * @property logLevels - This enum holds the 6 levels of logging and their order.
     **/
    KonyLogger.prototype.logLevels = {
        "TRACE": 0,
        "DEBUG": 1,
        "INFO": 2,
        "WARN": 3,
        "ERROR": 4,
        "SILENT": 5
    };
    /**
     * @member of  KonyLogger
     * @property eventTypes - This array holds 8 types of events.
     **/
    KonyLogger.prototype.supportedEventTypes = ["DEFAULT", "FUNCTION_ENTRY", "FUNCTION_EXIT", "SUCCESS_CALLBACK", "ERROR_CALLBACK", "EXCEPTION", "SERVICE_CALL", "DATA_STORE"];
    /** KonyLogger EventTypes**/
    KonyLogger.prototype.DEFAULT = 0;
    KonyLogger.prototype.FUNCTION_ENTRY = 1;
    KonyLogger.prototype.FUNCTION_EXIT = 2;
    KonyLogger.prototype.SUCCESS_CALLBACK = 3;
    KonyLogger.prototype.ERROR_CALLBACK = 4;
    KonyLogger.prototype.EXCEPTION = 5;
    KonyLogger.prototype.SERVICE_CALL = 6;
    KonyLogger.prototype.DATA_STORE = 7;
    /**
     * @member of  KonyLogger
     * @property defaultLogLevel - This property holds the default logLevel
     * It is intialised to "TRACE".
     **/
    KonyLogger.prototype.defaultLogLevel = KonyLogger.prototype.logLevels["TRACE"];
    /**
     * @member of  KonyLogger
     * @function isValidLogLevel
     * @param logLevel - (string or number)
     * @description - This method validates the logLevel parameter with the enum logLevels
     * @return boolean
     **/
    KonyLogger.prototype.isValidLogLevel = function(logLevel) {
        if ((logLevel !== undefined) && (logLevel !== null) && (logLevel !== "")) {
            if (typeof logLevel === "string") {
                if (logLevel.toUpperCase() in this.logLevels) {
                    return true;
                } else {
                    return false;
                }
            } else if (typeof logLevel === "number") {
                for (var logLevelKey in this.logLevels) {
                    if (logLevel === this.logLevels.logLevelKey) {
                        return true;
                    }
                }
                return false;
            } else {
                return false;
            }
        }
    };
    /**
     * @member of  KonyLogger
     * @function getLogLevel
     * @param none
     * @description - This method returns the current log level of the instance
     * @return type number
     **/
    KonyLogger.prototype.getLogLevel = function() {
        return this.currentLogLevel;
    };
    /**
     * @member of  KonyLogger
     * @function setPrintMethod
     * @param method: type function - The method to print the log/message.
     * The default value is kony.print
     * @description - This method sets the current log method to 'method'
     * @return none
     **/
    KonyLogger.prototype.setPrintMethod = function(method) {
        if ((method !== undefined) && (method !== null) && (method !== "")) {
            if (typeof method === "function") {
                this.printMethod = method;
            }
        }
    };
    KonyLogger.Utils = {};
    /**
     * @member of  KonyLogger
     * @function getDateTimeStamp
     * @param none
     * @description - It returns the current date and time stamp in "DD/MM/YY HH:MM AM/PM" format
     * @return type string
     **/
    KonyLogger.Utils.getDateTimeStamp = function() {
        var dateTimeStamp = "";
        var currentDateObj = new Date();
        dateTimeStamp += currentDateObj.getDate() + "/" + (currentDateObj.getMonth() + 1) + "/" + currentDateObj.getFullYear();
        dateTimeStamp += " ";
        var hours = currentDateObj.getHours();
        if (hours > 12) {
            dateTimeStamp += (hours - 12) + ":" + currentDateObj.getMinutes() + " PM";
        } else {
            dateTimeStamp += hours + ":" + currentDateObj.getMinutes() + " AM";
        }
        return dateTimeStamp;
    };
    return KonyLogger;
});

define('com/konymp/timepicker/ControllerImplementation.js',['com/konymp/timepicker/konyLogger'],function() {
    var konyLoggerModule = require('com/konymp/timepicker/konyLogger');
    var konymp = konymp || {};
    konymp.logger = (new konyLoggerModule("time picker Component")) || function() {};
    konymp.logger.setLogLevel("DEBUG");
    konymp.logger.enableServerLogging = true;
    var ControllerImplementation = function(componentInstance, componentName) {
        konymp.logger.trace("----------Entering ControllerImplementation Function---------", konymp.logger.FUNCTION_ENTRY);
        this.componentInstance = componentInstance;
        this.getNativeController = function() {
            try {
                konymp.logger.trace("----------Entering getNativeController Function---------", konymp.logger.FUNCTION_ENTRY);
                if (this.nativeControllerInstance === undefined) {
                    var deviceName = kony.os.deviceInfo().name;
                    var platformName = null;
                    if (deviceName.toLowerCase() === 'iphone' || deviceName.toLowerCase() === 'ipad') {
                        platformName = 'IOS';
                    } else if (deviceName.toLowerCase() === 'android') {
                        platformName = 'Android';
                    }
                    var nativeControllerPath = 'com/konymp/' + 'timepicker' + '/NativeController' + platformName + '.js';
                    var nativeController = require(nativeControllerPath);
                    this.nativeControllerInstance = new nativeController(this.componentInstance);
                }
                konymp.logger.trace("----------Exiting getNativeController Function---------", konymp.logger.FUNCTION_EXIT);
                return this.nativeControllerInstance;
            } catch (exception) {
                konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
                if (exception.type === "CUSTOM") {
                    throw exception;
                }
            }
        };
        this.show = function() {
            try {
                this.getNativeController().show();
            } catch (exception) {
                throw exception;
            }
        };
        this.hide = function() {
            try {
                this.getNativeController().hide();
            } catch (exception) {
                throw exception;
            }
        };
        this.setTime = function(time) {
            try {
                return this.getNativeController().setTime(time);
            } catch (exception) {
                throw exception;
            }
        };
        this.getTime = function() {
            try {
                return this.getNativeController().getTime();
            } catch (exception) {
                throw exception;
            }
        };
        this.setBackgroundColor = function(color) {
            try {
                this.getNativeController().setBackgroundColor(color);
            } catch (exception) {
                throw exception;
            }
        };
        this.is24HoursView = function() {
            try {
                return this.getNativeController().is24HoursView();
            } catch (exception) {
                throw exception;
            }
        };
        this.set24HoursView = function(enable) {
            try {
                this.getNativeController().set24HoursView(enable);
            } catch (exception) {
                throw exception;
            }
        };
        konymp.logger.trace("----------Exiting ControllerImplementation Function---------", konymp.logger.FUNCTION_EXIT);
    };
    return ControllerImplementation;
});

define('com/konymp/timepicker/Inherits',[], function() {
    var inheritsFrom = function(child, parent) {
        child.prototype = Object.create(parent.prototype);
        child.prototype.constructor = child;
    };
    return inheritsFrom;
});

define('com/konymp/timepicker/NativeController',[], function() {
    var konyLoggerModule = require('com/konymp/timepicker/konyLogger');
    var konymp = konymp || {};
    konymp.logger = (new konyLoggerModule("time picker Component")) || function() {};
    konymp.logger.setLogLevel("DEBUG");
    konymp.logger.enableServerLogging = true;
    var NativeController = function(componentInstance) {
        this.componentInstance = componentInstance;
    };
    NativeController.prototype.onTimeChanged = function(hours, minutes) {
        try {
            this.componentInstance.onTimeChanged(hours + ":" + minutes);
        } catch (exception) {
            konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
            throw exception;
        }
    };
    NativeController.prototype.getTime = function() {
        try {
            var hours = this.timePickerViewObj.getHour();
            var minutes = this.timePickerViewObj.getMinutes();
            return hours + ":" + minutes;
        } catch (exception) {
            konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
            throw exception;
        }
    };
    NativeController.prototype.show = function() {
        try {
            if (!this.componentInstance.viewAdded) {
                if (this.componentInstance.time !== undefined && this.componentInstance.time !== null && this.componentInstance.time.trim() !== "") {
                    this.setTime(this.componentInstance.time);
                }
                if (this.componentInstance.bgColor !== undefined && this.componentInstance.bgColor !== null && this.componentInstance.bgColor.trim() !== "" && this.componentInstance.bgColor.length === 6) {
                    this.setBackgroundColor(this.componentInstance.bgColor);
                }
                var count = this.timePickerViewObj.show(this.componentInstance.view.navTimepicker.getContainerView());
                if (count > 0) {
                    this.isTimerAdded = true;
                    this.componentInstance.viewAdded = true;
                }
            } else {
                this.timePickerViewObj.setVisibility(true);
            }
            this.componentInstance.view.forceLayout();
        } catch (exception) {
            konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
            throw exception;
        }
    };
    NativeController.prototype.hide = function() {
        try {
            this.timePickerViewObj.setVisibility(false);
        } catch (exception) {
            konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
            throw exception;
        }
    };
    NativeController.prototype.setBackgroundColor = function(color) {
        try {
            if (color !== undefined && color !== null && color.trim() !== "" && color.length === 6) {
                this.timePickerViewObj.setBackgroundColor(color);
            }
        } catch (exception) {
            konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
            throw exception;
        }
    };
    NativeController.prototype.is24HoursView = function() {
        try {
            throw "This API is not implemented for this platform";
        } catch (exception) {
            konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
            throw exception;
        }
    };
    NativeController.prototype.setTime = function(time) {
        try {
            throw "This API is not implemented for this platform";
        } catch (exception) {
            konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
            throw exception;
        }
    };
    return NativeController;
});

define('com/konymp/timepicker/NativeControllerAndroid',['./Inherits', './NativeController'], function(Inherits, NativeController) {
    var konyLoggerModule = require('com/konymp/timepicker/konyLogger');
    var konymp = konymp || {};
    var konympJumio = konympJumio || {};
    constants = constants || {};
    konymp.logger = (new konyLoggerModule("time picker Component")) || function() {};
    konymp.logger.setLogLevel("DEBUG");
    konymp.logger.enableServerLogging = true;
    var NativeControllerAndroid = function(componentInstance) {
        konympJumio.controllerContext = this;
        this.componentInstance = componentInstance;
        NativeController.call(this, this.componentInstance);
        this.importClasses();
    };
    Inherits(NativeControllerAndroid, NativeController);
    /**
     * @function importClasses
     * @private
     * @description: this function will import all the classes from the franeworks and store in the nativeClasses variable
     */
    NativeControllerAndroid.prototype.importClasses = function() {
        try {
            konymp.logger.trace("----------Entering importClasses Function---------", konymp.logger.FUNCTION_ENTRY);
            var konyContext = java.import("com.konylabs.android.KonyMain").getActContext();
            var timePickerView = java.import('com.konymp.timepicker.TimePickerView');
            this.timePickerViewObj = new timePickerView(konyContext);
            var timePickerListener = java.newClass('lisClass', 'java.lang.Object', ['com.konymp.timepicker.TimePickerListeners'], {
                onTimeChanged: this.onTimeChanged.bind(this)
            });
            this.timePickerViewObj.setListener(new timePickerListener());
            konymp.logger.trace("----------Exiting importClasses Function---------", konymp.logger.FUNCTION_EXIT);
        } catch (exception) {
            konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
            if (exception.type === "CUSTOM") {
                throw exception;
            }
        }
    };
    NativeControllerAndroid.prototype.removeFromParent = function() {
        try {
            if (this.isTimerAdded) {
                var previousViewGroup = this.timePickerViewObj.getParent();
                if (previousViewGroup !== null) {
                    var childCount = previousViewGroup.getChildCount();
                    if (childCount > 0) {
                        previousViewGroup.removeAllViews();
                    }
                }
            }
        } catch (exception) {
            throw exception;
        }
    };
    NativeControllerAndroid.prototype.setTime = function(time) {
        try {
            if (time !== undefined && time !== null && time.trim() !== "" && time.includes(':')) {
                var hoursAndMinutes = time.split(':');
                var hour = hoursAndMinutes[0];
                var minute = hoursAndMinutes[1];
                if (hour > 23 || hour < 0 || minute > 59 || minute[1] < 0) {
                    throw {
                        "error": "ComponentConfigurationError",
                        "message": "values are invalid",
                        "code": "2100"
                    };
                }
                this.timePickerViewObj.setHour(hour);
                this.timePickerViewObj.setMinute(minute);
            } else {
                throw {
                    "error": "ComponentConfigurationError",
                    "message": "values are invalid",
                    "code": "2100"
                };
            }
        } catch (exception) {
            konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
            throw exception;
        }
    };
    NativeControllerAndroid.prototype.is24HoursView = function() {
        try {
            return this.timePickerViewObj.is24HourView();
        } catch (exception) {
            konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
            throw exception;
        }
    };
    NativeControllerAndroid.prototype.set24HoursView = function(enable) {
        try {
            this.timePickerViewObj.set24HourView(enable);
        } catch (exception) {
            konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
            throw exception;
        }
    };
    return NativeControllerAndroid;
});

define('com/konymp/timepicker/NativeControllerIOS',['./Inherits', './NativeController'], function(Inherits, NativeController) {
    var konyLoggerModule = require('com/konymp/timepicker/konyLogger');
    var konymp = konymp || {};
    var konympJumio = konympJumio || {};
    konymp.logger = (new konyLoggerModule("Time Picker Component")) || function() {};
    konymp.logger.setLogLevel("DEBUG");
    konymp.logger.enableServerLogging = true;
    var NativeControllerIOS = function(componentInstance) {
        konympJumio.controllerContext = this;
        this.componentInstance = componentInstance;
        NativeController.call(this, this.componentInstance);
        this.importClasses();
    };
    Inherits(NativeControllerIOS, NativeController);
    /**
     * @function importClasses
     * @private
     * @description: this function will import all the classes from the frameworks and store in the nativeClasses variable
     */
    NativeControllerIOS.prototype.importClasses = function() {
        try {
            konymp.logger.trace("----------Entering importClasses Function---------", konymp.logger.FUNCTION_ENTRY);
            var timePickerView = objc.import('TimePickerView');
            this.timePickerViewObj = timePickerView.alloc().initWithCallbackAndView(this.onTimeChanged.bind(this), this.componentInstance.view.navTimepicker.getContainerView());
            konymp.logger.trace("----------Exiting importClasses Function---------", konymp.logger.FUNCTION_EXIT);
        } catch (exception) {
            konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
            if (exception.type === "CUSTOM") {
                throw exception;
            }
        }
    };
    NativeControllerIOS.prototype.setTime = function(time) {
        try {
            if (time.includes(':')) {
                var hoursAndMinutes = time.split(':');
                var meridiem = "";
                var hour = hoursAndMinutes[0];
                var minute = hoursAndMinutes[1];
                if (hour > 12) {
                    hour -= 12;
                    meridiem = "P";
                } else {
                    meridiem = "A";
                }
                if (hour > 12 || hour < 0 || minute > 59 || minute[1] < 0) {
                    throw {
                        "error": "ComponentConfigurationError",
                        "message": "values are invalid",
                        "code": "2100"
                    };
                }
                this.timePickerViewObj.setTime(hour + ":" + minute + " " + meridiem);
            } else {
                throw {
                    "error": "ComponentConfigurationError",
                    "message": "values are invalid",
                    "code": "2100"
                };
            }
        } catch (exception) {
            konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
            throw exception;
        }
    };
    NativeControllerIOS.prototype.is24HoursView = function() {
        try {
            throw "Platform doesn't support this API";
        } catch (exception) {
            konymp.logger.error(JSON.stringify(exception), konymp.logger.EXCEPTION);
            throw exception;
        }
    };
    return NativeControllerIOS;
});

define("com/konymp/timepicker/usertimepickerController", ['./ControllerImplementation.js'], function(ControllerImplementation) {
    return {
        constructor: function(baseConfig, layoutConfig, pspConfig) {
            var analytics = require("com/konymp/" + "timepicker" + "/analytics");
            analytics.notifyAnalytics();
            this.handler = new ControllerImplementation(this, baseConfig.id);
            this._backgroundColor = "";
            this._time = "";
            this._hoursView = false;
            this.viewAdded = false;
        },
        //Logic for getters/setters of custom properties
        initGettersSetters: function() {
            /**
             * @function
             * @property : backgroundColor
             * @description : this property set the background color for the time picker
             * @return : string
             */
            defineSetter(this, "bgColor", function(value) {
                if (value !== undefined && value !== null) this._backgroundColor = value;
            });
            defineGetter(this, "bgColor", function() {
                return this._backgroundColor;
            });
            /**
             * @function
             * @property : time
             * @description : this property set the time for the time picker
             * @return : string
             */
            defineSetter(this, "time", function(value) {
                if (value !== undefined && value !== null) this._time = value;
            });
            defineGetter(this, "time", function() {
                return this._time;
            });
            defineSetter(this, "invokeByDefault", function(value) {
                if (value !== undefined && value !== null) this._invokeByDefault = value;
            });
            defineGetter(this, "invokeByDefault", function() {
                return this._invokeByDefault;
            });
            /**
             * @function
             * @property : hoursView
             * @description : this property set the hours format of the time picker
             * @return : boolean
             */
            defineSetter(this, "hoursView", function(value) {
                if (value !== undefined && value !== null) this._hoursView = value;
            });
            defineGetter(this, "hoursView", function() {
                return this._hoursView;
            });
        },
        /**
         * @api : show
         * @description : This API will show timepicker
         * @return : null
         */
        show: function() {
            try {
                this.handler.show();
            } catch (exception) {
                throw exception;
            }
        },
        /**
         * @api : hide
         * @description : This API will hide the timepicker
         * @return : null
         */
        hide: function() {
            try {
                this.handler.hide();
            } catch (exception) {
                throw exception;
            }
        },
        /**
         * @api : setTime
         * @description : This API will set time to the time picker
         * @param : time - The required time parameter will set the time
         * @return : null
         */
        setTime: function(time) {
            try {
                this.handler.setTime(time);
            } catch (exception) {
                throw exception;
            }
        },
        /**
         * @api : getTime
         * @description : This API will return the time setted for the time picker
         * @return : time
         */
        getTime: function() {
            try {
                return this.handler.getTime();
            } catch (exception) {
                throw exception;
            }
        },
        /**
         * @api : setBackgroundColor
         * @description : This API will set the background color for the time picker
         * @param : color - The required color parameter will set the background color
         * @return : null
         */
        setBackgroundColor: function(color) {
            try {
                this.handler.setBackgroundColor(color);
            } catch (exception) {
                throw exception;
            }
        },
        /**
         * @api : is24HourView
         * @description : This API will return wheather the time picker is in 24 hours format or not
         * @return : enable
         */
        is24HoursView: function() {
            try {
                return this.handler.is24HoursView();
            } catch (exception) {
                throw exception;
            }
        },
        /**
         * @event : onTimeChanged
         * @description : called when time is changed in the component
         * @param : result {String} This event will give you time when ever it is changed
         * @param : time .
         */
        onTimeChanged: function(time) {
            // ontimechanged event
        }
    };
});
define("com/konymp/timepicker/timepickerControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** postShow defined for timepicker **/
    AS_FlexContainer_h9b6613f9e294116b2fa12090b1fb425: function AS_FlexContainer_h9b6613f9e294116b2fa12090b1fb425(eventobject) {
        var self = this;
        if (this.invokeByDefault) this.show();
    }
});
define("com/konymp/timepicker/timepickerController", ["com/konymp/timepicker/usertimepickerController", "com/konymp/timepicker/timepickerControllerActions"], function() {
    var controller = require("com/konymp/timepicker/usertimepickerController");
    var actions = require("com/konymp/timepicker/timepickerControllerActions");
    for (var key in actions) {
        controller[key] = actions[key];
    }
    controller.initializeProperties = function() {
        if (this.initGettersSetters) {
            this.initGettersSetters.apply(this, arguments);
        }
    };
    return controller;
});

define('com/konymp/timepicker/timepicker',[],function() {
    return function(controller) {
        var timepicker = new kony.ui.FlexContainer(extendConfig({
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "timepicker",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "postShow": controller.AS_FlexContainer_h9b6613f9e294116b2fa12090b1fb425,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, controller.args[0], "timepicker"), extendConfig({}, controller.args[1], "timepicker"), extendConfig({}, controller.args[2], "timepicker"));
        timepicker.setDefaultUnit(kony.flex.DP);
        timepicker.add();
        return timepicker;
    }
})
;
define('com/konymp/timepicker/timepickerConfig',[],function() {
    return {
        "properties": [{
            "name": "bgColor",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "hoursView",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "time",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }, {
            "name": "invokeByDefault",
            "enumerable": true,
            "configurable": false,
            "writable": true
        }],
        "apis": ["show", "hide", "getTime", "setTime", "setBackgroundColor", "is24HoursView"],
        "events": ["onTimeChanged"]
    }
});

define("flxSampleRowTemplate", [],function() {
    return function(controller) {
        var flxSampleRowTemplate = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "75dp",
            "id": "flxSampleRowTemplate",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleRowTemplate"
        }, {}, {});
        flxSampleRowTemplate.setDefaultUnit(kony.flex.DP);
        var lblHeading = new kony.ui.Label({
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknLblRowHeading",
            "text": "Heading",
            "textStyle": {},
            "top": "8.00%",
            "width": "45%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblDescription = new kony.ui.Label({
            "bottom": "10%",
            "id": "lblDescription",
            "isVisible": true,
            "left": "4%",
            "maxNumberOfLines": 3,
            "maxWidth": "70%",
            "skin": "sknLblDescription",
            "text": "Sub-Heading",
            "textStyle": {},
            "textTruncatePosition": constants.TEXT_TRUNCATE_NONE,
            "top": "42%",
            "width": "70%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblTime = new kony.ui.Label({
            "id": "lblTime",
            "isVisible": true,
            "right": "9%",
            "skin": "sknLblTimeStamp",
            "text": "Timestamp",
            "textStyle": {},
            "top": "10%",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblStrip = new kony.ui.Label({
            "height": "100%",
            "id": "lblStrip",
            "isVisible": true,
            "left": "0dp",
            "maxWidth": "1%",
            "skin": "sknLblStrip",
            "textStyle": {},
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxSampleRowTemplate.add(lblHeading, lblDescription, lblTime, lblStrip);
        return flxSampleRowTemplate;
    }
})
;
define("flxSectionHeaderTemplate", [],function() {
    return function(controller) {
        var flxSectionHeaderTemplate = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "45dp",
            "id": "flxSectionHeaderTemplate",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "skin": "sknSampleSectionHeaderTemplate"
        }, {}, {});
        flxSectionHeaderTemplate.setDefaultUnit(kony.flex.DP);
        var lblHeading = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblHeading",
            "isVisible": true,
            "left": "4%",
            "maxWidth": "50%",
            "skin": "sknSectionHeaderLabelSkin",
            "text": "Heading",
            "textStyle": {},
            "width": "75%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxSectionHeaderTemplate.add(lblHeading);
        return flxSectionHeaderTemplate;
    }
})
;
define("flxTempCrewInfo", [],function() {
    return function(controller) {
        var flxTempCrewInfo = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxTempCrewInfo",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, {
            "retainFlowHorizontalAlignment": false
        }, {});
        flxTempCrewInfo.setDefaultUnit(kony.flex.DP);
        var flxCrewMemberHeaderSup = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "42dp",
            "id": "flxCrewMemberHeaderSup",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlx000000Op13Percnt",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "retainFlowHorizontalAlignment": false
        }, {});
        flxCrewMemberHeaderSup.setDefaultUnit(kony.flex.DP);
        var lblCrewMemNameSup = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblCrewMemNameSup",
            "isVisible": true,
            "left": "5%",
            "skin": "sknLBl333Font100Bold",
            "text": "Chaves, Nelson",
            "textStyle": {},
            "top": "6dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var btnExpandCrewMemberDetails = new kony.ui.Button({
            "centerY": "50%",
            "focusSkin": "defBtnFocus",
            "height": "30dp",
            "id": "btnExpandCrewMemberDetails",
            "isVisible": true,
            "right": "5%",
            "skin": "sknExpandedDetails",
            "top": "3dp",
            "width": "30dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxCrewMemberHeaderSup.add(lblCrewMemNameSup, btnExpandCrewMemberDetails);
        var flxCrewMemberDetailsSup = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "200dp",
            "id": "flxCrewMemberDetailsSup",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "retainFlowHorizontalAlignment": false
        }, {});
        flxCrewMemberDetailsSup.setDefaultUnit(kony.flex.DP);
        var flxDPRIDSup = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "20%",
            "id": "flxDPRIDSup",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxSimpleBorder1PxFFFOp10",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "retainFlowHorizontalAlignment": false
        }, {});
        flxDPRIDSup.setDefaultUnit(kony.flex.DP);
        var lblDprIDSup = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblDprIDSup",
            "isVisible": true,
            "left": "5%",
            "skin": "sknLBl333Font100Bold",
            "text": "DPR ID",
            "textStyle": {},
            "top": "2dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblDprIDSupValue = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblDprIDSupValue",
            "isVisible": true,
            "right": "5%",
            "skin": "sknLBl333Font100",
            "text": "05538729",
            "textStyle": {},
            "top": "2dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxDPRIDSup.add(lblDprIDSup, lblDprIDSupValue);
        var flxEmployeeIDSup = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "20%",
            "id": "flxEmployeeIDSup",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxSimpleBorder1PxFFFOp10",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "retainFlowHorizontalAlignment": false
        }, {});
        flxEmployeeIDSup.setDefaultUnit(kony.flex.DP);
        var lblEmpIDSup = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblEmpIDSup",
            "isVisible": true,
            "left": "5%",
            "skin": "sknLBl333Font100Bold",
            "text": "Employee ID",
            "textStyle": {},
            "top": "2dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblEmpIDSupValue = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblEmpIDSupValue",
            "isVisible": true,
            "right": "5%",
            "skin": "sknLBl333Font100",
            "text": "0203732232",
            "textStyle": {},
            "top": "2dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxEmployeeIDSup.add(lblEmpIDSup, lblEmpIDSupValue);
        var flxStartDateSup = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "20%",
            "id": "flxStartDateSup",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxSimpleBorder1PxFFFOp10",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "retainFlowHorizontalAlignment": false
        }, {});
        flxStartDateSup.setDefaultUnit(kony.flex.DP);
        var lblStartDateSup = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblStartDateSup",
            "isVisible": true,
            "left": "5%",
            "skin": "sknLBl333Font100Bold",
            "text": "Start Date",
            "textStyle": {},
            "top": "2dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblStartDateSupValue = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblStartDateSupValue",
            "isVisible": true,
            "right": "5%",
            "skin": "sknLBl333Font100",
            "text": "2018-07-15",
            "textStyle": {},
            "top": "2dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxStartDateSup.add(lblStartDateSup, lblStartDateSupValue);
        var flxEndDateSup = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "20%",
            "id": "flxEndDateSup",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxSimpleBorder1PxFFFOp10",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "retainFlowHorizontalAlignment": false
        }, {});
        flxEndDateSup.setDefaultUnit(kony.flex.DP);
        var lblEndDateSup = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblEndDateSup",
            "isVisible": true,
            "left": "5%",
            "skin": "sknLBl333Font100Bold",
            "text": "End Date",
            "textStyle": {},
            "top": "2dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblEndDateSupValue = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblEndDateSupValue",
            "isVisible": true,
            "right": "5%",
            "skin": "sknLBl333Font100",
            "text": "2019-08-17",
            "textStyle": {},
            "top": "2dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxEndDateSup.add(lblEndDateSup, lblEndDateSupValue);
        var flxNormalHoursSup = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "20%",
            "id": "flxNormalHoursSup",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxSimpleBorder1PxFFFOp10",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "retainFlowHorizontalAlignment": false
        }, {});
        flxNormalHoursSup.setDefaultUnit(kony.flex.DP);
        var lblNormalHoursSup = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblNormalHoursSup",
            "isVisible": true,
            "left": "5%",
            "skin": "sknLBl333Font100Bold",
            "text": "Normal Hours",
            "textStyle": {},
            "top": "2dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblNormalHoursSupValue = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblNormalHoursSupValue",
            "isVisible": true,
            "right": "5%",
            "skin": "sknLBl333Font100",
            "text": "320",
            "textStyle": {},
            "top": "2dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxNormalHoursSup.add(lblNormalHoursSup, lblNormalHoursSupValue);
        flxCrewMemberDetailsSup.add(flxDPRIDSup, flxEmployeeIDSup, flxStartDateSup, flxEndDateSup, flxNormalHoursSup);
        flxTempCrewInfo.add(flxCrewMemberHeaderSup, flxCrewMemberDetailsSup);
        return flxTempCrewInfo;
    }
})
;
define("flxCrewSearchResults", [],function() {
    return function(controller) {
        var flxCrewSearchResults = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "24%",
            "id": "flxCrewSearchResults",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, {
            "retainFlowHorizontalAlignment": false
        }, {});
        flxCrewSearchResults.setDefaultUnit(kony.flex.DP);
        var lblCrewName = new kony.ui.Label({
            "centerY": "50%",
            "height": "100%",
            "id": "lblCrewName",
            "isVisible": true,
            "left": "3%",
            "skin": "sknLblSize1007099b1",
            "text": "Prabhjot Singh ",
            "textStyle": {},
            "top": "14dp",
            "width": "40%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [1, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblCrewEmployeeId = new kony.ui.Label({
            "centerY": "50%",
            "height": "100%",
            "id": "lblCrewEmployeeId",
            "isVisible": true,
            "right": "3%",
            "skin": "sknLblSize1007099b1",
            "text": "02032934",
            "textStyle": {},
            "top": "14dp",
            "width": "40%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
            "padding": [0, 0, 1, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxCrewSearchResults.add(lblCrewName, lblCrewEmployeeId);
        return flxCrewSearchResults;
    }
})
;
define("flxTempCrewDetails", [],function() {
    return function(controller) {
        var flxTempCrewDetails = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "40dp",
            "id": "flxTempCrewDetails",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxOp0",
            "top": "0dp",
            "width": "100%"
        }, {
            "retainFlowHorizontalAlignment": false
        }, {});
        flxTempCrewDetails.setDefaultUnit(kony.flex.DP);
        var flxTempCrewDetailsInner = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "45dp",
            "id": "flxTempCrewDetailsInner",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknFlxFFFFFFOp100",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, {
            "retainFlowHorizontalAlignment": false
        }, {});
        flxTempCrewDetailsInner.setDefaultUnit(kony.flex.DP);
        var lblCrewMemberName = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblCrewMemberName",
            "isVisible": true,
            "left": "5%",
            "skin": "sknLbl333333Bold100",
            "textStyle": {},
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblRole = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblRole",
            "isVisible": true,
            "right": "5%",
            "skin": "sknLbl333333100",
            "textStyle": {},
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblAddCrew = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblAddCrew",
            "isVisible": false,
            "left": "42%",
            "skin": "sknLbl333333Bold100",
            "text": "Add Crew",
            "textStyle": {},
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var imgAddCrew = new kony.ui.Image2({
            "centerY": "50%",
            "height": "40%",
            "id": "imgAddCrew",
            "isVisible": false,
            "left": "34.50%",
            "skin": "slImage",
            "src": "addicon.png",
            "width": "5%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxTempCrewDetailsInner.add(lblCrewMemberName, lblRole, lblAddCrew, imgAddCrew);
        flxTempCrewDetails.add(flxTempCrewDetailsInner);
        return flxTempCrewDetails;
    }
})
;
define("flxTempSegHistory", [],function() {
    return function(controller) {
        var flxTempSegHistory = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "50dp",
            "id": "flxTempSegHistory",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, {
            "retainFlowHorizontalAlignment": false
        }, {});
        flxTempSegHistory.setDefaultUnit(kony.flex.DP);
        var flxStatus = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerY": "50%",
            "clipBounds": true,
            "height": "6dp",
            "id": "flxStatus",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "3%",
            "isModalContainer": false,
            "skin": "sknFlx009C77Op100Border009C77Op100S1pxBorder",
            "width": "6dp",
            "zIndex": 1
        }, {
            "retainFlowHorizontalAlignment": false
        }, {});
        flxStatus.setDefaultUnit(kony.flex.DP);
        flxStatus.add();
        var lblDPRId = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblDPRId",
            "isVisible": true,
            "left": "7%",
            "skin": "sknLbl333333Op100S100Perc",
            "text": "DPR-1234567",
            "textStyle": {},
            "width": "27%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblProjectId = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblProjectId",
            "isVisible": true,
            "left": "38%",
            "skin": "sknLbl333333Op100S100Perc",
            "text": "0000144516",
            "textStyle": {},
            "width": "25%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblStartDate = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblStartDate",
            "isVisible": true,
            "left": "69.50%",
            "skin": "sknLbl333333Op100S100Perc",
            "text": "2005-07-15",
            "textStyle": {},
            "width": "25%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxTempSegHistory.add(flxStatus, lblDPRId, lblProjectId, lblStartDate);
        return flxTempSegHistory;
    }
})
;
define("flxTempSegProjects", [],function() {
    return function(controller) {
        var flxTempSegProjects = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "50dp",
            "id": "flxTempSegProjects",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, {
            "retainFlowHorizontalAlignment": false
        }, {});
        flxTempSegProjects.setDefaultUnit(kony.flex.DP);
        var lblProjectId = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblProjectId",
            "isVisible": true,
            "left": "6.50%",
            "skin": "sknLbl333333Op100S100Perc",
            "text": "0000100523",
            "textStyle": {},
            "width": "25%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblStartDate = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblStartDate",
            "isVisible": true,
            "left": "38%",
            "skin": "sknLbl333333Op100S100Perc",
            "text": "2005-06-28",
            "textStyle": {},
            "width": "25%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblEndDate = new kony.ui.Label({
            "centerY": "50%",
            "id": "lblEndDate",
            "isVisible": true,
            "left": "69.50%",
            "skin": "sknLbl333333Op100S100Perc",
            "text": "2005-07-15",
            "textStyle": {},
            "width": "25%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxTempSegProjects.add(lblProjectId, lblStartDate, lblEndDate);
        return flxTempSegProjects;
    }
})
;
define("flxTempSegTRC", [],function() {
    return function(controller) {
        var flxTempSegTRC = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "50dp",
            "id": "flxTempSegTRC",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%"
        }, {
            "retainFlowHorizontalAlignment": false
        }, {});
        flxTempSegTRC.setDefaultUnit(kony.flex.DP);
        var imgSelected = new kony.ui.Image2({
            "centerY": "50%",
            "height": "80%",
            "id": "imgSelected",
            "isVisible": true,
            "right": "5%",
            "skin": "slImage",
            "src": "checkbox_inactive.png",
            "width": "15%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var lblTRCDesciption = new kony.ui.Label({
            "centerY": "30%",
            "height": "40%",
            "id": "lblTRCDesciption",
            "isVisible": true,
            "left": "5%",
            "skin": "sknLbl333333Op100S100Perc",
            "text": "Onshore Hourly Rate",
            "textStyle": {},
            "width": "70%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        var lblTRCCode = new kony.ui.Label({
            "centerY": "75%",
            "height": "40%",
            "id": "lblTRCCode",
            "isVisible": true,
            "left": "5%",
            "skin": "sknLblFont8D8D8DOp100S90p",
            "text": "ONSHH",
            "textStyle": {},
            "width": "70%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "renderAsAnchor": false,
            "textCopyable": false
        });
        flxTempSegTRC.add(imgSelected, lblTRCDesciption, lblTRCCode);
        return flxTempSegTRC;
    }
})
;
define("userflxSampleRowTemplateController", {
    //Type your controller code here 
});
define("flxSampleRowTemplateControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSampleRowTemplateController", ["userflxSampleRowTemplateController", "flxSampleRowTemplateControllerActions"], function() {
    var controller = require("userflxSampleRowTemplateController");
    var controllerActions = ["flxSampleRowTemplateControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxSectionHeaderTemplateController", {
    //Type your controller code here 
});
define("flxSectionHeaderTemplateControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxSectionHeaderTemplateController", ["userflxSectionHeaderTemplateController", "flxSectionHeaderTemplateControllerActions"], function() {
    var controller = require("userflxSectionHeaderTemplateController");
    var controllerActions = ["flxSectionHeaderTemplateControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxTempCrewInfoController", {
    //Type your controller code here 
});
define("flxTempCrewInfoControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxTempCrewInfoController", ["userflxTempCrewInfoController", "flxTempCrewInfoControllerActions"], function() {
    var controller = require("userflxTempCrewInfoController");
    var controllerActions = ["flxTempCrewInfoControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxCrewSearchResultsController", {
    //Type your controller code here 
});
define("flxCrewSearchResultsControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxCrewSearchResultsController", ["userflxCrewSearchResultsController", "flxCrewSearchResultsControllerActions"], function() {
    var controller = require("userflxCrewSearchResultsController");
    var controllerActions = ["flxCrewSearchResultsControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxTempCrewDetailsController", {
    //Type your controller code here 
});
define("flxTempCrewDetailsControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxTempCrewDetailsController", ["userflxTempCrewDetailsController", "flxTempCrewDetailsControllerActions"], function() {
    var controller = require("userflxTempCrewDetailsController");
    var controllerActions = ["flxTempCrewDetailsControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxTempSegHistoryController", {
    //Type your controller code here 
});
define("flxTempSegHistoryControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxTempSegHistoryController", ["userflxTempSegHistoryController", "flxTempSegHistoryControllerActions"], function() {
    var controller = require("userflxTempSegHistoryController");
    var controllerActions = ["flxTempSegHistoryControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxTempSegProjectsController", {
    //Type your controller code here 
});
define("flxTempSegProjectsControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxTempSegProjectsController", ["userflxTempSegProjectsController", "flxTempSegProjectsControllerActions"], function() {
    var controller = require("userflxTempSegProjectsController");
    var controllerActions = ["flxTempSegProjectsControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

define("userflxTempSegTRCController", {
    //Type your controller code here 
});
define("flxTempSegTRCControllerActions", {
    /* 
    This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("flxTempSegTRCController", ["userflxTempSegTRCController", "flxTempSegTRCControllerActions"], function() {
    var controller = require("userflxTempSegTRCController");
    var controllerActions = ["flxTempSegTRCControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});

require(['applicationController','com/konymp/floatingaction/analytics','com/konymp/floatingaction/KonyLogger','com/konymp/floatingaction/floatingactionController','com/konymp/floatingaction/floatingaction','com/konymp/floatingaction/floatingactionConfig','com/konymp/timepicker/analytics','com/konymp/timepicker/ControllerImplementation','com/konymp/timepicker/Inherits','com/konymp/timepicker/konyLogger','com/konymp/timepicker/NativeController','com/konymp/timepicker/NativeControllerAndroid','com/konymp/timepicker/NativeControllerIOS','com/konymp/timepicker/timepickerController','com/konymp/timepicker/timepicker','com/konymp/timepicker/timepickerConfig','flxSampleRowTemplate','flxSectionHeaderTemplate','flxTempCrewInfo','flxCrewSearchResults','flxTempCrewDetails','flxTempSegHistory','flxTempSegProjects','flxTempSegTRC','flxSampleRowTemplateController','flxSectionHeaderTemplateController','flxTempCrewInfoController','flxCrewSearchResultsController','flxTempCrewDetailsController','flxTempSegHistoryController','flxTempSegProjectsController','flxTempSegTRCController'], function(){});

define("sparequirefileslist", function(){});

