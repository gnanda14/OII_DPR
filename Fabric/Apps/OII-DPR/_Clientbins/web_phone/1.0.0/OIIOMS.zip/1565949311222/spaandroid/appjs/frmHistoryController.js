define("userfrmHistoryController", {
    /**
     * @desc MVC navigation function
     * @param JSON data - contains the data received from other forms while navigating
     * @retun void
     */
    onNavigate: function(data) {
        this.view.flxFiltersOuter.isVisible = false;
        this.view.flxFiltersOuter.setEnabled(false);
    },
    /**
     * @desc Called on click of the back button
     * @param -
     * @retun void
     */
    onClickOfBack: function() {
        var navigationModule = require("navigationModule");
        navigationModule.navigateToFrmDashboard({});
    },
    /**
     * @desc Toggles filter on and off
     * @param -
     * @retun void
     */
    toggleFilters: function() {
        if (this.view.flxFiltersOuter.isVisible) {
            this.view.flxFiltersOuter.isVisible = false;
            this.view.flxFiltersOuter.setEnabled(false);
            this.view.flxBody.setEnabled(true);
        } else {
            this.view.flxBody.setEnabled(false);
            this.view.flxFiltersOuter.isVisible = true;
            this.view.flxFiltersOuter.setEnabled(true);
        }
    }
});
define("frmHistoryControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxMenuIcon **/
    AS_FlexContainer_c57b9454de174938bba4b85ad3033ac9: function AS_FlexContainer_c57b9454de174938bba4b85ad3033ac9(eventobject) {
        var self = this;
        this.onClickOfBack();
    },
    /** onClick defined for flxFilterIcon **/
    AS_FlexContainer_b818639388984e78b93d78f6b579e91f: function AS_FlexContainer_b818639388984e78b93d78f6b579e91f(eventobject) {
        var self = this;
        this.toggleFilters();
    },
    /** onClick defined for flxFiltersInner **/
    AS_FlexContainer_a73937d1b23c462fb3b88362fd1e9b4d: function AS_FlexContainer_a73937d1b23c462fb3b88362fd1e9b4d(eventobject) {
        var self = this;
        this.toggleFilters();
    }
});
define("frmHistoryController", ["userfrmHistoryController", "frmHistoryControllerActions"], function() {
    var controller = require("userfrmHistoryController");
    var controllerActions = ["frmHistoryControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
