define("frmDashboard", function() {
    return function(controller) {
        function addWidgetsfrmDashboard() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "7%",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx003C5COp100",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var flxMenuIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "55%",
                "clipBounds": true,
                "height": "80%",
                "id": "flxMenuIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "4%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_a8ce571fb0e94c1fb414de873388ca82,
                "skin": "slFbox",
                "width": "8%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxMenuIcon.setDefaultUnit(kony.flex.DP);
            var imgMenu = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgMenu",
                "isVisible": true,
                "skin": "slImage",
                "src": "hamburgermenuicon.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMenuIcon.add(imgMenu);
            var lblTitle = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblTitle",
                "isVisible": true,
                "skin": "sknLblFFFFFFOp100S130",
                "text": "Dashboard",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxHeader.add(flxMenuIcon, lblTitle);
            var flxBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "93%",
                "id": "flxBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "7%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxBody.setDefaultUnit(kony.flex.DP);
            var flxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "8%",
                "id": "flxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx999999Op100",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var flxSeachArea = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "80%",
                "id": "flxSeachArea",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.50%",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100BorderFFFFFFOp100Radius25px",
                "width": "87%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSeachArea.setDefaultUnit(kony.flex.DP);
            var txtSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "bottom": "5%",
                "focusSkin": "sknFFFFFFOp100Font333333Op100S100Perc",
                "height": "80%",
                "id": "txtSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "5%",
                "onTextChange": controller.AS_TextField_bf023ff7acc842cc9b1e104d3fdedb53,
                "placeholder": "Enter Project ID",
                "secureTextEntry": false,
                "skin": "sknFFFFFFOp100Font333333Op100S100Perc",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_NUMERIC,
                "width": "75%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var flxSearchIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "80%",
                "id": "flxSearchIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "85%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_f5c064e09ef24eedb9b3a6d835d5022a,
                "skin": "slFbox",
                "width": "10%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSearchIcon.setDefaultUnit(kony.flex.DP);
            var imgSearch = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgSearch",
                "isVisible": true,
                "skin": "slImage",
                "src": "search_icon.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchIcon.add(imgSearch);
            flxSeachArea.add(txtSearch, flxSearchIcon);
            flxSearch.add(flxSeachArea);
            var flxSegHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "7%",
                "id": "flxSegHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "8%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSegHeader.setDefaultUnit(kony.flex.DP);
            var lblProjectIdTitle = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblProjectIdTitle",
                "isVisible": true,
                "left": "6.50%",
                "skin": "sknLbl25536EOp100S110Perc",
                "text": "Project ID",
                "textStyle": {},
                "width": "25%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblStartDateTitle = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblStartDateTitle",
                "isVisible": true,
                "left": "38%",
                "skin": "sknLbl25536EOp100S110Perc",
                "text": "Start Date",
                "textStyle": {},
                "width": "25%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var lblEndDate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblEndDate",
                "isVisible": true,
                "left": "69.50%",
                "skin": "sknLbl25536EOp100S110Perc",
                "text": "End Date",
                "textStyle": {},
                "width": "25%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var flxHeaderLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHeaderLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxAAAAAAOp100",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHeaderLine.setDefaultUnit(kony.flex.DP);
            flxHeaderLine.add();
            flxSegHeader.add(lblProjectIdTitle, lblStartDateTitle, lblEndDate, flxHeaderLine);
            var segProjects = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{
                    "lblEndDate": "2005-07-15",
                    "lblProjectId": "0000100523",
                    "lblStartDate": "2005-06-28"
                }, {
                    "lblEndDate": "2005-07-15",
                    "lblProjectId": "0000100523",
                    "lblStartDate": "2005-06-28"
                }, {
                    "lblEndDate": "2005-07-15",
                    "lblProjectId": "0000100523",
                    "lblStartDate": "2005-06-28"
                }, {
                    "lblEndDate": "2005-07-15",
                    "lblProjectId": "0000100523",
                    "lblStartDate": "2005-06-28"
                }, {
                    "lblEndDate": "2005-07-15",
                    "lblProjectId": "0000100523",
                    "lblStartDate": "2005-06-28"
                }, {
                    "lblEndDate": "2005-07-15",
                    "lblProjectId": "0000100523",
                    "lblStartDate": "2005-06-28"
                }, {
                    "lblEndDate": "2005-07-15",
                    "lblProjectId": "0000100523",
                    "lblStartDate": "2005-06-28"
                }, {
                    "lblEndDate": "2005-07-15",
                    "lblProjectId": "0000100523",
                    "lblStartDate": "2005-06-28"
                }, {
                    "lblEndDate": "2005-07-15",
                    "lblProjectId": "0000100523",
                    "lblStartDate": "2005-06-28"
                }, {
                    "lblEndDate": "2005-07-15",
                    "lblProjectId": "0000100523",
                    "lblStartDate": "2005-06-28"
                }],
                "groupCells": false,
                "height": "85%",
                "id": "segProjects",
                "isVisible": false,
                "left": "0dp",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_ga511155ad604eeebe1540fd74506714,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxTempSegProjects",
                "scrollingEvents": {},
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": true,
                "top": "15%",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxTempSegProjects": "flxTempSegProjects",
                    "lblEndDate": "lblEndDate",
                    "lblProjectId": "lblProjectId",
                    "lblStartDate": "lblStartDate"
                },
                "width": "100%",
                "zIndex": 1
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoProjects = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblNoProjects",
                "isVisible": false,
                "skin": "sknLbl22253BOp100S130",
                "text": "No Projects Found.",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxBody.add(flxSearch, flxSegHeader, segProjects, lblNoProjects);
            var flxFAB = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "4%",
                "clipBounds": true,
                "height": "45dp",
                "id": "flxFAB",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_ec49ab7436df49d39a273de5152d814a,
                "right": "5%",
                "skin": "sknFlxOp0",
                "width": "45dp",
                "zIndex": 2
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxFAB.setDefaultUnit(kony.flex.DP);
            var flxFABInner = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxFABInner",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFD80FOp100BorderE0BE14Op100Circle",
                "top": "0dp",
                "width": "40dp",
                "zIndex": 3
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxFABInner.setDefaultUnit(kony.flex.DP);
            var imgFAB = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "65%",
                "id": "imgFAB",
                "isVisible": true,
                "skin": "slImage",
                "src": "konymp_fa_icon_plus.png",
                "width": "65%",
                "zIndex": 3
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFABInner.add(imgFAB);
            var imgShadow = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "40dp",
                "id": "imgShadow",
                "isVisible": true,
                "skin": "slImage",
                "src": "circle_shadow.png",
                "width": "40dp",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFAB.add(flxFABInner, imgShadow);
            var flxPopups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxPopups",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_a174f978551643b0a3c04fc709ad4021,
                "skin": "sknFlx000000Op40",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxPopups.setDefaultUnit(kony.flex.DP);
            var flxCrewOrSupervisor = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "33%",
                "id": "flxCrewOrSupervisor",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_gfa857301664420b810b7f70cab4c27e,
                "skin": "sknFlxBgFFFFFFOp100BorderFFFFFFS1pRounded",
                "width": "85%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCrewOrSupervisor.setDefaultUnit(kony.flex.DP);
            var flxCrewOrSupervisorHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "23%",
                "id": "flxCrewOrSupervisorHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxOp0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCrewOrSupervisorHeader.setDefaultUnit(kony.flex.DP);
            var lblCrewOrSupervisorHeader = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblCrewOrSupervisorHeader",
                "isVisible": true,
                "skin": "sknLblFont000000Op100S125pBold",
                "text": "Are You?",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var flxCloseCrewOrSupervisor = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "80%",
                "id": "flxCloseCrewOrSupervisor",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_b9cb194dba6049629da659c9dc65852c,
                "right": "5%",
                "skin": "slFbox",
                "width": "15%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCloseCrewOrSupervisor.setDefaultUnit(kony.flex.DP);
            var imgCloseCrewOrSupervisor = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "45%",
                "id": "imgCloseCrewOrSupervisor",
                "isVisible": true,
                "skin": "slImage",
                "src": "close_icon.png",
                "width": "50%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseCrewOrSupervisor.add(imgCloseCrewOrSupervisor);
            flxCrewOrSupervisorHeader.add(lblCrewOrSupervisorHeader, flxCloseCrewOrSupervisor);
            var flxCrewOrSupervisorBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "77%",
                "id": "flxCrewOrSupervisorBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxOp0",
                "top": "23%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCrewOrSupervisorBody.setDefaultUnit(kony.flex.DP);
            var flxCrew = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "70%",
                "id": "flxCrew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "8%",
                "isModalContainer": false,
                "skin": "sknFlxBorderABD3D9Op100S1pxRounded",
                "width": "35%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCrew.setDefaultUnit(kony.flex.DP);
            var imgCrew = new kony.ui.Image2({
                "centerX": "50%",
                "height": "60%",
                "id": "imgCrew",
                "isVisible": true,
                "skin": "slImage",
                "src": "crew_icon.png",
                "top": "5%",
                "width": "60%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCrew = new kony.ui.Label({
                "bottom": "10%",
                "centerX": "50%",
                "id": "lblCrew",
                "isVisible": true,
                "skin": "sknLblFont000000S110Prc",
                "text": "Crew",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxCrew.add(imgCrew, lblCrew);
            var flxSupervisor = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "70%",
                "id": "flxSupervisor",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "8%",
                "skin": "sknFlxBorderABD3D9Op100S1pxRounded",
                "width": "35%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSupervisor.setDefaultUnit(kony.flex.DP);
            var imgSupervisor = new kony.ui.Image2({
                "centerX": "53.50%",
                "height": "60%",
                "id": "imgSupervisor",
                "isVisible": true,
                "skin": "slImage",
                "src": "supervisor_icon.png",
                "top": "5%",
                "width": "60%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSupervisor = new kony.ui.Label({
                "bottom": "10%",
                "centerX": "50%",
                "id": "lblSupervisor",
                "isVisible": true,
                "skin": "sknLblFont000000S110Prc",
                "text": "Supervisor",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxSupervisor.add(imgSupervisor, lblSupervisor);
            var lblOr = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblOr",
                "isVisible": true,
                "skin": "sknLblFont000000S120Prc",
                "text": "or",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxCrewOrSupervisorBody.add(flxCrew, flxSupervisor, lblOr);
            flxCrewOrSupervisor.add(flxCrewOrSupervisorHeader, flxCrewOrSupervisorBody);
            var flxAddProject = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "24%",
                "id": "flxAddProject",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_fffe915d04f3437a9452ed2a081dfb3c,
                "skin": "sknFlxFFFFFFOp100",
                "width": "85%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxAddProject.setDefaultUnit(kony.flex.DP);
            var lblAddProject = new kony.ui.Label({
                "id": "lblAddProject",
                "isVisible": true,
                "left": "6%",
                "skin": "sknLblFont000000Op100S125pBold",
                "text": "Add Project ID",
                "textStyle": {},
                "top": "10%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var flxCloseAddProject = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "14%",
                "id": "flxCloseAddProject",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_fd3876e0a83343c79acb1be3c68de597,
                "right": "5%",
                "skin": "slFbox",
                "top": "8%",
                "width": "15%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCloseAddProject.setDefaultUnit(kony.flex.DP);
            var imgCloseAddProject = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "80%",
                "id": "imgCloseAddProject",
                "isVisible": true,
                "skin": "slImage",
                "src": "close_icon.png",
                "width": "70%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseAddProject.add(imgCloseAddProject);
            var btnAddProject = new kony.ui.Button({
                "bottom": "5%",
                "focusSkin": "sknBtn0097A8Op100Border0097A8Op100Rounded",
                "height": "20%",
                "id": "btnAddProject",
                "isVisible": true,
                "onClick": controller.AS_Button_fb504bace2d24894bc4e3b967cc78c7a,
                "right": "5%",
                "skin": "sknBtn0097A8Op100Border0097A8Op100Rounded",
                "text": "Sync/Add Project",
                "width": "47%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLineAddProject = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "35%",
                "clipBounds": true,
                "height": "1%",
                "id": "flxLineAddProject",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "sknFlx999999Op100",
                "width": "90%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxLineAddProject.setDefaultUnit(kony.flex.DP);
            flxLineAddProject.add();
            var txtAddProject = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "bottom": "36%",
                "focusSkin": "sknTbxBgFFFFFFOp0",
                "height": "25%",
                "id": "txtAddProject",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "5%",
                "onDone": controller.AS_TextField_i8bd8292acf5409f8bddca42b1355a78,
                "placeholder": "Project ID",
                "secureTextEntry": false,
                "skin": "sknTbxBgFFFFFFOp0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_NUMERIC,
                "width": "90%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoComplete": false,
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxAddProject.add(lblAddProject, flxCloseAddProject, btnAddProject, flxLineAddProject, txtAddProject);
            flxPopups.add(flxCrewOrSupervisor, flxAddProject);
            flxMain.add(flxHeader, flxBody, flxFAB, flxPopups);
            var flxHamburgerMenu = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxHamburgerMenu",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx000000Op40",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHamburgerMenu.setDefaultUnit(kony.flex.DP);
            var flxMenuBlankArea = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxMenuBlankArea",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "75%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_dd375a4776094b678494edf234281ace,
                "skin": "sknFlxOp0",
                "top": "0dp",
                "width": "25%",
                "zIndex": 6
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxMenuBlankArea.setDefaultUnit(kony.flex.DP);
            flxMenuBlankArea.add();
            var flxHamburgerMenuInner = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxHamburgerMenuInner",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-77.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "77.50%"
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHamburgerMenuInner.setDefaultUnit(kony.flex.DP);
            var flxHamburgerMenuMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxHamburgerMenuMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlx6C8EA1Op100",
                "top": "0dp",
                "width": "97%",
                "zIndex": 6
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHamburgerMenuMain.setDefaultUnit(kony.flex.DP);
            var flxMenuHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "17%",
                "id": "flxMenuHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx2F586EOp100",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxMenuHeader.setDefaultUnit(kony.flex.DP);
            var imgCompanyLogo = new kony.ui.Image2({
                "bottom": "5%",
                "height": "25%",
                "id": "imgCompanyLogo",
                "isVisible": true,
                "right": "5%",
                "skin": "slImage",
                "src": "oceaneering_logo_white.png",
                "width": "32%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMenuHeader.add(imgCompanyLogo);
            var flxHorizontalLineMenu1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1%",
                "id": "flxHorizontalLineMenu1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "top": "17%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHorizontalLineMenu1.setDefaultUnit(kony.flex.DP);
            flxHorizontalLineMenu1.add();
            var flxUserImage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "16%",
                "clipBounds": true,
                "height": "80dp",
                "id": "flxUserImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "9%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "80dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxUserImage.setDefaultUnit(kony.flex.DP);
            var imgWhiteCircle = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgWhiteCircle",
                "isVisible": true,
                "skin": "slImage",
                "src": "circle_shadow.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUserImageInner = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "48%",
                "centerY": "47%",
                "clipBounds": true,
                "height": "90%",
                "id": "flxUserImageInner",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxCircleOp0",
                "width": "90%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxUserImageInner.setDefaultUnit(kony.flex.DP);
            var imgUser = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "95%",
                "id": "imgUser",
                "isVisible": true,
                "skin": "slImage",
                "src": "dummy.png",
                "width": "95%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUserImageInner.add(imgUser);
            flxUserImage.add(imgWhiteCircle, flxUserImageInner);
            var flxOptions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "77.50%",
                "id": "flxOptions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "18%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxOptions.setDefaultUnit(kony.flex.DP);
            var lblUsername = new kony.ui.Label({
                "id": "lblUsername",
                "isVisible": true,
                "left": "11%",
                "skin": "sknLblFFFFFFOp100S100",
                "text": "Nakul Gupta",
                "textStyle": {},
                "top": "8%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var flxOptionsLine1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxOptionsLine1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBFBFBFFlxOp100",
                "top": "14%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxOptionsLine1.setDefaultUnit(kony.flex.DP);
            flxOptionsLine1.add();
            var flxDashboard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "10%",
                "id": "flxDashboard",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx000000Op10",
                "top": "15%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxDashboard.setDefaultUnit(kony.flex.DP);
            var lblDashboard = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDashboard",
                "isVisible": true,
                "left": "23.50%",
                "skin": "sknLblFFFFFFOp100S100",
                "text": "Dashboard",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var imgDashboard = new kony.ui.Image2({
                "centerY": "50%",
                "height": "45%",
                "id": "imgDashboard",
                "isVisible": true,
                "left": "10%",
                "right": "5%",
                "skin": "slImage",
                "src": "dashboard_active.png",
                "width": "10%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDashboard.add(lblDashboard, imgDashboard);
            var flxOptionsLine2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxOptionsLine2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBFBFBFFlxOp100",
                "top": "25.50%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxOptionsLine2.setDefaultUnit(kony.flex.DP);
            flxOptionsLine2.add();
            var flxHistory = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "10%",
                "id": "flxHistory",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_a6456668709348bc9ccdaef25ba4b0fd,
                "skin": "sknFlxOp0",
                "top": "26%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxHistory.setDefaultUnit(kony.flex.DP);
            var lblHistory = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblHistory",
                "isVisible": true,
                "left": "23.50%",
                "skin": "sknLblE6E6E6Op100S100",
                "text": "DPR History",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var imgHistory = new kony.ui.Image2({
                "centerY": "50%",
                "height": "45%",
                "id": "imgHistory",
                "isVisible": true,
                "left": "10%",
                "right": "5%",
                "skin": "slImage",
                "src": "history_inactive.png",
                "width": "10%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHistory.add(lblHistory, imgHistory);
            var flxOptionsLine3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxOptionsLine3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBFBFBFFlxOp100",
                "top": "36.50%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxOptionsLine3.setDefaultUnit(kony.flex.DP);
            flxOptionsLine3.add();
            var flxOptionsLine4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "21.50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxOptionsLine4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBFBFBFFlxOp100",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxOptionsLine4.setDefaultUnit(kony.flex.DP);
            flxOptionsLine4.add();
            var flxTouchId = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "11%",
                "clipBounds": true,
                "height": "10%",
                "id": "flxTouchId",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_b092eae1834c4cfb85b63dc349f550d3,
                "skin": "sknFlxOp0",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxTouchId.setDefaultUnit(kony.flex.DP);
            var lblTouchId = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblTouchId",
                "isVisible": true,
                "left": "11%",
                "skin": "sknLblE6E6E6Op100S100",
                "text": "Touch ID / Face ID",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var imgTouchId = new kony.ui.Image2({
                "centerY": "50%",
                "height": "65%",
                "id": "imgTouchId",
                "isVisible": true,
                "right": "8%",
                "skin": "slImage",
                "src": "switch_off.png",
                "width": "14.50%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTouchId.add(lblTouchId, imgTouchId);
            var flxOptionsLine5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "10.50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxOptionsLine5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBFBFBFFlxOp100",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxOptionsLine5.setDefaultUnit(kony.flex.DP);
            flxOptionsLine5.add();
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0%",
                "clipBounds": true,
                "height": "10%",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_ec7e8c069f204687a6032c2b2e7eeda4,
                "skin": "sknFlxOp0",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var lblLogout = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblLogout",
                "isVisible": true,
                "left": "11%",
                "skin": "sknLblE6E6E6Op100S100",
                "text": "Logout",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            var imgLogout = new kony.ui.Image2({
                "centerY": "50%",
                "height": "45%",
                "id": "imgLogout",
                "isVisible": true,
                "right": "11%",
                "skin": "slImage",
                "src": "logout.png",
                "width": "10%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLogout.add(lblLogout, imgLogout);
            flxOptions.add(lblUsername, flxOptionsLine1, flxDashboard, flxOptionsLine2, flxHistory, flxOptionsLine3, flxOptionsLine4, flxTouchId, flxOptionsLine5, flxLogout);
            var flxFooterLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "4%",
                "clipBounds": true,
                "height": "2dp",
                "id": "flxFooterLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFOp100",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxFooterLine.setDefaultUnit(kony.flex.DP);
            flxFooterLine.add();
            var flxMenuFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "4%",
                "id": "flxMenuFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx2F586EOp100",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxMenuFooter.setDefaultUnit(kony.flex.DP);
            var lblVersion = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblVersion",
                "isVisible": true,
                "right": "5%",
                "skin": "sknLblE8E8E8Op100S80",
                "text": "v1.0.0",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "renderAsAnchor": false,
                "textCopyable": false
            });
            flxMenuFooter.add(lblVersion);
            flxHamburgerMenuMain.add(flxMenuHeader, flxHorizontalLineMenu1, flxUserImage, flxOptions, flxFooterLine, flxMenuFooter);
            var imgMenuShadow = new kony.ui.Image2({
                "height": "101%",
                "id": "imgMenuShadow",
                "isVisible": true,
                "right": "0%",
                "skin": "slImage",
                "src": "vertical_shadow.png",
                "top": "-0.50%",
                "width": "3.50%",
                "zIndex": 5
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHamburgerMenuInner.add(flxHamburgerMenuMain, imgMenuShadow);
            flxHamburgerMenu.add(flxMenuBlankArea, flxHamburgerMenuInner);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlx000000Op40",
                "width": "100%",
                "zIndex": 15
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "10%",
                "id": "imgLoading",
                "isVisible": true,
                "skin": "slImage",
                "src": "loading.gif",
                "width": "30%",
                "zIndex": 15
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoading.add(imgLoading);
            this.add(flxMain, flxHamburgerMenu, flxLoading);
        };
        return [{
            "addWidgets": addWidgetsfrmDashboard,
            "bounces": false,
            "enableScrolling": false,
            "enabledForIdleTimeout": false,
            "id": "frmDashboard",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmFFD80FOp100"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});