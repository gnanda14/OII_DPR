define("userfrmCreateDPRController", {
    //Boolean - Checks whether the project is hourly or day based
    isHourlyRate: true,
    //String - Contains the name of the previous form
    navigatingFrom: null,
    //JS Module - Contains common functions used throughout the application
    CommonUtilsModule: null,
    //JS Module - Contains navigation functions used to move to other screens
    navigationModule: null,
    /**
     * @desc MVC navigation function
     * @param JSON data - contains the data received from other forms while navigating
     * @retun void
     */
    onNavigate: function(data) {
        this.toggleLoadingIndicator(true);
        this.dismissPopups();
        this.navigatingFrom = data.navigatingFrom;
        this.initializeJSModules(data.projectData);
    },
    /**
     * @desc Initializes all the JS modules required in this form
     * @param JSON projectData - contains the project data to be displayed on the screen
     * @retun void
     */
    initializeJSModules: function(projectData) {
        this.CommonUtilsModule = require("commonUtils");
        this.navigationModule = require("navigationModule");
        this.setProjectDetails(projectData);
    },
    /**
     * @desc Sets the project details
     * @param JSON projectData - contains the project data to be displayed on the screen
     * @retun void
     */
    setProjectDetails: function(projectData) {
        this.view.lblProjectDetails.text = "Project Details - " + projectData.Project_Id;
        this.getCrewDetails(projectData.Project_Id);
    },
    /**
     * @desc Calls a service to get the current project's crew details
     * @param String projectID - contains the id of the selected project
     * @retun void
     */
    getCrewDetails: function(projectID) {
        var integrationObj = oceaneering.oms.appGlobals.client.getIntegrationService("StagingDB");
        var operationName = "dbo_crew_Info_get";
        var data = {
            "$filter": "projectId eq " + projectID
        };
        var headers = {};
        integrationObj.invokeOperation(operationName, headers, data, this.successCallback_GetCrewDetails.bind(this), this.errorCallback.bind(this));
    },
    /**
     * @desc Success callback of crew details service
     * @param JSON response - contains the crew details for the selected project
     * @retun void
     */
    successCallback_GetCrewDetails: function(response) {
        this.view.segCrewDetails.widgetDataMap = {
            "lblCrewMemberName": "empName",
            "lblRole": "selectedRole"
        };
        this.view.segCrewDetails.setData(response.crew_Info);
        this.getCurrentEmployeePersonnelDetails(response.crew_Info);
    },
    getCurrentEmployeePersonnelDetails: function(CrewDetails) {
        for (var i = 0; i < CrewDetails.length; i++) {
            if (CrewDetails[i].empId == oceaneering.oms.appGlobals.employeeId) {
                this.setPersonnelDetails(CrewDetails[i]);
                return;
            }
        }
        this.toggleLoadingIndicator(false);
    },
    setPersonnelDetails: function(personnelDetails) {
        this.view.lblNameValue.text = personnelDetails.empName;
        this.view.lblEmpIDValue.text = personnelDetails.empId;
        this.view.lblJobPositionValue.text = personnelDetails.jobPosition;
        this.view.lblCrewPositionValue.text = personnelDetails.crewPosition;
        this.view.lblArrivalDateValue.text = (personnelDetails.arrivalDate).substring(0, 10);
        this.view.lblDepartDateValue.text = (personnelDetails.departureDate).substring(0, 10);
        this.view.lblStandbyRateValue.text = personnelDetails.standbyRate;
        this.view.lblNonDiveRateValue.text = personnelDetails.nonDiveRate;
        this.view.lblHourlyRateValue.text = this.isHourlyRate ? personnelDetails.hourlyRate : personnelDetails.dayRate;
        this.view.flxBillingHours.isVisible = this.isHourlyRate;
        this.getTRC(personnelDetails.empId);
    },
    getTRC: function(employeeID) {
        var integrationObj = oceaneering.oms.appGlobals.client.getIntegrationService("Projects");
        var operationName = "getTRC";
        var data = {
            "empId": employeeID
        };
        var headers = {};
        integrationObj.invokeOperation(operationName, headers, data, this.successCallback_GetTRC.bind(this), this.errorCallback_GetTRC.bind(this));
    },
    successCallback_GetTRC: function(response) {
        var TRCData = [];
        for (var i = 0; i < response.Record.length; i++) {
            TRCData.push([response.Record[i].trc, response.Record[i].description + " - " + response.Record[i].trc]);
        }
        this.view.chxkbxTRCList.masterData = TRCData;
        this.toggleLoadingIndicator(false);
    },
    errorCallback_GetTRC: function(error) {
        this.toggleLoadingIndicator(false);
        if (error.errmsg != "empty response received") {
            this.showErrorMessage();
        }
    },
    onClickOfTRCDropDown: function() {
        if (this.CommonUtilsModule.checkIfEmpty(this.view.chxkbxTRCList.masterData)) {
            alert("No TRC available.");
        } else {
            this.showPopup(this.view.flxTRCPopup);
        }
    },
    onDoneOfTRCPopup: function() {
        var selectedTRC = this.view.chxkbxTRCList.selectedKeyValues;
        if (this.CommonUtilsModule.checkIfEmpty(selectedTRC)) {
            this.view.lblTRCValue.text = "None";
        } else {
            var trcValues = selectedTRC[0][1];
            for (var i = 1; i < selectedTRC.length; i++) {
                trcValues = trcValues + ", " + selectedTRC[i][1];
            }
            this.view.lblTRCValue.text = trcValues;
        }
        this.dismissPopups();
    },
    onClickOfBack: function() {
        this.navigationModule.navigateToFrmDashboard({
            "navigatingFrom": "Create"
        });
    },
    /**
     * @desc Hides all the popups from the screen
     * @param -
     * @retun void
     */
    dismissPopups: function() {
        this.view.flxHeader.setEnabled(true);
        this.view.flxBody.setEnabled(true);
        this.view.flxPopups.isVisible = false;
        this.view.flxPopups.setEnabled(false);
        this.view.flxTRCPopup.isVisible = false;
        this.view.flxTRCPopup.setEnabled(false);
    },
    /**
     * @desc shows the selected popup on the screen
     * @param Widet popupWidget - Contains the popup widget to be displayed
     * @retun void
     */
    showPopup: function(popupWidget) {
        this.view.flxHeader.setEnabled(false);
        this.view.flxBody.setEnabled(false);
        this.view.flxPopups.isVisible = true;
        this.view.flxPopups.setEnabled(true);
        popupWidget.isVisible = true;
        popupWidget.setEnabled(true);
    },
    /**
     * @desc Commom error callback for service calls
     * @param JSON error - Contains the error message and error code of service call
     * @retun void
     */
    errorCallback: function(error) {
        this.showErrorMessage();
    },
    /**
     * @desc Shows the common error message
     * @param -
     * @retun void
     */
    showErrorMessage: function() {
        this.toggleLoadingIndicator(false);
        alert("Sorry, something went wrong. Please try again later.");
    },
    /**
     * @desc Toggles loading indicator on and off
     * @param boolean value - True: to show loading indicator, false: to hide loading indicator
     * @retun void
     */
    toggleLoadingIndicator: function(value) {
        this.view.flxLoading.isVisible = value;
        this.view.flxMain.setEnabled(!value);
    },
    /**
     * @desc Empty function. Does nothing
     * @param -
     * @retun void
     */
    doNothing: function() {
        //Empty Function
    }
});
define("frmCreateDPRControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for flxBack **/
    AS_FlexContainer_adb4ce04e85d4a8f95ea8a99b6bc2238: function AS_FlexContainer_adb4ce04e85d4a8f95ea8a99b6bc2238(eventobject) {
        var self = this;
        this.onClickOfBack();
    },
    /** onClick defined for flxTRCValue **/
    AS_FlexContainer_i70a97574b9a4bfd9a2a11c4ce025c20: function AS_FlexContainer_i70a97574b9a4bfd9a2a11c4ce025c20(eventobject) {
        var self = this;
        this.onClickOfTRCDropDown();
    },
    /** onClick defined for flxDoneTRCPopup **/
    AS_FlexContainer_j43dd2a8067e44ba97b54785aa4d9abe: function AS_FlexContainer_j43dd2a8067e44ba97b54785aa4d9abe(eventobject) {
        var self = this;
        this.onDoneOfTRCPopup();
    },
    /** onClick defined for flxTRCPopup **/
    AS_FlexContainer_h35d6572c0734735a32a3eeaa7b4b0a9: function AS_FlexContainer_h35d6572c0734735a32a3eeaa7b4b0a9(eventobject) {
        var self = this;
        this.doNothing();
    },
    /** onClick defined for flxPopups **/
    AS_FlexContainer_ca8aca278a854821954ad6cb1f7e5c95: function AS_FlexContainer_ca8aca278a854821954ad6cb1f7e5c95(eventobject) {
        var self = this;
        this.dismissPopups();
    }
});
define("frmCreateDPRController", ["userfrmCreateDPRController", "frmCreateDPRControllerActions"], function() {
    var controller = require("userfrmCreateDPRController");
    var controllerActions = ["frmCreateDPRControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
