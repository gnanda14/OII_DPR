define("userfrmDPRInfoController", {
    onNavigate: function(data) {
        //     this.refreshDPRInfoPage();
        //     if (data.role == "Crew") {
        //       this.view.flxAddCrew.isVisible=false;
        //       this.view.btnExpandProjectDetails.isVisible=true;
        //       this.view.flxPersonnelHeader.isVisible=true;
        //       this.view.flxPersonnelDetails.isVisible=true;
        //       this.view.flxCrewDPRInfo.isVisible=false;
        //       this.view.segCrewInfo.isVisible=false;
        //       this.view.btnSave.text="Save";
        //       this.view.lblHeaderTitle.text = "Create DPR";
        //     } else {
        //       this.view.flxAddCrew.isVisible=true;
        //       this.view.btnExpandProjectDetails.isVisible=false;     
        //       this.view.flxPersonnelHeader.isVisible=false;
        //       this.view.flxPersonnelDetails.isVisible=false;
        //       this.view.flxCrewDPRInfo.isVisible=true;
        //       this.view.segCrewInfo.isVisible=true;
        //       this.view.btnSave.text="Create DPR";
        //        this.view.lblHeaderTitle.text = "";
        //     }
        this.getCrewDetails(data.projectData.Project_Id);
    },
    getCrewDetails: function(projectID) {
        var integrationObj = oceaneering.oms.appGlobals.client.getIntegrationService("StagingDB");
        var operationName = "dbo_crew_Info_get";
        var data = {
            "$filter": "projectId eq " + projectID
        };
        var headers = {};
        integrationObj.invokeOperation(operationName, headers, data, this.successCallback_GetCrewDetails.bind(this), this.errorCallback_GetCrewDetails.bind(this));
    },
    successCallback_GetCrewDetails: function(response) {
        var crewDetails = response.crew_Info;
        this.view.segCrewDetails.widgetDataMap = {
            "lblCrewMemberName": "empName",
            "lblRole": "selectedRole"
        };
        this.view.segCrewDetails.setData(crewDetails);
    },
    errorCallback_GetCrewDetails: function(error) {},
    refreshDPRInfoPage: function() {
        this.view.flxProjectHeader.isVisible = true;
        this.view.borderProjectDetails.isVisible = true;
        this.view.flxProjectDetails.isVisible = false;
        this.view.segCrewDetails.isVisible = false;
        this.view.flxCrewDetailsHeader.isVisible = true;
        this.view.borderCrewDetails.isVisible = true;
    },
    expand_contract_projectDetails: function() {
        if (this.view.btnExpandProjectDetails.skin == "sknNonExpandedDetails") {
            if (this.view.btnExpandCrewDetails.skin == "sknExpandedDetails") {
                this.expand_contract_crewDetails();
            }
            this.view.btnExpandProjectDetails.skin = "sknExpandedDetails";
            this.view.flxProjectDetails.isVisible = true;
        } else {
            this.view.btnExpandProjectDetails.skin = "sknNonExpandedDetails";
            this.view.flxProjectDetails.isVisible = false;
        }
    },
    expand_contract_crewDetails: function() {
        if (this.view.btnExpandCrewDetails.skin == "sknNonExpandedDetails") {
            if (this.view.btnExpandProjectDetails.skin == "sknExpandedDetails") {
                this.expand_contract_projectDetails();
            }
            this.view.btnExpandCrewDetails.skin = "sknExpandedDetails";
            this.view.segCrewDetails.isVisible = true;
            this.view.borderCrewDetails.isVisible = false;
        } else {
            this.view.btnExpandCrewDetails.skin = "sknNonExpandedDetails";
            this.view.segCrewDetails.isVisible = false;
            this.view.borderCrewDetails.isVisible = true;
        }
    }
});
define("frmDPRInfoControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0a7a6a6484c974e **/
    AS_Button_aec2ded646b844fba45f18588a15adbd: function AS_Button_aec2ded646b844fba45f18588a15adbd(eventobject) {
        var self = this;
        var projectId = this.view.lblProjectID.text.split("-")[1];
        var navigationModule = require("navigationModule");
        navigationModule.navigateToFrmAddCrew(projectId);
    },
    /** onClick defined for btnExpandProjectDetails **/
    AS_Button_ba1c21305a204fcfbd24836abfa3c1e9: function AS_Button_ba1c21305a204fcfbd24836abfa3c1e9(eventobject) {
        var self = this;
        this.expand_contract_projectDetails();
    },
    /** onClick defined for btnExpandCrewDetails **/
    AS_Button_d7d85dd542af424283d3d9b6f4ba6276: function AS_Button_d7d85dd542af424283d3d9b6f4ba6276(eventobject) {
        var self = this;
        this.expand_contract_crewDetails();
    },
    /** onClick defined for btnSave **/
    AS_Button_f62f524b24fb48da8b59ca9c8cb4aa63: function AS_Button_f62f524b24fb48da8b59ca9c8cb4aa63(eventobject) {
        var self = this;
        var navigationModule = require("navigationModule");
        navigationModule.navigateToFrmDashboard({});
    }
});
define("frmDPRInfoController", ["userfrmDPRInfoController", "frmDPRInfoControllerActions"], function() {
    var controller = require("userfrmDPRInfoController");
    var controllerActions = ["frmDPRInfoControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
