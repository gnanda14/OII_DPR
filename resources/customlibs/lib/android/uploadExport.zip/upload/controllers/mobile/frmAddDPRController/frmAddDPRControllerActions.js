define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** postShow defined for frmAddDPR **/
    AS_Form_d9c947268b4a4f9a976c6775ceba4914: function AS_Form_d9c947268b4a4f9a976c6775ceba4914(eventobject) {
        var self = this;
    }
});