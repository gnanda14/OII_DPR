/* jshint esnext: true */

/**
 * @Description - Contains the functionality of the Create DPR Form
 * @author - Amritpal Singh
*/

define({ 
  /**
    * @desc MVC navigation function
    * @param JSON data - contains the data received from other forms while navigating
    * @retun void
  */
  onNavigate : function(data) {
    try {
      this.bindAttachments();
    } catch(ex){
      //this.exception(ex);
    }
  },

  /// ----------------------------- Attachments -----------------//
  onClickOfCamera : function(){
    try {
      var base64Image = "";
      var rawByte = this.view.CameraImage.rawBytes;
      var imageObject = kony.image.createImage(rawByte);
      imageObject.compress(0.4);    
      imageObject.scale(0.4);    
      base64Image = kony.convertToBase64(imageObject.getImageAsRawBytes());
      this.view.img.base64 = base64Image;
      this.HideFileUploadPopUp();
    } catch(err){
     // commonUtils.exception(this , err);
    }
  },

  openFileUploadPopUp : function() {
    var self = this;
    this.view.flxEditImage.setVisibility(true);
    self.view.FlexContainerData.animate(
      kony.ui.createAnimation({
        "100": {
          "height": "250dp",
          "stepConfig": {
            "timingFunction": kony.anim.EASE
          }
        }
      }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.2
      }, {
        "animationEnd": ""
      });
  },

  HideFileUploadPopUp : function() {
    var self = this;
    self.view.FlexContainerData.animate(
      kony.ui.createAnimation({
        "100": {
          "height": "0dp",
          "stepConfig": {
            "timingFunction": kony.anim.EASE
          }
        }
      }), {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.2
      }, {
        "animationEnd": ()=>{
          self.view.flxEditImage.setVisibility(false);
        }
      });
  },

  onClickOfOpenGallery : function(){
    try {
      var queryContext = { mimetype : "image/*" }; // image/*, video/*, audio/*
      var returnStatus = kony.phone.openMediaGallery(this.onImageSelectionCallback.bind(this), queryContext);
    } catch(err){
    //  commonUtils.exception(this, err);
    }
  },

  onImageSelectionCallback : function(rawBytes){
    try {
     // this.showLoading();
      if((rawBytes)){
        var imageObject = kony.image.createImage(rawBytes);
        imageObject.compress(0.4);
        imageObject.scale(0.4);
        var base64Image = kony.convertToBase64(imageObject.getImageAsRawBytes()); 
        this.HideFileUploadPopUp();
      } else {
      //  this.dismissLoading();
        this.HideFileUploadPopUp();
      }
    } catch(err){
     // commonUtils.exception(this, err);
    }
  },

  onClickOfOpenFileSystem : function(){
    try {
      var queryContext = { mimetype : "application/*" };
      var returnStatus = kony.phone.openMediaGallery(this.onFileSelectionCallback.bind(this), queryContext);
    } catch(err){
     // commonUtils.exception(this, err);
    }
  },

  onFileSelectionCallback : function(rawBytes){
    try{
      var base64NPWP = kony.convertToBase64(rawBytes);
      if((rawBytes)){
        this.HideFileUploadPopUp();
        this.openPDF(base64NPWP);
      } else {
      //  this.dismissLoading();
        this.HideFileUploadPopUp();
      }    
    } catch(err){
     // commonUtils.exception(this, err);
    }
  },

  bindAttachments : function(){
    var self = this;
    this.view.btnCancel.onClick = this.HideFileUploadPopUp.bind(this);
    this.view.flxGallary.onClick = this.onClickOfOpenGallery.bind(this);
    this.view.CameraImage.onCapture = this.onClickOfCamera.bind(this);
    this.view.flxFile.onClick = this.onClickOfOpenFileSystem.bind(this); 
    
    this.view.upload.onClick = this.openFileUploadPopUp.bind(this);
  },

  openPDF : function(base64String){
    try {
      //#ifdef android
      let pdfName = "Oceaneering" + parseInt(Math.random() * 100);
      let savePDFResponse = NSPDFViewer.savePDF(base64String, pdfName);
      if(savePDFResponse == "PDF Created Successfully"){
        let openPdfResponse = NSPDFViewer.openPDF(pdfName, "com.oceaneering.oms");  
        if(openPdfResponse == "PDF Opened Successfully"){
          alert("open pdf success");
        }
      }
      //#endif
    } catch(error) {
      alert(error);
    //  commonUtils.exception(this, error);
    }
  }, 


  openDOC : function(base64String){
    try {
      //#ifdef android
      let pdfName = "Oceaneering" + parseInt(Math.random() * 100);
      let savePDFResponse = NSPDFViewer.saveDOC(base64String, pdfName);
      if(savePDFResponse == "DOC Created Successfully"){
        let openPdfResponse = NSPDFViewer.openDOC(pdfName, "com.oceaneering.oms");  
        if(openPdfResponse == "DOC Opened Successfully"){
          alert("open doc success");
        } else{
          
        }
      }
      //#endif
    } catch(error) {
      alert(error);
    //  commonUtils.exception(this, error);
    }
  }, 

  openExcel : function(base64String){
    try {
      //#ifdef android
      let pdfName = "Oceaneering" + parseInt(Math.random() * 100);
      let savePDFResponse = NSPDFViewer.saveExcel(base64String, pdfName);
      if(savePDFResponse == "Excel Created Successfully"){
        let openPdfResponse = NSPDFViewer.openExcel(pdfName, "com.oceaneering.oms");  
        if(openPdfResponse == "Excel Opened Successfully"){
          alert("open excel success");
        } else{
          
        }
      }
      //#endif
    } catch(error) {
      alert(error);
    }
  }
});