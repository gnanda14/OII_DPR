var NSPDFViewer={};
NSPDFViewer.savePDF= function(base64String,pdfName){};
NSPDFViewer.openPDF= function(pdfName,applicationId){};
