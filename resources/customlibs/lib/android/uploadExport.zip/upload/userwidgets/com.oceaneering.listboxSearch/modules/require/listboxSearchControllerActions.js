define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onDone defined for tbxSearch **/
    AS_TextField_g3d1fd7283f342aa9c0bdc6ceb62b269: function AS_TextField_g3d1fd7283f342aa9c0bdc6ceb62b269(eventobject, changedtext) {
        var self = this;
        this.onDoneInSearch();
    }
});