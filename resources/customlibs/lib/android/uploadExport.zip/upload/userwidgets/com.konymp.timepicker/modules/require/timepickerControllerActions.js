define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** postShow defined for timepicker **/
    AS_FlexContainer_i0d0c4869ce247059c65467fafa1e378: function AS_FlexContainer_i0d0c4869ce247059c65467fafa1e378(eventobject) {
        var self = this;
        //#ifdef android
        this.viewAdded = false;
        //#endif
        if (this.invokeByDefault) this.show();
    }
});