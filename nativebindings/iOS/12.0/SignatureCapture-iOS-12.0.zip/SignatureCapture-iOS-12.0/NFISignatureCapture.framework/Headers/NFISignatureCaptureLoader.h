#import <JavaScriptCore/JavaScriptCore.h>

void loadNFISignatureCaptureModules(JSContext* context);
JSValue* extractNFISignatureCaptureStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFISignatureCaptureStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
